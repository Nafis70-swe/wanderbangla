import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
  onClick?: () => void;
}

export const WanderBanglaLogo: React.FC<LogoProps> = ({
  size = 'md',
  showText = true,
  className = '',
  onClick,
}) => {
  // Sizing definitions - Clean and transparent background
  const sizeMap = {
    sm: { svg: 26, text: 'text-sm font-black tracking-tight', sub: 'text-[9px]' },
    md: { svg: 32, text: 'text-base font-black tracking-tight', sub: 'text-[10px]' },
    lg: { svg: 44, text: 'text-xl font-black tracking-tight', sub: 'text-xs' },
    xl: { svg: 56, text: 'text-2xl font-black tracking-tight', sub: 'text-sm' },
  };

  const current = sizeMap[size];

  return (
    <div
      onClick={onClick}
      className={`inline-flex items-center gap-2.5 transition-transform duration-200 select-none bg-transparent ${className} ${
        onClick ? 'cursor-pointer hover:opacity-90' : ''
      }`}
    >
      {/* Bangladesh Map Silhouette Emblem with Red Sun Core & White Lettering */}
      <div className="relative shrink-0 flex items-center justify-center p-1 rounded-xl bg-[#0f6b4f]/10 border border-[#0f6b4f]/20 shadow-2xs">
        <svg
          width={current.svg}
          height={current.svg}
          viewBox="0 0 100 100"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="drop-shadow-xs"
        >
          {/* Bangladesh silhouette */}
          <path
            d="M 28 14 
               C 32 10, 36 12, 38 18 
               C 41 15, 45 16, 43 23 
               C 48 20, 52 24, 49 30 
               C 53 30, 56 34, 52 38 
               L 42 38 
               L 37 32 
               L 31 32 
               L 28 26 
               Z"
            fill="#0f6b4f"
          />

          <path
            d="M 28 26 
               L 36 29 
               L 34 38 
               L 26 42 
               L 32 46 
               L 28 54 
               L 35 58 
               L 30 68 
               L 37 72 
               L 44 71 
               L 40 65 
               L 43 56 
               L 39 48 
               L 43 42 
               L 37 38 
               L 36 29 
               Z"
            fill="#0f6b4f"
          />

          <path
            d="M 52 32 
               C 58 29, 65 30, 68 35 
               C 71 40, 67 46, 61 46 
               L 57 40 
               L 52 42 
               Z"
            fill="#0f6b4f"
          />

          {/* Red Central Sun Core */}
          <path
            d="M 43 42 
               L 58 42 
               L 52 64 
               L 48 68 
               L 46 62 
               L 49 52 
               L 43 52 
               Z"
            fill="#D92D20"
          />

          {/* South-Eastern Chittagong & Hill Tracts segment */}
          <path
            d="M 58 50 
               C 65 52, 69 57, 65 63 
               C 68 67, 72 72, 68 78 
               C 70 82, 73 88, 69 94 
               C 67 92, 65 86, 64 81 
               C 61 80, 59 75, 62 70 
               L 57 65 
               L 58 58 
               Z"
            fill="#0f6b4f"
          />
        </svg>
      </div>

      {/* Clean Brand Name Typography: WanderBangla */}
      {showText && (
        <div className="flex flex-col leading-tight">
          <div className="flex items-center">
            <span
              className={`text-[#17201c] font-black tracking-tight ${current.text}`}
              style={{ fontFamily: '"Plus Jakarta Sans", sans-serif' }}
            >
              Wander<span className="text-[#0f6b4f]">Bangla</span>
            </span>
          </div>
          <span className={`font-semibold text-slate-500 tracking-normal ${current.sub}`}>
            বাংলাদেশ ভ্রমণ ম্যাপ
          </span>
        </div>
      )}
    </div>
  );
};
