import React, { useState, useMemo, useRef } from 'react';
import { DISTRICTS, District } from '../data/bangladeshData';
import mapData from '../data/bangladeshMapPaths.json';
import { ZoomIn, ZoomOut, RotateCcw, Check, Sparkles } from 'lucide-react';

interface BangladeshMapProps {
  selectedDistricts: Set<string>;
  onToggleDistrict: (districtId: string) => void;
  themeColor: string;
  lang: 'bn' | 'en';
}

interface MapFeature {
  n: string; // English district name e.g. "Natore"
  dv: string; // Division name
  d: string; // SVG path
  c: [number, number]; // Centroid [x, y]
}

export const BangladeshMap: React.FC<BangladeshMapProps> = ({
  selectedDistricts,
  onToggleDistrict,
  themeColor,
  lang,
}) => {
  const [hoveredFeature, setHoveredFeature] = useState<MapFeature | null>(null);
  const [mousePos, setMousePos] = useState<{ x: number; y: number } | null>(null);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [showLabels, setShowLabels] = useState<boolean>(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Map district name to DISTRICTS item
  const districtMapByName = useMemo(() => {
    const map = new Map<string, District>();
    DISTRICTS.forEach((d) => {
      // Normalize name matching
      const norm = d.nameEn.toLowerCase().replace(/[^a-z]/g, '');
      map.set(norm, d);
    });
    return map;
  }, []);

  const getDistrictForFeature = (featureName: string): District | undefined => {
    const norm = featureName.toLowerCase().replace(/[^a-z]/g, '');
    if (norm === 'jhalokati') return districtMapByName.get('jhalokathi');
    if (norm === 'chapainawabganj') return districtMapByName.get('chapainawabganj');
    if (norm === 'kishorganj') return districtMapByName.get('kishoreganj');
    return districtMapByName.get(norm);
  };

  const handleMouseMove = (e: React.MouseEvent<SVGElement>, feature: MapFeature) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    setMousePos({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    });
    setHoveredFeature(feature);
  };

  const hoveredDistrictInfo = hoveredFeature ? getDistrictForFeature(hoveredFeature.n) : undefined;
  const isHoveredVisited = hoveredDistrictInfo ? selectedDistricts.has(hoveredDistrictInfo.id) : false;

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full min-h-[560px] flex flex-col items-center justify-center bg-[#f7f4ed] rounded-2xl overflow-hidden border border-[#ebe6dc] select-none"
    >
      {/* Map Control Tools Bar */}
      <div className="absolute top-3 left-3 z-20 flex items-center gap-1.5 bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-xl shadow-xs border border-slate-200/80">
        <button
          onClick={() => setZoomLevel((prev) => Math.min(prev + 0.2, 2.0))}
          title="Zoom In"
          className="p-1 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
        <button
          onClick={() => setZoomLevel((prev) => Math.max(prev - 0.2, 0.75))}
          title="Zoom Out"
          className="p-1 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
        >
          <ZoomOut className="w-4 h-4" />
        </button>
        <button
          onClick={() => setZoomLevel(1)}
          title="Reset Zoom"
          className="p-1 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        <div className="h-4 w-px bg-slate-200 mx-1" />

        <button
          onClick={() => setShowLabels(!showLabels)}
          className={`text-xs px-2.5 py-0.5 rounded-md font-semibold transition-colors cursor-pointer ${
            showLabels ? 'bg-[#0f6b4f] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          {lang === 'bn' ? (showLabels ? 'নাম দেখাচ্ছে' : 'নাম দেখান') : (showLabels ? 'Labels On' : 'Labels Off')}
        </button>
      </div>

      {/* SVG Canvas Map Container with Original Vector Polygon Boundaries */}
      <div
        className="w-full h-full flex items-center justify-center p-2 sm:p-4 overflow-auto transition-transform duration-200"
        style={{ transform: `scale(${zoomLevel})` }}
      >
        <svg
          viewBox={`0 0 ${mapData.w} ${mapData.h}`}
          className="w-full max-w-[620px] max-h-[820px] drop-shadow-sm transition-all"
          onMouseLeave={() => {
            setHoveredFeature(null);
            setMousePos(null);
          }}
        >
          {/* Render All 64 District Polygons matching Image 2 exactly */}
          {(mapData.f as MapFeature[]).map((feature) => {
            const district = getDistrictForFeature(feature.n);
            const districtId = district ? district.id : feature.n.toLowerCase();
            const isVisited = selectedDistricts.has(districtId);
            const isHovered = hoveredFeature?.n === feature.n;

            // Fill color: Theme color when visited, sand/beige #ded7cb when unvisited
            let fillColor = '#ded7cb';
            if (isVisited) {
              fillColor = themeColor;
            } else if (isHovered) {
              fillColor = '#cfc6b5';
            }

            return (
              <g key={feature.n}>
                <path
                  d={feature.d}
                  fill={fillColor}
                  stroke="#ffffff"
                  strokeWidth="0.85"
                  strokeLinejoin="round"
                  className="cursor-pointer transition-colors duration-150"
                  onClick={() => onToggleDistrict(districtId)}
                  onMouseEnter={(e) => handleMouseMove(e, feature)}
                  onMouseMove={(e) => handleMouseMove(e, feature)}
                />

                {/* Optional centroid label */}
                {showLabels && feature.c && (
                  <text
                    x={feature.c[0]}
                    y={feature.c[1]}
                    textAnchor="middle"
                    dominantBaseline="middle"
                    fill={isVisited ? '#ffffff' : '#4a4439'}
                    fontSize="7.5"
                    fontWeight="700"
                    className="pointer-events-none select-none drop-shadow-2xs"
                  >
                    {lang === 'bn' && district ? district.nameBn : feature.n}
                  </text>
                )}
              </g>
            );
          })}
        </svg>
      </div>

      {/* Floating Tooltip matching Image 2 perfectly */}
      {hoveredFeature && mousePos && (
        <div
          className="absolute z-30 pointer-events-none transition-transform duration-75 ease-out"
          style={{
            left: `${mousePos.x}px`,
            top: `${mousePos.y - 12}px`,
            transform: 'translate(-50%, -100%)',
          }}
        >
          <div className="bg-[#525252]/90 backdrop-blur-md text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-xl flex items-center gap-1.5 border border-white/20 whitespace-nowrap">
            <span>
              {lang === 'bn' && hoveredDistrictInfo ? hoveredDistrictInfo.nameBn : hoveredFeature.n}
            </span>
            {isHoveredVisited && (
              <Check className="w-3.5 h-3.5 text-emerald-300 stroke-[2.5]" />
            )}
          </div>
        </div>
      )}

      {/* Selected District Quick Action Bar at bottom */}
      {hoveredDistrictInfo && (
        <div className="absolute bottom-3 left-4 right-4 sm:left-auto sm:right-4 z-20 bg-white/95 backdrop-blur-md p-3 rounded-2xl shadow-lg border border-slate-200/90 flex items-center justify-between gap-3 min-w-[260px]">
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-sm text-slate-900">
                {lang === 'bn' ? hoveredDistrictInfo.nameBn : hoveredDistrictInfo.nameEn}
              </span>
              <span className="text-xs text-slate-500 font-medium">
                ({hoveredDistrictInfo.divisionBn})
              </span>
            </div>
            <div className="text-[11px] text-slate-500 line-clamp-1">
              {hoveredDistrictInfo.spots.slice(0, 2).join(', ')}
            </div>
          </div>

          <button
            onClick={() => onToggleDistrict(hoveredDistrictInfo.id)}
            className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 shrink-0 ${
              isHoveredVisited
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-[#0f6b4f] hover:text-white'
            }`}
          >
            {isHoveredVisited ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>{lang === 'bn' ? 'ঘুরেছি' : 'Visited'}</span>
              </>
            ) : (
              <span>+ {lang === 'bn' ? 'যোগ করুন' : 'Add'}</span>
            )}
          </button>
        </div>
      )}
    </div>
  );
};
