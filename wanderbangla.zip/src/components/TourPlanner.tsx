import React, { useState, useMemo } from 'react';
import { DISTRICTS, DIVISIONS } from '../data/bangladeshData';
import {
  Calendar,
  Compass,
  MapPin,
  Clock,
  DollarSign,
  Users,
  CheckSquare,
  Square,
  Sparkles,
  Download,
  Share2,
  ChevronRight,
  Luggage,
  Search,
  Check,
  Award,
  Sun,
  Waves,
  Mountain,
  Trees,
  Landmark,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface TourPlannerProps {
  lang: 'bn' | 'en';
}

export interface TourPackage {
  id: string;
  category: 'hill' | 'sea' | 'tea' | 'forest' | 'heritage' | 'river';
  titleBn: string;
  titleEn: string;
  locationBn: string;
  locationEn: string;
  durationBn: string;
  durationEn: string;
  estimatedCostBn: string;
  estimatedCostEn: string;
  bestSeasonBn: string;
  bestSeasonEn: string;
  highlights: string[];
  itinerary: { day: string; title: string; activities: string[] }[];
}

export const FEATURED_TOURS: TourPackage[] = [
  {
    id: 'sajek',
    category: 'hill',
    titleBn: 'মেঘের রাজ্য সাজেক ভ্যালি ৩ দিন ২ রাত ট্যুর',
    titleEn: 'Sajek Valley Cloud Kingdom 3D/2N Tour',
    locationBn: 'খাগড়াছড়ি - সাজেক (রাঙ্গামাটি)',
    locationEn: 'Khagrachhari - Sajek (Rangamati)',
    durationBn: '৩ দিন ২ রাত',
    durationEn: '3 Days 2 Nights',
    estimatedCostBn: '৳৫,৫০০ - ৳৮,০০০ (জনপ্রতি)',
    estimatedCostEn: 'BDT 5,500 - 8,000 (Per Person)',
    bestSeasonBn: 'বর্ষা ও শীতকাল (আগস্ট - ফেব্রুয়ারি)',
    bestSeasonEn: 'Monsoon & Winter (Aug - Feb)',
    highlights: ['রুইলুই পাড়া কটেজ', 'কংলাক পাহাড় চূড়া', 'আলুটিলা গুহা', 'রিছাং ঝর্ণা', 'মেঘের সমুদ্র দর্শন'],
    itinerary: [
      {
        day: '১ম দিন',
        title: 'ঢাকা থেকে খাগড়াছড়ি হয়ে সাজেক যাত্রা',
        activities: ['দীঘিনালা থেকে চান্দের গাড়িতে আর্মি এসকর্ট নিয়ে যাত্রা', 'রুইলুই পাড়ায় কটেজে চেক-ইন', 'কংলাক পাহাড়ে সূর্যাস্ত দর্শন'],
      },
      {
        day: '২য় দিন',
        title: 'সাজেকের মেঘ ও পাহাড়ি জীবন',
        activities: ['ভোরে বারান্দা থেকে মেঘের সমুদ্র উপভোগ', 'স্থানীয় আদিবাসী ঐতিহ্য ও বাঁশের চা টেস্ট', 'হ্যালিপ্যাডে ক্যাম্পফায়ার ও বারবিকিউ'],
      },
      {
        day: '৩য় দিন',
        title: 'আলুটিলা রহস্যময় গুহা ও প্রত্যাবর্তন',
        activities: ['সকালের এসকর্টে খাগড়াছড়ি নামা', 'মশাল জ্বালিয়ে আলুটিলা গুহা অভিযান', 'রিছাং ঝর্ণায় গোসল ও রাতে ঢাকার বাস ধরা'],
      },
    ],
  },
  {
    id: 'coxs-bazar-stmartin',
    category: 'sea',
    titleBn: 'কক্সবাজার ও প্রবাল দ্বীপ সেন্টমার্টিন ৪ দিন ৩ রাত',
    titleEn: "Cox's Bazar & Saint Martin Coral Island 4D/3N",
    locationBn: 'কক্সবাজার - টেকনাফ - সেন্টমার্টিন',
    locationEn: "Cox's Bazar - Teknaf - Saint Martin",
    durationBn: '৪ দিন ৩ রাত',
    durationEn: '4 Days 3 Nights',
    estimatedCostBn: '৳৮,০০০ - ৳১২,০০০ (জনপ্রতি)',
    estimatedCostEn: 'BDT 8,000 - 12,000 (Per Person)',
    bestSeasonBn: 'নভেম্বর - মার্চ (জাহাজ চলাচল মৌসুম)',
    bestSeasonEn: 'November - March',
    highlights: ['বিশ্বের দীর্ঘতম সমুদ্র সৈকত', 'মেরিন ড্রাইভ রোড', 'জাহাজে সেন্টমার্টিন ক্রুজ', 'ছেঁড়া দ্বীপ কোরাল ও সাইক্লিং'],
    itinerary: [
      {
        day: '১ম দিন',
        title: 'কক্সবাজার পৌঁছানো ও ইনানী সৈকত',
        activities: ['হোটেল চেক-ইন ও সৈকতে স্নান', 'মেরিন ড্রাইভ দিয়ে ইনানী পাথুরে বিচ ভ্রমণ', 'লাবণী বিচে সূর্যাস্ত ও সামুদ্রিক মাছের বারবিকিউ'],
      },
      {
        day: '২য় দিন',
        title: 'জাহাজে সেন্টমার্টিন গমন',
        activities: ['টেকনাফ/নুনিয়ারছড়া ঘাট থেকে বিলাসবহুল জাহাজে যাত্রা', 'সেন্টমার্টিন রিসোর্টে চেক-ইন', 'পশ্চিম সৈকতে ডাব খাওয়া ও সূর্যাস্ত উপভোগ'],
      },
      {
        day: '৩য় দিন',
        title: 'ছেঁড়া দ্বীপ অভিযান ও সাইক্লিং',
        activities: ['ভোরে ট্রলার বা স্পিডবোটে ছেঁড়া দ্বীপ ভ্রমণ', 'সৈকতে সাইকেল রাইড ও বারবিকিউ পার্টি'],
      },
      {
        day: '৪র্থ দিন',
        title: 'কক্সবাজার ফেরা ও ঢাকা যাত্রা',
        activities: ['শুটকি ও বার্মিজ মার্কেট শপিং', 'বিকালের জাহাজে টেকনাফ হয়ে রাতে ঢাকা রওয়ানা'],
      },
    ],
  },
  {
    id: 'sylhet-sreemangal',
    category: 'tea',
    titleBn: 'সিলেট-শ্রীমঙ্গল চা বাগান ও সোয়াম্প ফরেস্ট ৩ দিন ২ রাত',
    titleEn: 'Sylhet & Sreemangal Nature & Tea Tour 3D/2N',
    locationBn: 'সিলেট - মৌলভীবাজার',
    locationEn: 'Sylhet - Moulvibazar',
    durationBn: '৩ দিন ২ রাত',
    durationEn: '3 Days 2 Nights',
    estimatedCostBn: '৳৫,০০০ - ৳৭,৫০০ (জনপ্রতি)',
    estimatedCostEn: 'BDT 5,000 - 7,500 (Per Person)',
    bestSeasonBn: 'জুলাই - ফেব্রুয়ারি',
    bestSeasonEn: 'July - February',
    highlights: ['রাতারগুল মিঠাপানির সোয়াম্প ফরেস্ট', 'সাদাপাথর ভোলাগঞ্জ', 'জাফলং', 'শ্রীমঙ্গল চা বাগান ও সাত রঙের চা'],
    itinerary: [
      {
        day: '১ম দিন',
        title: 'রাতারগুল ও ভোলাগঞ্জ সাদাপাথর',
        activities: ['ভোরে নৌকা দিয়ে রাতারগুল বন পরিদর্শন', 'ভোলাগঞ্জ সাদাপাথরের স্বচ্ছ পাহাড়ি জলে স্নান', 'রাতে পাঁচভাই বা পানসিতে সাতকড়া বিফ ডিনার'],
      },
      {
        day: '২য় দিন',
        title: 'জাফলং ও লালাখাল',
        activities: ['জাফলং জিরো পয়েন্ট ও খাসিয়া পুঞ্জি ভ্রমণ', 'লালাখালের পান্না সবুজ জলে বোট রাইড', 'হযরত শাহজালাল (র.) মাজার জিয়ারত'],
      },
      {
        day: '৩য় দিন',
        title: 'শ্রীমঙ্গল চা বাগান ও লাউয়াছড়া রেইনফরেস্ট',
        activities: ['শ্রীমঙ্গলের সবুজ চা বাগানে ফটোসেশন', 'নীলকণ্ঠ কেবিনে বিখ্যাত সাত রঙের চা টেস্ট', 'লাউয়াছড়া জাতীয় উদ্যানে বন্যপ্রাণী ও ট্রেইল হাঁটা'],
      },
    ],
  },
  {
    id: 'sundarbans',
    category: 'forest',
    titleBn: 'সুন্দরবন ম্যানগ্রোভ ওয়াইল্ডলাইফ ক্রুজ ৩ দিন ২ রাত',
    titleEn: 'Sundarbans Mangrove Wildlife Cruise 3D/2N',
    locationBn: 'মংলা - সুন্দরবন (বাগেরহাট/খুলনা)',
    locationEn: 'Mongla - Sundarbans (Bagerhat/Khulna)',
    durationBn: '৩ দিন ২ রাত',
    durationEn: '3 Days 2 Nights',
    estimatedCostBn: '৳১০,০০০ - ৳১৫,০০০ (জনপ্রতি)',
    estimatedCostEn: 'BDT 10,000 - 15,000 (Per Person)',
    bestSeasonBn: 'নভেম্বর - ফেব্রুয়ারি',
    bestSeasonEn: 'November - February',
    highlights: ['বিলাসবহুল ট্যুরিস্ট বোটে থাকা-খাওয়া', 'করমজল কুমির ও হরিণ প্রজনন কেন্দ্র', 'হারবাড়িয়া ইকো ট্রেইল', 'কটকা জামতলা বিচ ও টাইগার পয়েন্ট'],
    itinerary: [
      {
        day: '১ম দিন',
        title: 'মংলা ঘাট থেকে বোট ক্রুজ শুরু',
        activities: ['সকালে মংলা থেকে নৌযানে যাত্রা', 'করমজল ইকো ট্যুরিজম কেন্দ্র ও ওয়াচ টাওয়ার দর্শন', 'হারবাড়িয়া খালের ভেতরে ক্যানেল ক্রুজিং'],
      },
      {
        day: '২য় দিন',
        title: 'গভীর সুন্দরবন ও কটকা সৈকত',
        activities: ['ভোরে নীরব খাঁড়িতে নিঃশব্দ ডিঙি নৌকায় পাখি ও হরিণ দর্শন', 'কটকা অভয়ারণ্যে ট্র্যাকিং ও জামতলা সৈকত ভ্রমণ', 'টাইগার পয়েন্টে ম্যানগ্রোভ অরণ্য পর্যবেক্ষণ'],
      },
      {
        day: '৩য় দিন',
        title: 'কচিখালী ও মংলা প্রত্যাবর্তন',
        activities: ['কচিখালীতে ট্রেইল হাঁটা ও বুনো মহিষ পর্যবেক্ষণ', 'দুধমুখী হয়ে বিকেলে মংলা ফিরে আসা ও ঐতিহ্যবাহী চুইঝাল ডিনার'],
      },
    ],
  },
  {
    id: 'bandarban-nilgiri',
    category: 'hill',
    titleBn: 'বান্দরবান নীলগিরি ও বগালেক রোমাঞ্চ ৩ দিন ২ রাত',
    titleEn: 'Bandarban Nilgiri & Boga Lake Adventure 3D/2N',
    locationBn: 'বান্দরবান - রুমা - থানচি',
    locationEn: 'Bandarban - Ruma - Thanchi',
    durationBn: '৩ দিন ২ রাত',
    durationEn: '3 Days 2 Nights',
    estimatedCostBn: '৳৬,৫০০ - ৳৯,৫০০ (জনপ্রতি)',
    estimatedCostEn: 'BDT 6,500 - 9,500 (Per Person)',
    bestSeasonBn: 'সেপ্টেম্বর - মার্চ',
    bestSeasonEn: 'September - March',
    highlights: ['নীলগিরি রিসোর্ট মেঘের স্পর্শ', 'নীলাচল সূর্যাস্ত পয়েন্ট', 'বগালেক রহস্যময় পাহাড়ি হ্রদ', 'শৈলপ্রপাত ঝর্ণা ও পাহাড়ি ফল'],
    itinerary: [
      {
        day: '১ম দিন',
        title: 'বান্দরবান পৌঁছানো ও নীলগিরি',
        activities: ['চাঁদের গাড়িতে পাহাড়ি আঁকাবাঁকা পথে নীলগিরি যাত্রা', 'মেঘের ওপরে দাঁড়িয়ে চা উপভোগ', 'শৈলপ্রপাত ঝর্ণা ও স্থানীয় উপজাতি বাজার দর্শন'],
      },
      {
        day: '২য় দিন',
        title: 'রুমা বাজার ও বগালেক ক্যাম্পিং',
        activities: ['আর্মি পারমিশন নিয়ে রুমা ঘাট পার হওয়া', 'বগালেকে আদিবাসী কটেজে রাত্রিযাপন', 'লেকের পাড়ে পাহাড়ি বারবিকিউ ও তারা দর্শন'],
      },
      {
        day: '৩য় দিন',
        title: 'নীলাচল ও শহর ভ্রমণ',
        activities: ['নীলাচলে স্বর্ণালী সূর্যাস্ত দর্শন', 'স্বর্ণমন্দির পরিদর্শন', 'রাতে ঢাকার উদ্দেশ্যে বাসে রওয়ানা'],
      },
    ],
  },
  {
    id: 'tanguar-haor',
    category: 'tea',
    titleBn: 'টাঙ্গুয়ার হাওর ও জাদুকাটা নদী হাউসবোট ২ দিন ২ রাত',
    titleEn: 'Tanguar Haor & Jadukata River Houseboat 2D/2N',
    locationBn: 'তাহিরপুর - সুনামগঞ্জ',
    locationEn: 'Tahirpur - Sunamganj',
    durationBn: '২ দিন ২ রাত',
    durationEn: '2 Days 2 Nights',
    estimatedCostBn: '৳৬,০০০ - ৳৯,০০০ (জনপ্রতি)',
    estimatedCostEn: 'BDT 6,000 - 9,000 (Per Person)',
    bestSeasonBn: 'বর্ষাকাল (জুলাই - অক্টোবর)',
    bestSeasonEn: 'Monsoon (July - October)',
    highlights: ['প্রিমিয়াম কাঠের হাউসবোটে রাত্রিযাপন', 'হিজল-করচ বন ও ওয়াচ টাওয়ার', 'জাদুকাটা নদীর স্বচ্ছ জল', 'বারেক টিলা ও শিমুল বাগান'],
    itinerary: [
      {
        day: '১ম দিন',
        title: 'তাহিরপুর ঘাট থেকে হাউসবোটে ভাসমান যাত্রা',
        activities: ['সকালে বোটে চেক-ইন ও দেশীয় সুস্বাদু মাছের লাঞ্চ', 'টাঙ্গুয়ার হাওরে ওয়াচ টাওয়ার পরিদর্শন ও সাঁতার', 'সন্ধ্যায় খোলা ছাদে চাঁদের আলো ও গান'],
      },
      {
        day: '২য় দিন',
        title: 'নীলাদ্রি লেক, জাদুকাটা নদী ও শিমুল বাগান',
        activities: ['শহীদ সিরাজ লেক (নীলাদ্রি) পরিদর্শন', 'জাদুকাটা নদীর নীল পানিতে স্নান', 'বারেক টিলা চূড়ায় মেঘালয় সীমান্ত দর্শন ও রাতে সুনামগঞ্জ ফেরা'],
      },
    ],
  },
  {
    id: 'kuakata',
    category: 'sea',
    titleBn: 'কুয়াকাটা সাগরকন্যা সূর্যোদয় ও সূর্যাস্ত ৩ দিন ২ রাত',
    titleEn: 'Kuakata Daughter of Sea Sunrise & Sunset 3D/2N',
    locationBn: 'পটুয়াখালী - কুয়াকাটা',
    locationEn: 'Patuakhali - Kuakata',
    durationBn: '৩ দিন ২ রাত',
    durationEn: '3 Days 2 Nights',
    estimatedCostBn: '৳৫,০০০ - ৳৮,০০০ (জনপ্রতি)',
    estimatedCostEn: 'BDT 5,000 - 8,000 (Per Person)',
    bestSeasonBn: 'অক্টোবর - এপ্রিল',
    bestSeasonEn: 'October - April',
    highlights: ['একই সৈকত থেকে সূর্যোদয় ও সূর্যাস্ত', 'ঝাউবন ও লাল কাঁকড়ার দ্বীপ', 'গঙ্গামতির চর ও লেম্বুর চর', 'রাখাইন পল্লী ও প্রাচীন সীমা বৌদ্ধ মন্দির'],
    itinerary: [
      {
        day: '১ম দিন',
        title: 'পদ্মা সেতু পার হয়ে কুয়াকাটা আগমন',
        activities: ['বিলাসবহুল এসি বাসে সরাসরি কুয়াকাটা পৌঁছানো', 'বিকেলে প্রধান সৈকতে সূর্যাস্ত উপভোগ', 'রাখাইন মার্কেটে কেনাকাটা ও তাজা মাছ ফ্রাই'],
      },
      {
        day: '২য় দিন',
        title: 'সূর্যোদয় দর্শন ও লাল কাঁকড়ার চর',
        activities: ['ভোরে গঙ্গামতি চরে সূর্যোদয় উপভোগ', 'লেম্বুর বনে সূর্যাস্ত ও কাঁকড়া ফ্রাই টেস্ট', 'মিশ্রিপাড়া প্রাচীন বৌদ্ধ বিহার দর্শন'],
      },
      {
        day: '৩য় দিন',
        title: 'ফাতরার বন ক্রুজ ও ফিরতি পথ',
        activities: ['ইকো বোটে ফাতরার ম্যানগ্রোভ বন ভ্রমণ', 'দুপুরে চেক-আউট ও ঢাকার বাস ধরা'],
      },
    ],
  },
  {
    id: 'sitakunda-chattogram',
    category: 'hill',
    titleBn: 'সীতাকুণ্ড ঝরনা ট্রেইল ও মিরসরাই মহামায়া ২ দিন ১ রাত',
    titleEn: 'Sitakunda Waterfall Trail & Mohamaya 2D/1N',
    locationBn: 'চট্টগ্রাম - সীতাকুণ্ড - মিরসরাই',
    locationEn: 'Chittagong - Sitakunda - Mirsarai',
    durationBn: '২ দিন ১ রাত',
    durationEn: '2 Days 1 Night',
    estimatedCostBn: '৳৩,৫০০ - ৳৫,৫০০ (জনপ্রতি)',
    estimatedCostEn: 'BDT 3,500 - 5,500 (Per Person)',
    bestSeasonBn: 'বর্ষা ও শরৎকাল (জুলাই - নভেম্বর)',
    bestSeasonEn: 'Monsoon & Autumn (July - Nov)',
    highlights: ['চন্দ্রনাথ পাহাড় চূড়া ট্র্যাকিং', 'খৈয়াছড়া বহু ধাপের ঝর্ণা', 'মহামায়া লেকে কায়াকিং', 'গুলিয়াখালী সবুজ ঘাসের সমুদ্র সৈকত'],
    itinerary: [
      {
        day: '১ম দিন',
        title: 'চন্দ্রনাথ পাহাড় সামিট ও গুলিয়াখালী বিচ',
        activities: ['ভোরে সীতাকুণ্ড নেমে চন্দ্রনাথ পাহাড়ে পাহাড়ি ট্র্যাকিং', 'দুপুরে গুলিয়াখালী সবুজ ম্যানগ্রোভ বিচে সূর্যাস্ত দর্শন'],
      },
      {
        day: '২য় দিন',
        title: 'খৈয়াছড়া ঝর্ণা ও মহামায়া কায়াকিং',
        activities: ['খৈয়াছড়ার রোমাঞ্চকর পাহাড়ি ঝর্ণায় অবগাহন', 'মহামায়া লেকে কায়াকিং ও গুহা ভ্রমণ', 'রাতে ট্রেন বা বাসে ঢাকায় প্রত্যাবর্তন'],
      },
    ],
  },
  {
    id: 'north-bengal',
    category: 'heritage',
    titleBn: 'উত্তরবঙ্গ প্রাচীন প্রত্নতত্ত্ব ও জমিদার প্রাসাদ ৩ দিন ২ রাত',
    titleEn: 'North Bengal Archaeology & Historic Palaces 3D/2N',
    locationBn: 'বগুড়া - নওগাঁ - নাটোর - রাজশাহী',
    locationEn: 'Bogura - Naogaon - Natore - Rajshahi',
    durationBn: '৩ দিন ২ রাত',
    durationEn: '3 Days 2 Nights',
    estimatedCostBn: '৳৫,৫০০ - ৳৮,৫০০ (জনপ্রতি)',
    estimatedCostEn: 'BDT 5,500 - 8,500 (Per Person)',
    bestSeasonBn: 'অক্টোবর - মার্চ',
    bestSeasonEn: 'October - March',
    highlights: ['মহাস্থানগড় প্রাচীন পুণ্ড্রনগরী', 'পাহাড়পুর সোমপুর বৌদ্ধ মহাবিহার (UNESCO)', 'উত্তরা গণভবন ও নাটোর রাজবাড়ি', 'বাঘা মসজিদ ও পদ্মার পাড়'],
    itinerary: [
      {
        day: '১ম দিন',
        title: 'বগুড়া মহাস্থানগড় ও দই ভোজ',
        activities: ['মহাস্থানগড়ের বেহুলা লক্ষ্মীন্দরের বাসর ঘর ও জাদুঘর দর্শন', 'বিখ্যাত বগুড়ার আসল খই ও দই টেস্ট'],
      },
      {
        day: '২য় দিন',
        title: 'ইউনেস্কো পাহাড়পুর মহাবিহার ও কুসুম্বা মসজিদ',
        activities: ['পাহাড়পুর বৌদ্ধবিহারের স্থাপত্যশিল্প অবলোকন', 'নওগাঁর পাথুরে কুসুম্বা মসজিদ দর্শন'],
      },
      {
        day: '৩য় দিন',
        title: 'নাটোরের কাঁচাগোল্লা ও পদ্মা গার্ডেন',
        activities: ['উত্তরা গণভবনের রাজকীয় উদ্যান পরিদর্শন', 'রাজশাহীর পদ্মার পাড়ে সূর্যাস্ত ও ঢাকামুখী যাত্রা'],
      },
    ],
  },
  {
    id: 'barishal-backwaters',
    category: 'river',
    titleBn: 'বরিশাল ব্যাকওয়াটার ও ভাসমান পেয়ারা বাজার ২ দিন ১ রাত',
    titleEn: 'Barishal Backwaters & Floating Guava Market 2D/1N',
    locationBn: 'বরিশাল - ঝালকাঠি - পিরোজপুর',
    locationEn: 'Barishal - Jhalokathi - Pirojpur',
    durationBn: '২ দিন ১ রাত',
    durationEn: '2 Days 1 Night',
    estimatedCostBn: '৳৩,৮০০ - ৳৫,৮০০ (জনপ্রতি)',
    estimatedCostEn: 'BDT 3,800 - 5,800 (Per Person)',
    bestSeasonBn: 'বর্ষাকাল (জুলাই - সেপ্টেম্বর)',
    bestSeasonEn: 'Monsoon (July - September)',
    highlights: ['ভিমরুলী খালের ভাসমান পেয়ারা বাজার', 'সবুজ খালের ভেতরে ডিঙি নৌকা ভ্রমণ', 'গুঠিয়া জামে মসজিদ ও দুর্গাসাগর দীঘি', 'ঐতিহ্যবাহী লঞ্চ কেবিন ক্রুজ'],
    itinerary: [
      {
        day: '১ম দিন',
        title: 'লঞ্চে বরিশাল পৌঁছানো ও পেয়ারা বাজার',
        activities: ['সকালে সদরঘাট লঞ্চযোগে বরিশাল পৌঁছে ট্রলারে যাত্রা', 'ভিমরুলী ভাসমান পেয়ারা বাজারে টাটকা পেয়ারা ও মিষ্টি ফল কেনা', 'গ্রামের মিষ্টি পানির খালে স্নান'],
      },
      {
        day: '২য় দিন',
        title: 'গুঠিয়া মসজিদ ও বরিশাল শহর দর্শন',
        activities: ['বিশাল গুঠিয়া মসজিদ কমপ্লেক্স পরিদর্শন', 'দুর্গাসাগর দীঘিতে পাখি দর্শন', 'রাতে বিলাসবহুল লঞ্চে ঢাকার উদ্দেশ্যে যাত্রা'],
      },
    ],
  },
];

export const TourPlanner: React.FC<TourPlannerProps> = ({ lang }) => {
  const [selectedTour, setSelectedTour] = useState<TourPackage>(FEATURED_TOURS[0]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Custom Tour Builder State
  const [customDestination, setCustomDestination] = useState<string>('coxs-bazar');
  const [districtSearch, setDistrictSearch] = useState<string>('');
  const [selectedDivision, setSelectedDivision] = useState<string>('all');
  const [travelersCount, setTravelersCount] = useState<number>(2);
  const [tourDays, setTourDays] = useState<number>(3);
  const [tourType, setTourType] = useState<'budget' | 'standard' | 'luxury'>('standard');

  // Interactive Checklist State
  const [checklist, setChecklist] = useState<Record<string, boolean>>({
    nid: true,
    powerbank: true,
    firstaid: false,
    camera: false,
    clothes: true,
    cash: true,
    tickets: true,
    umbrella: false,
  });

  const toggleChecklistItem = (key: string) => {
    setChecklist((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // Filtered tours for the selection UI
  const filteredTours = useMemo(() => {
    return FEATURED_TOURS.filter((tour) => {
      const matchesCategory = selectedCategory === 'all' || tour.category === selectedCategory;
      if (!matchesCategory) return false;
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase().trim();
      return (
        tour.titleBn.toLowerCase().includes(q) ||
        tour.titleEn.toLowerCase().includes(q) ||
        tour.locationBn.toLowerCase().includes(q) ||
        tour.locationEn.toLowerCase().includes(q)
      );
    });
  }, [searchQuery, selectedCategory]);

  // Filtered districts for the custom tour destination selection UI
  const filteredDistricts = useMemo(() => {
    return DISTRICTS.filter((d) => {
      const matchesDiv = selectedDivision === 'all' || d.divisionBn === selectedDivision || d.divisionEn === selectedDivision;
      if (!matchesDiv) return false;
      if (!districtSearch.trim()) return true;
      const q = districtSearch.toLowerCase().trim();
      return (
        d.nameBn.toLowerCase().includes(q) ||
        d.nameEn.toLowerCase().includes(q) ||
        d.divisionBn.toLowerCase().includes(q) ||
        d.divisionEn.toLowerCase().includes(q) ||
        d.spots.some((s) => s.toLowerCase().includes(q))
      );
    });
  }, [districtSearch, selectedDivision]);

  // Estimated Cost calculation for custom plan
  const costMultiplier = tourType === 'budget' ? 1800 : tourType === 'standard' ? 3200 : 5500;
  const estimatedTotalCost = travelersCount * tourDays * costMultiplier;
  const targetDistrict = DISTRICTS.find((d) => d.id === customDestination) || DISTRICTS[0];

  const handleDownloadPlan = () => {
    confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    alert(
      lang === 'bn'
        ? `"${selectedTour.titleBn}" এর ট্যুর প্ল্যান সফলভাবে সংরক্ষণ হয়েছে!`
        : `"${selectedTour.titleEn}" tour plan saved successfully!`
    );
  };

  return (
    <div className="space-y-8 animate-fadeIn max-w-6xl mx-auto">
      {/* Top Banner */}
      <div className="text-center pt-2 pb-2">
        <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#e8f5e9] text-[#006042] border border-[#c8e6c9] text-xs font-bold mb-3 shadow-2xs">
          <Compass className="w-3.5 h-3.5 text-[#005a3c]" />
          <span>{lang === 'bn' ? '১০টি প্রিমিয়াম ট্যুর প্ল্যান • সম্পূর্ণ বাজেট ও সূচি' : '10 Curated Tour Plans • Budget & Route'}</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight">
          <span className="text-[#17201c]">{lang === 'bn' ? 'বাংলাদেশ ' : 'Bangladesh '}</span>
          <span className="text-[#005a3c]">{lang === 'bn' ? 'ট্যুর প্ল্যানার' : 'Tour Planner'}</span>
        </h1>

        <p className="text-slate-600 text-xs sm:text-sm max-w-xl mx-auto mt-2 leading-relaxed">
          {lang === 'bn'
            ? 'পছন্দের ট্যুর প্ল্যানটি বেছে নিন অথবা ৬৪ জেলার মধ্য থেকে নিজের গন্তব্য নির্বাচন করে কাস্টম বাজেট হিসাব করুন।'
            : 'Select a curated tour itinerary or pick your preferred destination from 64 districts to calculate custom budget.'}
        </p>
      </div>

      {/* ============================================================== */}
      {/* 1. TOUR PLAN SELECTION CARD (Exact photo design: 2-cols, circular checkbox, search, badges) */}
      {/* ============================================================== */}
      <div className="bg-white border border-[#ebe6dc] rounded-2xl p-5 shadow-xs">
        {/* Header Row: [ট্যুর প্ল্যান বাছাই করুন] ... [১/১০ টি প্ল্যান] */}
        <div className="flex items-center justify-between gap-3 mb-2">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#005a3c]" />
            <h3 className="text-base font-extrabold text-slate-900">
              {lang === 'bn' ? 'ট্যুর প্ল্যান বাছাই করুন' : 'Select Tour Plan'}
            </h3>
          </div>

          {/* Counter Badge */}
          <div className="bg-[#e8f5e9] text-[#005a3c] font-black text-xs px-3 py-1 rounded-full border border-[#c8e6c9]">
            {filteredTours.findIndex((t) => t.id === selectedTour.id) !== -1 ? '১' : '০'}/{FEATURED_TOURS.length} {lang === 'bn' ? 'টি প্ল্যান' : 'Plans'}
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-2 text-xs">
          {[
            { id: 'all', labelBn: 'সকল ট্যুর (১০)', labelEn: 'All Tours' },
            { id: 'hill', labelBn: 'পাহাড় ও মেঘ', labelEn: 'Hills & Clouds' },
            { id: 'sea', labelBn: 'সমুদ্র ও দ্বীপ', labelEn: 'Sea & Islands' },
            { id: 'tea', labelBn: 'চা বাগান ও হাওর', labelEn: 'Tea & Haor' },
            { id: 'forest', labelBn: 'ম্যানগ্রোভ ও বন', labelEn: 'Forest & Safari' },
            { id: 'heritage', labelBn: 'ঐতিহ্য ও প্রত্নতত্ত্ব', labelEn: 'Heritage' },
            { id: 'river', labelBn: 'নদ-নদী ও ব্যাকওয়াটার', labelEn: 'River' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                selectedCategory === cat.id
                  ? 'bg-[#005a3c] text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {lang === 'bn' ? cat.labelBn : cat.labelEn}
            </button>
          ))}
        </div>

        {/* Search Input Box */}
        <div className="relative mb-2">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={lang === 'bn' ? 'ট্যুর বা জেলা খুঁজুন: সাজেক, সেন্টমার্টিন, সুন্দরবন, বান্দরবান...' : 'Search tour: Sajek, Saint Martin, Sundarbans...'}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9.5 pr-4 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#005a3c] focus:bg-white"
          />
        </div>

        {/* Subtitle helper */}
        <p className="text-[11px] text-slate-500 mb-3">
          {lang === 'bn'
            ? '১০টি জনপ্রিয় রেডিমেড ট্যুর প্ল্যান। ক্লিক করে বেছে নিন এবং নিচে বিস্তারিত সূচি দেখুন।'
            : '10 curated tour itineraries. Click to select and view detailed schedule below.'}
        </p>

        {/* Scrollable 2-Column Grid of Tours (Identical to destination selection in photo) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-[420px] overflow-y-auto pr-1">
          {filteredTours.map((tour) => {
            const isChecked = selectedTour.id === tour.id;
            return (
              <div
                key={tour.id}
                onClick={() => {
                  setSelectedTour(tour);
                  confetti({ particleCount: 30, spread: 60, origin: { y: 0.7 } });
                }}
                className={`p-3 rounded-xl border flex items-center gap-3 transition-all cursor-pointer ${
                  isChecked
                    ? 'bg-emerald-50/70 border-[#005a3c] shadow-xs ring-1 ring-[#005a3c]/30'
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                {/* Circular Checkbox/Radio Indicator */}
                <div
                  className={`w-4.5 h-4.5 rounded-full border-2 flex items-center justify-center shrink-0 transition-all ${
                    isChecked
                      ? 'bg-[#005a3c] border-[#005a3c] text-white'
                      : 'border-slate-300 bg-white'
                  }`}
                >
                  {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                </div>

                {/* Tour Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-xs font-bold text-slate-900 truncate">
                      {lang === 'bn' ? tour.titleBn : tour.titleEn}
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-2 mt-0.5">
                    <span className="text-[11px] text-slate-500 truncate">
                      {lang === 'bn' ? tour.locationBn : tour.locationEn}
                    </span>
                    <span className="text-[10px] font-black text-[#005a3c] bg-emerald-100/80 px-2 py-0.5 rounded-full shrink-0">
                      {lang === 'bn' ? tour.durationBn : tour.durationEn}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ============================================================== */}
      {/* 2. SELECTED TOUR DETAILS & DAY-BY-DAY ITINERARY CARD */}
      {/* ============================================================== */}
      <div className="bg-[#faf8f4] border border-[#ebe6dc] rounded-2xl p-5 sm:p-7 shadow-xs">
        {/* Top Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#ebe6dc]">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-bold text-[#005a3c] mb-1">
              <MapPin className="w-3.5 h-3.5" />
              <span>{lang === 'bn' ? selectedTour.locationBn : selectedTour.locationEn}</span>
              <span>•</span>
              <span>{lang === 'bn' ? selectedTour.durationBn : selectedTour.durationEn}</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              {lang === 'bn' ? selectedTour.titleBn : selectedTour.titleEn}
            </h3>
            <div className="text-xs text-slate-500 mt-1 flex items-center gap-2">
              <Sun className="w-3.5 h-3.5 text-amber-500" />
              <span>
                {lang === 'bn' ? `সেরা মৌসুম: ${selectedTour.bestSeasonBn}` : `Best Season: ${selectedTour.bestSeasonEn}`}
              </span>
            </div>
          </div>

          {/* Cost Badge & Actions */}
          <div className="flex items-center gap-3">
            <div className="bg-white border border-slate-200 px-4 py-2 rounded-xl text-right">
              <div className="text-[10px] text-slate-400 font-bold uppercase">
                {lang === 'bn' ? 'আনুমানিক বাজেট' : 'Est. Budget'}
              </div>
              <div className="text-sm sm:text-base font-black text-[#005a3c]">
                {lang === 'bn' ? selectedTour.estimatedCostBn : selectedTour.estimatedCostEn}
              </div>
            </div>

            <button
              onClick={handleDownloadPlan}
              className="bg-[#005a3c] hover:bg-[#004730] text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{lang === 'bn' ? 'প্ল্যান সংরক্ষণ' : 'Save Plan'}</span>
            </button>
          </div>
        </div>

        {/* Highlights */}
        <div className="py-4">
          <div className="text-xs font-bold text-slate-700 mb-2">
            {lang === 'bn' ? 'ট্যুরের বিশেষ আকর্ষণসমূহ:' : 'Tour Highlights:'}
          </div>
          <div className="flex flex-wrap gap-2">
            {selectedTour.highlights.map((h, i) => (
              <span
                key={i}
                className="text-xs bg-white border border-[#ebe6dc] px-3 py-1 rounded-full text-slate-700 font-medium flex items-center gap-1 shadow-2xs"
              >
                <CheckCircle2 className="w-3 h-3 text-[#005a3c]" />
                <span>{h}</span>
              </span>
            ))}
          </div>
        </div>

        {/* Day by Day Plan */}
        <div className="pt-2">
          <div className="text-xs font-bold text-slate-700 mb-3">
            {lang === 'bn' ? 'দিনভিত্তিক পূর্ণাঙ্গ ভ্রমণ সূচি:' : 'Day-by-Day Itinerary:'}
          </div>
          <div className="space-y-3">
            {selectedTour.itinerary.map((dayItem, idx) => (
              <div
                key={idx}
                className="bg-white border border-[#ebe6dc] p-4 rounded-xl flex flex-col sm:flex-row sm:items-start gap-3 shadow-2xs"
              >
                <span className="text-xs font-black bg-[#005a3c] text-white px-3 py-1 rounded-lg shrink-0 self-start shadow-2xs">
                  {dayItem.day}
                </span>
                <div className="flex-1">
                  <h5 className="font-bold text-sm text-slate-900">{dayItem.title}</h5>
                  <ul className="mt-2 space-y-1.5">
                    {dayItem.activities.map((act, actIdx) => (
                      <li key={actIdx} className="text-xs text-slate-600 flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#005a3c] shrink-0" />
                        <span>{act}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ============================================================== */}
      {/* 3. CUSTOM TOUR BUILDER & BUDGET CALCULATOR */}
      {/* ============================================================== */}
      <div className="bg-white border border-[#ebe6dc] rounded-2xl p-5 sm:p-7 shadow-xs">
        <div className="mb-5">
          <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
            <Luggage className="w-5 h-5 text-[#005a3c]" />
            <span>{lang === 'bn' ? 'কাস্টম ট্যুর তৈরি করুন ও বাজেট হিসাব করুন' : 'Custom Tour Builder & Budget Estimator'}</span>
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            {lang === 'bn'
              ? '৬৪ জেলার মধ্য থেকে আপনার গন্তব্য বেছে নিন, ভ্রমণসঙ্গী ও দিনের সংখ্যা দিয়ে লাইভ বাজেট দেখুন।'
              : 'Pick your destination from 64 districts, adjust travelers and days for instant live estimate.'}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Destination Picker Selection Cards (7 COLS - Matches Photo Design) */}
          <div className="lg:col-span-7 bg-[#faf8f4] border border-[#ebe6dc] p-4 sm:p-5 rounded-2xl space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold text-slate-800">
                  {lang === 'bn' ? 'গন্তব্য জেলা বাছাই করুন:' : 'Select Destination District:'}
                </label>
                <span className="text-[11px] text-[#005a3c] font-black">
                  {targetDistrict.nameBn} ({targetDistrict.divisionBn})
                </span>
              </div>

              {/* Division filter pills */}
              <div className="flex items-center gap-1 overflow-x-auto pb-1.5 mb-2 text-xs">
                <button
                  onClick={() => setSelectedDivision('all')}
                  className={`px-2.5 py-1 rounded-full text-[11px] font-bold cursor-pointer whitespace-nowrap transition-all ${
                    selectedDivision === 'all'
                      ? 'bg-[#005a3c] text-white shadow-2xs'
                      : 'bg-white border border-slate-200 text-slate-600'
                  }`}
                >
                  {lang === 'bn' ? 'সব বিভাগ' : 'All'}
                </button>
                {Object.values(DIVISIONS).map((div) => (
                  <button
                    key={div.nameBn}
                    onClick={() => setSelectedDivision(div.nameBn)}
                    className={`px-2.5 py-1 rounded-full text-[11px] font-bold cursor-pointer whitespace-nowrap transition-all ${
                      selectedDivision === div.nameBn
                        ? 'bg-[#005a3c] text-white shadow-2xs'
                        : 'bg-white border border-slate-200 text-slate-600'
                    }`}
                  >
                    {lang === 'bn' ? div.nameBn : div.nameEn}
                  </button>
                ))}
              </div>

              {/* Search District */}
              <div className="relative mb-2">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={districtSearch}
                  onChange={(e) => setDistrictSearch(e.target.value)}
                  placeholder={lang === 'bn' ? 'জেলা বা আকর্ষণ খুঁজুন: কক্সবাজার, বান্দরবান, মৌলভীবাজার...' : 'Search district: Coxs Bazar, Bandarban...'}
                  className="w-full bg-white border border-slate-200 rounded-xl pl-8.5 pr-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-[#005a3c]"
                />
              </div>

              {/* 2-Column Districts Grid (Identical to Photo Selection Cards) */}
              <div className="grid grid-cols-2 gap-2 max-h-[220px] overflow-y-auto pr-1">
                {filteredDistricts.map((d) => {
                  const isChecked = customDestination === d.id;
                  return (
                    <div
                      key={d.id}
                      onClick={() => setCustomDestination(d.id)}
                      className={`p-2 rounded-xl border flex items-center gap-2 transition-all cursor-pointer ${
                        isChecked
                          ? 'bg-emerald-50/70 border-[#005a3c] shadow-2xs ring-1 ring-[#005a3c]/30'
                          : 'bg-white border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded-full border-2 flex items-center justify-center shrink-0 transition-all ${
                          isChecked
                            ? 'bg-[#005a3c] border-[#005a3c] text-white'
                            : 'border-slate-300 bg-white'
                        }`}
                      >
                        {isChecked && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                      </div>
                      <div className="truncate">
                        <div className="text-xs font-bold text-slate-900 truncate">
                          {d.nameBn}
                        </div>
                        <div className="text-[10px] text-slate-400 font-medium truncate">
                          {d.spots[0]}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Days & Travelers Controls */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'bn' ? 'ভ্রমণের দিন:' : 'Number of Days:'}
                </label>
                <div className="flex items-center gap-2 bg-white border border-[#ebe6dc] rounded-xl p-1 shadow-2xs">
                  <button
                    onClick={() => setTourDays(Math.max(1, tourDays - 1))}
                    className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold flex items-center justify-center cursor-pointer"
                  >
                    -
                  </button>
                  <span className="flex-1 text-center font-bold text-xs text-slate-800">
                    {tourDays} {lang === 'bn' ? 'দিন' : 'Days'}
                  </span>
                  <button
                    onClick={() => setTourDays(Math.min(10, tourDays + 1))}
                    className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold flex items-center justify-center cursor-pointer"
                  >
                    +
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'bn' ? 'ভ্রমণসঙ্গী (মানুষ):' : 'Travelers Count:'}
                </label>
                <div className="flex items-center gap-2 bg-white border border-[#ebe6dc] rounded-xl p-1 shadow-2xs">
                  <button
                    onClick={() => setTravelersCount(Math.max(1, travelersCount - 1))}
                    className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold flex items-center justify-center cursor-pointer"
                  >
                    -
                  </button>
                  <span className="flex-1 text-center font-bold text-xs text-slate-800">
                    {travelersCount} {lang === 'bn' ? 'জন' : 'Persons'}
                  </span>
                  <button
                    onClick={() => setTravelersCount(Math.min(20, travelersCount + 1))}
                    className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold flex items-center justify-center cursor-pointer"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>

            {/* Tour Comfort Type */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {lang === 'bn' ? 'ভ্রমণের ধরন ও স্ট্যান্ডার্ড:' : 'Travel Style:'}
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'budget', labelBn: 'বাজেট ব্যাকপ্যাকার', labelEn: 'Budget' },
                  { id: 'standard', labelBn: 'স্ট্যান্ডার্ড রিসোর্ট', labelEn: 'Standard' },
                  { id: 'luxury', labelBn: 'লাক্সারি ও প্রিমিয়াম', labelEn: 'Luxury' },
                ].map((type) => (
                  <button
                    key={type.id}
                    onClick={() => setTourType(type.id as any)}
                    className={`py-2 px-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      tourType === type.id
                        ? 'bg-[#005a3c] text-white border-[#005a3c] shadow-xs'
                        : 'bg-white text-slate-700 border-[#ebe6dc] hover:border-slate-300'
                    }`}
                  >
                    {lang === 'bn' ? type.labelBn : type.labelEn}
                  </button>
                ))}
              </div>
            </div>

            {/* Estimated Calculation Summary Card */}
            <div className="p-4 bg-white rounded-xl border border-[#ebe6dc] flex items-center justify-between shadow-2xs">
              <div>
                <span className="text-xs text-slate-500 font-medium">
                  {lang === 'bn' ? 'মোট আনুমানিক বাজেট:' : 'Total Est. Budget:'}
                </span>
                <div className="text-xl font-black text-[#005a3c]">
                  ৳{estimatedTotalCost.toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}
                </div>
                <div className="text-[10px] text-slate-400">
                  {lang === 'bn'
                    ? `(${travelersCount} জনের জন্য ${tourDays} দিন, জনপ্রতি ~৳${(costMultiplier * tourDays).toLocaleString('bn-BD')})`
                    : `(${travelersCount} persons for ${tourDays} days, ~৳${(costMultiplier * tourDays).toLocaleString('en-US')} per person)`}
                </div>
              </div>
              <button
                onClick={() => {
                  confetti({ particleCount: 60, spread: 60, origin: { y: 0.7 } });
                  alert(lang === 'bn' ? 'কাস্টম ট্যুর প্ল্যান সেভ হয়েছে!' : 'Custom Tour Plan Saved!');
                }}
                className="bg-[#005a3c] hover:bg-[#004730] text-white font-bold text-xs px-4 py-2.5 rounded-xl transition-colors cursor-pointer shadow-xs"
              >
                {lang === 'bn' ? 'প্ল্যান সেভ করুন' : 'Save Plan'}
              </button>
            </div>
          </div>

          {/* Packing Checklist (5 COLS) */}
          <div className="lg:col-span-5 bg-[#faf8f4] border border-[#ebe6dc] p-4 sm:p-5 rounded-2xl">
            <h4 className="text-xs font-black text-slate-900 mb-3 flex items-center gap-1.5">
              <CheckSquare className="w-4 h-4 text-[#005a3c]" />
              <span>{lang === 'bn' ? 'ট্যুর প্যাকিং চেকলিস্ট' : 'Tour Packing Checklist'}</span>
            </h4>

            <div className="space-y-2">
              {[
                { key: 'nid', labelBn: 'জাতীয় পরিচয়পত্র (NID) বা জন্মনিবন্ধন', labelEn: 'NID or Passport Copy' },
                { key: 'tickets', labelBn: 'বাস/ট্রেন/লঞ্চ টিকিট ও হোটেল বুকিং', labelEn: 'Tickets & Booking Voucher' },
                { key: 'powerbank', labelBn: 'পাওয়ার ব্যাংক ও চার্জার ক্যাবল', labelEn: 'Power Bank & Cables' },
                { key: 'cash', labelBn: 'জরুরি নগদ ক্যাশ টাকা (হাতে ক্যাশ)', labelEn: 'Emergency Cash in Hand' },
                { key: 'firstaid', labelBn: 'ফার্স্ট এইড ব্যান্ডেজ ও দরকারি ওষুধ', labelEn: 'First-aid & Medications' },
                { key: 'camera', labelBn: 'ক্যামেরা বা মোবাইল সানগ্লাস', labelEn: 'Camera & Sunglasses' },
                { key: 'clothes', labelBn: 'আরামদায়ক ট্র্যাকিং জুতো ও পোশাক', labelEn: 'Trekking shoes & Clothes' },
                { key: 'umbrella', labelBn: 'ছাতা বা রেইনকোট / পানির বোতল', labelEn: 'Umbrella & Water Bottle' },
              ].map((item) => (
                <button
                  key={item.key}
                  onClick={() => toggleChecklistItem(item.key)}
                  className="w-full flex items-center gap-2.5 p-2 rounded-lg bg-white border border-[#ebe6dc] text-left hover:bg-slate-50 transition-colors cursor-pointer shadow-2xs"
                >
                  {checklist[item.key] ? (
                    <CheckSquare className="w-4 h-4 text-[#005a3c] shrink-0" />
                  ) : (
                    <Square className="w-4 h-4 text-slate-300 shrink-0" />
                  )}
                  <span
                    className={`text-xs ${
                      checklist[item.key] ? 'line-through text-slate-400 font-normal' : 'text-slate-700 font-semibold'
                    }`}
                  >
                    {lang === 'bn' ? item.labelBn : item.labelEn}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
