import React from 'react';

interface SimCompanyLogoProps {
  operatorId: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
}

export const SimCompanyLogo: React.FC<SimCompanyLogoProps> = ({
  operatorId,
  size = 'md',
  showText = true,
  className = '',
}) => {
  const sizeMap = {
    sm: { icon: 'w-7 h-7', text: 'text-xs', container: 'p-1.5' },
    md: { icon: 'w-10 h-10', text: 'text-sm', container: 'p-2' },
    lg: { icon: 'w-14 h-14', text: 'text-base', container: 'p-2.5' },
    xl: { icon: 'w-16 h-16', text: 'text-lg', container: 'p-3' },
  };

  const currentSize = sizeMap[size] || sizeMap.md;

  switch (operatorId) {
    case 'grameenphone':
      return (
        <div className={`flex items-center gap-2.5 ${className}`}>
          {/* GP Emblem: Iconic 3-blade propeller / pinwheel in Telenor Blue */}
          <div
            className={`${currentSize.icon} shrink-0 rounded-xl bg-gradient-to-tr from-[#005a96] via-[#0070BA] to-[#00A3E0] p-1.5 shadow-sm flex items-center justify-center`}
            title="Grameenphone (GP)"
          >
            <svg viewBox="0 0 100 100" className="w-full h-full" fill="none">
              <defs>
                <linearGradient id="gpBlade1" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#FFFFFF" />
                  <stop offset="100%" stopColor="#8BE0FF" />
                </linearGradient>
                <linearGradient id="gpBlade2" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#C4EFFF" />
                  <stop offset="100%" stopColor="#38B6FF" />
                </linearGradient>
                <linearGradient id="gpBlade3" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#FFFFFF" />
                  <stop offset="100%" stopColor="#00A3E0" />
                </linearGradient>
              </defs>
              {/* Petal 1 - Top Right */}
              <path
                d="M50 48 C 45 22, 68 8, 86 16 C 94 28, 82 48, 50 48 Z"
                fill="url(#gpBlade1)"
                filter="drop-shadow(0px 2px 3px rgba(0,0,0,0.2))"
              />
              {/* Petal 2 - Bottom Right */}
              <path
                d="M48 52 C 40 76, 56 94, 76 90 C 88 80, 82 58, 48 52 Z"
                fill="url(#gpBlade2)"
                filter="drop-shadow(0px 2px 3px rgba(0,0,0,0.2))"
              />
              {/* Petal 3 - Left */}
              <path
                d="M47 48 C 22 45, 8 64, 14 82 C 28 90, 48 76, 47 48 Z"
                fill="url(#gpBlade3)"
                filter="drop-shadow(0px 2px 3px rgba(0,0,0,0.2))"
              />
              {/* Center Dot */}
              <circle cx="49" cy="50" r="4.5" fill="#FFFFFF" />
            </svg>
          </div>
          {showText && (
            <div className="leading-tight">
              <span className={`font-black text-[#0070BA] tracking-tight block ${currentSize.text}`}>
                grameenphone
              </span>
              <span className="text-[10px] text-slate-500 font-bold block uppercase tracking-wider">
                GP 4G • Telenor
              </span>
            </div>
          )}
        </div>
      );

    case 'robi':
      return (
        <div className={`flex items-center gap-2.5 ${className}`}>
          {/* Robi Emblem: Iconic origami faceted ruby / bird */}
          <div
            className={`${currentSize.icon} shrink-0 rounded-xl bg-gradient-to-tr from-[#990000] via-[#D31117] to-[#FF3B30] p-1.5 shadow-sm flex items-center justify-center`}
            title="Robi Axiata"
          >
            <svg viewBox="0 0 100 100" className="w-full h-full" fill="none">
              <defs>
                <linearGradient id="robiFacet1" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#FFA100" />
                  <stop offset="100%" stopColor="#FF3B30" />
                </linearGradient>
                <linearGradient id="robiFacet2" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#FFFFFF" />
                  <stop offset="100%" stopColor="#FFC247" />
                </linearGradient>
                <linearGradient id="robiFacet3" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#C40008" />
                  <stop offset="100%" stopColor="#870006" />
                </linearGradient>
              </defs>
              {/* Origami Prism Facets */}
              <polygon points="50,12 84,38 50,60" fill="url(#robiFacet1)" />
              <polygon points="50,12 16,38 50,60" fill="url(#robiFacet2)" />
              <polygon points="50,60 84,38 72,82" fill="#E60000" />
              <polygon points="50,60 16,38 28,82" fill="#B30006" />
              <polygon points="50,60 72,82 50,88" fill="url(#robiFacet3)" />
              <polygon points="50,60 28,82 50,88" fill="#800004" />
            </svg>
          </div>
          {showText && (
            <div className="leading-tight">
              <span className={`font-black text-[#D31117] tracking-tight block ${currentSize.text}`}>
                robi
              </span>
              <span className="text-[10px] text-slate-500 font-bold block uppercase tracking-wider">
                Axiata Group
              </span>
            </div>
          )}
        </div>
      );

    case 'banglalink':
      return (
        <div className={`flex items-center gap-2.5 ${className}`}>
          {/* Banglalink Emblem: Tiger stripe energetic orange swoosh */}
          <div
            className={`${currentSize.icon} shrink-0 rounded-xl bg-gradient-to-tr from-[#E65100] via-[#FF6600] to-[#FFA726] p-1.5 shadow-sm flex items-center justify-center`}
            title="Banglalink"
          >
            <svg viewBox="0 0 100 100" className="w-full h-full" fill="none">
              <defs>
                <linearGradient id="blCurve1" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#FFFFFF" />
                  <stop offset="100%" stopColor="#FFE082" />
                </linearGradient>
                <linearGradient id="blCurve2" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#FFCC80" />
                  <stop offset="100%" stopColor="#FFFFFF" />
                </linearGradient>
              </defs>
              {/* Dynamic curved swooshes */}
              <path
                d="M16 28 C 38 18, 70 24, 86 46 C 70 42, 42 40, 26 56 C 18 46, 14 36, 16 28 Z"
                fill="url(#blCurve1)"
              />
              <path
                d="M24 62 C 40 48, 68 48, 84 66 C 68 66, 46 72, 32 86 C 24 78, 22 70, 24 62 Z"
                fill="url(#blCurve2)"
              />
              <circle cx="76" cy="30" r="6" fill="#FFFFFF" />
            </svg>
          </div>
          {showText && (
            <div className="leading-tight">
              <span className={`font-black text-[#E65100] tracking-tight block ${currentSize.text}`}>
                banglalink
              </span>
              <span className="text-[10px] text-slate-500 font-bold block uppercase tracking-wider">
                Ookla 4G • VEON
              </span>
            </div>
          )}
        </div>
      );

    case 'teletalk':
      return (
        <div className={`flex items-center gap-2.5 ${className}`}>
          {/* Teletalk Emblem: Green & Red Bangladesh sovereign colors & radio waves */}
          <div
            className={`${currentSize.icon} shrink-0 rounded-xl bg-gradient-to-tr from-[#006A38] via-[#00843D] to-[#28A745] p-1.5 shadow-sm flex items-center justify-center`}
            title="Teletalk Bangladesh"
          >
            <svg viewBox="0 0 100 100" className="w-full h-full" fill="none">
              <defs>
                <linearGradient id="ttRed" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#FF3B30" />
                  <stop offset="100%" stopColor="#D21034" />
                </linearGradient>
              </defs>
              {/* National Flag Red Sun at center */}
              <circle cx="50" cy="50" r="22" fill="url(#ttRed)" />
              {/* Connectivity signal rings */}
              <path
                d="M 22 50 A 28 28 0 0 1 78 50"
                stroke="#FFFFFF"
                strokeWidth="5"
                strokeLinecap="round"
                fill="none"
              />
              <path
                d="M 12 50 A 38 38 0 0 1 88 50"
                stroke="rgba(255,255,255,0.7)"
                strokeWidth="4"
                strokeLinecap="round"
                fill="none"
              />
              <path
                d="M 32 50 A 18 18 0 0 1 68 50"
                stroke="#FFFFFF"
                strokeWidth="3.5"
                strokeLinecap="round"
                fill="none"
              />
              {/* Center tower signal dot */}
              <circle cx="50" cy="50" r="5" fill="#FFFFFF" />
            </svg>
          </div>
          {showText && (
            <div className="leading-tight">
              <span className={`font-black text-[#006A38] tracking-tight block ${currentSize.text}`}>
                teletalk
              </span>
              <span className="text-[10px] text-slate-500 font-bold block uppercase tracking-wider">
                State-Owned • আমাদের ফোন
              </span>
            </div>
          )}
        </div>
      );

    default:
      return null;
  }
};
