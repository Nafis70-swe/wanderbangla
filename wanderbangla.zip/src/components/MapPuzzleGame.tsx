import React, { useState, useEffect, useMemo, useRef } from 'react';
import { DISTRICTS, District } from '../data/bangladeshData';
import mapData from '../data/bangladeshMapPaths.json';
import {
  Trophy,
  RotateCcw,
  Sparkles,
  HelpCircle,
  Clock,
  Flame,
  CheckCircle,
  XCircle,
  MapPin,
  ChevronRight,
  Eye,
  Award,
  Zap,
  Map as MapIcon,
  Layers,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface MapPuzzleGameProps {
  lang: 'bn' | 'en';
}

interface MapFeature {
  n: string;
  dv: string;
  d: string;
  c: [number, number];
}

type PuzzleMode = 'quick10' | 'all64' | 'timed60';

export const MapPuzzleGame: React.FC<MapPuzzleGameProps> = ({ lang }) => {
  const [puzzleMode, setPuzzleMode] = useState<PuzzleMode>('quick10');
  const [roundDistricts, setRoundDistricts] = useState<District[]>([]);
  const [currentRoundIdx, setCurrentRoundIdx] = useState<number>(0);
  const [foundDistrictIds, setFoundDistrictIds] = useState<Set<string>>(new Set());
  const [wrongClickedId, setWrongClickedId] = useState<string | null>(null);
  const [score, setScore] = useState<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [attempts, setAttempts] = useState<number>(0);
  const [showHint, setShowHint] = useState<boolean>(false);
  const [revealedCurrent, setRevealedCurrent] = useState<boolean>(false);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [hoveredFeature, setHoveredFeature] = useState<MapFeature | null>(null);
  const [mousePos, setMousePos] = useState<{ x: number; y: number } | null>(null);
  const [timeLeft, setTimeLeft] = useState<number>(60);

  const containerRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize game according to selected puzzle mode
  const initGame = (mode: PuzzleMode = puzzleMode) => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    const shuffled = [...DISTRICTS].sort(() => 0.5 - Math.random());
    const totalCount = mode === 'all64' ? 64 : mode === 'timed60' ? 64 : 10;
    const selected = shuffled.slice(0, totalCount);

    setRoundDistricts(selected);
    setCurrentRoundIdx(0);
    setFoundDistrictIds(new Set());
    setWrongClickedId(null);
    setScore(0);
    setStreak(0);
    setAttempts(0);
    setShowHint(false);
    setRevealedCurrent(false);
    setIsGameOver(false);
    setTimeLeft(60);

    // If timed mode, start 60s countdown
    if (mode === 'timed60') {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            setIsGameOver(true);
            confetti({ particleCount: 70, spread: 70, origin: { y: 0.5 } });
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
  };

  useEffect(() => {
    initGame(puzzleMode);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [puzzleMode]);

  const currentTarget = roundDistricts[currentRoundIdx];
  const totalRounds = roundDistricts.length || 10;

  const districtMapByName = useMemo(() => {
    const map = new Map<string, District>();
    DISTRICTS.forEach((d) => {
      const norm = d.nameEn.toLowerCase().replace(/[^a-z]/g, '');
      map.set(norm, d);
    });
    return map;
  }, []);

  const getDistrictForFeature = (featureName: string): District | undefined => {
    const norm = featureName.toLowerCase().replace(/[^a-z]/g, '');
    if (norm === 'jhalokati') return districtMapByName.get('jhalokathi');
    if (norm === 'chapainawabganj') return districtMapByName.get('chapainawabganj');
    if (norm === 'kishorganj') return districtMapByName.get('kishoreganj');
    return districtMapByName.get(norm);
  };

  const handleDistrictClick = (clickedDistrict: District | undefined) => {
    if (!clickedDistrict || isGameOver || !currentTarget) return;

    if (clickedDistrict.id === currentTarget.id) {
      // Correct click!
      confetti({ particleCount: 40, spread: 60, origin: { y: 0.6 } });
      const points = 10 + streak * 2;
      setScore((prev) => prev + points);
      setStreak((prev) => prev + 1);
      setFoundDistrictIds((prev) => new Set([...prev, currentTarget.id]));
      setWrongClickedId(null);
      setAttempts(0);
      setShowHint(false);
      setRevealedCurrent(false);

      if (currentRoundIdx < totalRounds - 1) {
        setCurrentRoundIdx((prev) => prev + 1);
      } else {
        setIsGameOver(true);
        if (timerRef.current) clearInterval(timerRef.current);
        confetti({ particleCount: 110, spread: 85, origin: { y: 0.5 } });
      }
    } else {
      // Wrong district clicked
      setWrongClickedId(clickedDistrict.id);
      setStreak(0);
      setAttempts((prev) => prev + 1);
      setTimeout(() => setWrongClickedId(null), 1800);
    }
  };

  const handleReveal = () => {
    if (!currentTarget) return;
    setRevealedCurrent(true);
    setFoundDistrictIds((prev) => new Set([...prev, currentTarget.id]));
    setTimeout(() => {
      if (currentRoundIdx < totalRounds - 1) {
        setCurrentRoundIdx((prev) => prev + 1);
        setRevealedCurrent(false);
        setAttempts(0);
        setShowHint(false);
      } else {
        setIsGameOver(true);
        if (timerRef.current) clearInterval(timerRef.current);
      }
    }, 1800);
  };

  const handleMouseMove = (e: React.MouseEvent<SVGElement>, feature: MapFeature) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    setMousePos({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    });
    setHoveredFeature(feature);
  };

  return (
    <div className="bg-white border border-[#ebe6dc] rounded-3xl p-5 sm:p-8 shadow-xs space-y-6">
      {/* Top Header Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-[#ebe6dc]">
        <div>
          <div className="flex items-center gap-2 flex-wrap mb-1.5">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0f6b4f] bg-[#e3f0ea] px-3 py-1 rounded-full">
              <Trophy className="w-3.5 h-3.5" />
              <span>{lang === 'bn' ? 'বাংলাদেশ ম্যাপ পাজল গেম' : 'Bangladesh Map Puzzle Game'}</span>
            </div>
            <span className="text-xs font-semibold text-slate-400">•</span>
            <span className="text-xs font-semibold text-slate-500">
              {lang === 'bn' ? '৬৪ জেলা শনাক্তকরণ চ্যালেঞ্জ' : '64 Districts Locator'}
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            {lang === 'bn' ? 'মানচিত্রে জেলাটি খুঁজে বের করুন!' : 'Find the District on the Map!'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
            {lang === 'bn'
              ? '৬৪ জেলার আকর্ষণীয় ইন্টারেক্টিভ ম্যাপ পাজল। মানচিত্রে সঠিক জেলা চিহ্নিত করে স্কোর ও স্ট্রিক অর্জন করুন।'
              : 'Interactive 64-district map puzzle. Click and identify districts on the map to score points!'}
          </p>
        </div>

        {/* Game stats */}
        <div className="flex items-center gap-3 flex-wrap self-start lg:self-auto">
          {/* Score Counter */}
          <div className="flex items-center gap-1.5 bg-[#f7f4ed] px-3.5 py-2 rounded-xl border border-[#ebe6dc]">
            <Trophy className="w-4 h-4 text-amber-500" />
            <span className="text-xs font-bold text-slate-700">
              {lang === 'bn' ? 'স্কোর:' : 'Score:'}{' '}
              <strong className="text-slate-900 font-black text-sm">{score}</strong>
            </span>
          </div>

          {streak > 1 && (
            <div className="flex items-center gap-1 bg-rose-50 px-3 py-2 rounded-xl border border-rose-200 text-rose-600 font-extrabold text-xs animate-bounce">
              <Flame className="w-3.5 h-3.5" />
              <span>
                {streak}x {lang === 'bn' ? 'স্ট্রিক!' : 'Streak!'}
              </span>
            </div>
          )}

          {puzzleMode === 'timed60' && !isGameOver && (
            <div className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border font-black text-xs ${
              timeLeft <= 10
                ? 'bg-red-50 border-red-300 text-red-600 animate-pulse'
                : 'bg-amber-50 border-amber-200 text-amber-800'
            }`}>
              <Clock className="w-3.5 h-3.5" />
              <span>{timeLeft}s</span>
            </div>
          )}

          <button
            onClick={() => initGame()}
            title={lang === 'bn' ? 'নতুন গেম শুরু করুন' : 'Restart Game'}
            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Game Mode Selector Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#faf8f4] p-3 rounded-2xl border border-[#ebe6dc]">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-xs font-bold text-slate-500 mr-1">
            {lang === 'bn' ? 'গেম মোড:' : 'Game Mode:'}
          </span>
          <button
            onClick={() => setPuzzleMode('quick10')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              puzzleMode === 'quick10'
                ? 'bg-[#0f6b4f] text-white shadow-2xs'
                : 'bg-white text-slate-700 hover:bg-slate-50 border border-[#ebe6dc]'
            }`}
          >
            <MapIcon className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? '১০ জেলা কুইক রাউন্ড' : 'Quick 10 Districts'}</span>
          </button>

          <button
            onClick={() => setPuzzleMode('all64')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              puzzleMode === 'all64'
                ? 'bg-[#0f6b4f] text-white shadow-2xs'
                : 'bg-white text-slate-700 hover:bg-slate-50 border border-[#ebe6dc]'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? 'সম্পূর্ণ ৬৪ জেলা মাস্টার' : 'All 64 Districts Master'}</span>
          </button>

          <button
            onClick={() => setPuzzleMode('timed60')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              puzzleMode === 'timed60'
                ? 'bg-[#0f6b4f] text-white shadow-2xs'
                : 'bg-white text-slate-700 hover:bg-slate-50 border border-[#ebe6dc]'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? '৬০ সেকেন্ড রাশ' : '60s Speed Rush'}</span>
          </button>
        </div>

        <div className="text-xs font-medium text-slate-500">
          {lang === 'bn' ? 'মানচিত্র জুম ও ড্র্যাগ করে সঠিক জেলাটিতে ক্লিক করুন' : 'Click the matching district on the map'}
        </div>
      </div>

      {!isGameOver && currentTarget ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Challenge Panel (5 cols) */}
          <div className="lg:col-span-5 bg-[#faf8f4] border border-[#ebe6dc] p-5 sm:p-6 rounded-2xl flex flex-col justify-between">
            <div>
              {/* Progress */}
              <div className="flex items-center justify-between text-xs font-bold text-slate-500 mb-2">
                <span>
                  {lang === 'bn'
                    ? `রাউন্ড ${currentRoundIdx + 1} / ${totalRounds}`
                    : `Round ${currentRoundIdx + 1} of ${totalRounds}`}
                </span>
                <span>
                  {foundDistrictIds.size} {lang === 'bn' ? 'টি সম্পন্ন' : 'Found'}
                </span>
              </div>

              <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden mb-6">
                <div
                  className="bg-[#0f6b4f] h-full rounded-full transition-all duration-300"
                  style={{ width: `${((currentRoundIdx + 1) / totalRounds) * 100}%` }}
                />
              </div>

              {/* Target Prompt Box */}
              <div className="bg-white border-2 border-[#0f6b4f] p-5 rounded-2xl shadow-xs mb-4 text-center">
                <span className="text-xs font-bold text-[#0f6b4f] uppercase tracking-wider block mb-1">
                  {lang === 'bn' ? 'এই জেলাটি মানচিত্রে ক্লিক করুন:' : 'Locate this district on map:'}
                </span>
                <h3 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                  {lang === 'bn' ? currentTarget.nameBn : currentTarget.nameEn}
                </h3>
                <span className="text-xs font-semibold text-slate-500 block mt-0.5">
                  ({lang === 'bn' ? `${currentTarget.divisionBn} বিভাগ` : `${currentTarget.divisionEn} Division`})
                </span>
              </div>

              {/* Clue and Hint Box */}
              <div className="bg-[#f3efe7] border border-[#ebe6dc] p-4 rounded-xl text-xs text-slate-700 mb-4">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-bold flex items-center gap-1 text-slate-800">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    {lang === 'bn' ? 'পর্যটন ক্লু / সূত্র:' : 'Clue:'}
                  </span>
                  {!showHint && (
                    <button
                      onClick={() => setShowHint(true)}
                      className="text-[11px] font-bold text-[#0f6b4f] hover:underline cursor-pointer"
                    >
                      {lang === 'bn' ? 'হিন্ট দেখুন 💡' : 'Show Hint 💡'}
                    </button>
                  )}
                </div>

                <p className="line-clamp-2 italic text-slate-600">
                  “{lang === 'bn' ? currentTarget.famousForBn : currentTarget.famousForEn}”
                </p>

                {showHint && (
                  <div className="mt-2 pt-2 border-t border-slate-200 text-slate-700 text-[11px]">
                    <strong>{lang === 'bn' ? 'প্রধান দর্শনীয় স্থান: ' : 'Top Spots: '}</strong>
                    {currentTarget.spots.slice(0, 3).join(', ')}
                  </div>
                )}
              </div>

              {/* Feedback Alert if Wrong District Clicked */}
              {wrongClickedId && (
                <div className="p-3 bg-rose-50 border border-rose-300 text-rose-700 rounded-xl text-xs flex items-center gap-2">
                  <XCircle className="w-4 h-4 shrink-0" />
                  <span>
                    {lang === 'bn'
                      ? 'ভুল জেলা! আবার চেষ্টা করুন।'
                      : 'Not quite! Try another location.'}
                  </span>
                </div>
              )}
            </div>

            {/* Helper Action Buttons */}
            <div className="mt-4 pt-4 border-t border-slate-200 flex items-center justify-between gap-2">
              <span className="text-[11px] text-slate-500">
                {attempts > 0 && `${lang === 'bn' ? 'ভুল চেষ্টা:' : 'Attempts:'} ${attempts}`}
              </span>

              {attempts >= 2 && !revealedCurrent && (
                <button
                  onClick={handleReveal}
                  className="text-xs font-bold text-amber-700 bg-amber-50 hover:bg-amber-100 px-3 py-1.5 rounded-xl border border-amber-200 cursor-pointer flex items-center gap-1 transition-colors"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>{lang === 'bn' ? 'উত্তর দেখিয়ে দিন' : 'Reveal Answer'}</span>
                </button>
              )}
            </div>
          </div>

          {/* Right Interactive Puzzle Map (7 cols) */}
          <div
            ref={containerRef}
            className="lg:col-span-7 bg-[#f7f4ed] border border-[#ebe6dc] p-3 rounded-2xl relative min-h-[480px] flex items-center justify-center overflow-hidden"
          >
            <svg
              viewBox={`0 0 ${mapData.w} ${mapData.h}`}
              className="w-full max-w-[540px] max-h-[720px] drop-shadow-sm transition-all"
              onMouseLeave={() => {
                setHoveredFeature(null);
                setMousePos(null);
              }}
            >
              {(mapData.f as MapFeature[]).map((feature) => {
                const district = getDistrictForFeature(feature.n);
                const districtId = district ? district.id : feature.n.toLowerCase();
                const isFound = foundDistrictIds.has(districtId);
                const isWrong = wrongClickedId === districtId;
                const isTargetRevealed = revealedCurrent && districtId === currentTarget.id;

                let fillColor = '#ded7cb'; // default puzzle beige
                if (isFound) {
                  fillColor = '#0f6b4f'; // green solved
                } else if (isTargetRevealed) {
                  fillColor = '#10b981'; // flash green
                } else if (isWrong) {
                  fillColor = '#f43f5e'; // red wrong
                } else if (hoveredFeature?.n === feature.n) {
                  fillColor = '#cfc6b5';
                }

                return (
                  <path
                    key={feature.n}
                    d={feature.d}
                    fill={fillColor}
                    stroke="#ffffff"
                    strokeWidth="0.9"
                    strokeLinejoin="round"
                    className="cursor-pointer transition-colors duration-150 hover:opacity-90"
                    onClick={() => handleDistrictClick(district)}
                    onMouseEnter={(e) => handleMouseMove(e, feature)}
                    onMouseMove={(e) => handleMouseMove(e, feature)}
                  />
                );
              })}
            </svg>

            {/* Floating Tooltip during puzzle */}
            {hoveredFeature && mousePos && (
              <div
                className="absolute z-30 pointer-events-none transition-transform duration-75 ease-out"
                style={{
                  left: `${mousePos.x}px`,
                  top: `${mousePos.y - 12}px`,
                  transform: 'translate(-50%, -100%)',
                }}
              >
                <div className="bg-[#525252]/90 backdrop-blur-md text-white text-[11px] font-bold px-2.5 py-1 rounded-md shadow-md border border-white/20 whitespace-nowrap">
                  {lang === 'bn' ? (getDistrictForFeature(hoveredFeature.n)?.nameBn || hoveredFeature.n) : hoveredFeature.n}
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Game Over Trophy Screen */
        <div className="py-12 text-center max-w-lg mx-auto">
          <div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-amber-300">
            <Trophy className="w-10 h-10 text-amber-600" />
          </div>

          <h3 className="text-2xl font-black text-slate-900 mb-1">
            {lang === 'bn' ? 'ম্যাপ পাজল সমাপ্ত হয়েছে!' : 'Puzzle Completed!'}
          </h3>

          <p className="text-sm text-slate-600 mb-6">
            {lang === 'bn'
              ? `অভিনন্দন! আপনি মোট ${foundDistrictIds.size}টি জেলা সফলভাবে শনাক্ত করেছেন!`
              : `Great job! You identified ${foundDistrictIds.size} districts!`}
          </p>

          <div className="bg-[#faf8f4] border border-[#ebe6dc] p-4 rounded-2xl mb-6 flex items-center justify-around">
            <div>
              <span className="text-xs text-slate-500 font-medium block">
                {lang === 'bn' ? 'মোট স্কোর' : 'Total Score'}
              </span>
              <span className="text-2xl font-black text-[#0f6b4f]">{score}</span>
            </div>
            <div className="h-8 w-px bg-slate-200" />
            <div>
              <span className="text-xs text-slate-500 font-medium block">
                {lang === 'bn' ? 'অর্জিত খেতাব' : 'Explorer Rank'}
              </span>
              <span className="text-sm font-bold text-slate-800">
                {score >= 80 ? 'বাংলাদেশ ভূগোল মাস্টার 🏆' : 'দক্ষ অভিযাত্রী ✨'}
              </span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={() => initGame()}
              className="inline-flex items-center justify-center gap-2 bg-[#0f6b4f] hover:bg-emerald-800 text-white font-bold text-sm px-6 py-3 rounded-xl transition-all cursor-pointer shadow-md w-full sm:w-auto"
            >
              <RotateCcw className="w-4 h-4" />
              <span>{lang === 'bn' ? 'আবার নতুন পাজল খেলুন' : 'Play Again'}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
