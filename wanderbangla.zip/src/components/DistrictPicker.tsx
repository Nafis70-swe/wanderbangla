import React, { useState, useMemo } from 'react';
import { DISTRICTS, DIVISION_DISTRICTS, DIVISIONS } from '../data/bangladeshData';
import { Search, X, Check, CheckCheck, RotateCcw, ChevronDown, ChevronUp, MapPin } from 'lucide-react';

interface DistrictPickerProps {
  selectedDistricts: Set<string>;
  onToggleDistrict: (districtId: string) => void;
  onSelectAll: (select: boolean) => void;
  onSelectDivision: (divisionNameBn: string, select: boolean) => void;
  lang: 'bn' | 'en';
}

export const DistrictPicker: React.FC<DistrictPickerProps> = ({
  selectedDistricts,
  onToggleDistrict,
  onSelectAll,
  onSelectDivision,
  lang,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [collapsedDivisions, setCollapsedDivisions] = useState<Record<string, boolean>>({});

  const totalDistricts = 64;
  const count = selectedDistricts.size;
  const percentage = Math.round((count / totalDistricts) * 100);

  // Explorer Title calculation based on count
  const getExplorerTitle = (visited: number) => {
    if (visited === 0) return { bn: 'শুরু করুন ভ্রমণ', en: 'Start Wandering' };
    if (visited <= 10) return { bn: 'নবীন অভিযাত্রী', en: 'Novice Traveler' };
    if (visited <= 25) return { bn: 'অন্বেষী ভবঘুরে', en: 'Curious Explorer' };
    if (visited <= 45) return { bn: 'অভিজ্ঞ পরিব্রাজক', en: 'Seasoned Wanderer' };
    if (visited < 64) return { bn: 'বাংলার সুপার ট্রাভেলার', en: 'Super Wanderer' };
    return { bn: '৬৪ জেলা বিজয়ী মহাপর্যটক!', en: 'Conqueror of Bangladesh!' };
  };

  const title = getExplorerTitle(count);

  const toggleDivisionCollapse = (div: string) => {
    setCollapsedDivisions((prev) => ({ ...prev, [div]: !prev[div] }));
  };

  // Filtered districts
  const filteredDivisions = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    const result: Record<string, typeof DISTRICTS> = {};

    Object.entries(DIVISION_DISTRICTS).forEach(([divName, districtIds]) => {
      const districtsInDiv = districtIds
        .map((id) => DISTRICTS.find((d) => d.id === id)!)
        .filter((d) => {
          if (!query) return true;
          return (
            d.nameBn.toLowerCase().includes(query) ||
            d.nameEn.toLowerCase().includes(query) ||
            d.famousForBn.toLowerCase().includes(query) ||
            d.famousForEn.toLowerCase().includes(query) ||
            d.spots.some((s) => s.toLowerCase().includes(query))
          );
        });

      if (districtsInDiv.length > 0) {
        result[divName] = districtsInDiv;
      }
    });

    return result;
  }, [searchQuery]);

  return (
    <div className="bg-white border border-[#ebe6dc] rounded-2xl p-5 shadow-xs flex flex-col h-full max-h-[calc(100vh-100px)] sticky top-20">
      {/* Header & Counter */}
      <div className="flex items-center justify-between pb-3 border-b border-[#ebe6dc]">
        <div>
          <h2 className="text-lg font-extrabold text-slate-900 tracking-tight">
            {lang === 'bn' ? 'জেলা বাছাই করুন' : 'Select Districts'}
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            {lang === 'bn' ? title.bn : title.en} · {percentage}% {lang === 'bn' ? 'সম্পন্ন' : 'Completed'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-[#0f6b4f] bg-[#e3f0ea] px-3 py-1 rounded-full border border-[#0f6b4f]/20">
            {count} / {totalDistricts}
          </span>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden my-3">
        <div
          className="bg-[#0f6b4f] h-full rounded-full transition-all duration-300"
          style={{ width: `${percentage}%` }}
        />
      </div>

      {/* Search Input */}
      <div className="relative mb-3">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={lang === 'bn' ? 'জেলার নাম খুঁজুন (যেমন: কক্সবাজার, সিলেট)...' : 'Search district...'}
          className="w-full bg-[#faf8f4] border border-[#ebe6dc] rounded-xl pl-9 pr-8 py-2 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-[#0f6b4f] focus:ring-1 focus:ring-[#0f6b4f] transition-all"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Quick Actions Bar */}
      <div className="flex items-center justify-between text-xs pb-2 mb-1 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <button
            onClick={() => onSelectAll(true)}
            className="text-slate-600 hover:text-[#0f6b4f] font-semibold underline underline-offset-2 transition-colors cursor-pointer flex items-center gap-1"
          >
            <CheckCheck className="w-3.5 h-3.5" />
            {lang === 'bn' ? 'সব বাছাই করুন' : 'Select All'}
          </button>
          <button
            onClick={() => onSelectAll(false)}
            className="text-slate-500 hover:text-rose-600 font-semibold underline underline-offset-2 transition-colors cursor-pointer flex items-center gap-1"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            {lang === 'bn' ? 'রিসেট' : 'Reset'}
          </button>
        </div>

        <span className="text-[11px] text-slate-400">
          {Object.values(filteredDivisions).flat().length} {lang === 'bn' ? 'টি প্রদর্শিত' : 'shown'}
        </span>
      </div>

      {/* Division Groups & District Chips */}
      <div className="overflow-y-auto pr-1 flex-1 space-y-3.5 divide-y divide-slate-100">
        {Object.entries(filteredDivisions).map(([divName, districtsList]) => {
          const isCollapsed = !!collapsedDivisions[divName];
          const divSelectedCount = districtsList.filter((d) => selectedDistricts.has(d.id)).length;
          const allDivSelected = divSelectedCount === districtsList.length;

          return (
            <div key={divName} className="pt-3 first:pt-1">
              {/* Division Header */}
              <div className="flex items-center justify-between mb-2">
                <button
                  onClick={() => toggleDivisionCollapse(divName)}
                  className="flex items-center gap-1.5 font-bold text-xs text-slate-800 hover:text-[#0f6b4f] transition-colors cursor-pointer"
                >
                  <MapPin className="w-3.5 h-3.5 text-[#0f6b4f]" />
                  <span>
                    {lang === 'bn' ? `${divName} বিভাগ` : `${DIVISIONS[divName]?.nameEn || divName} Division`}
                  </span>
                  <span className="text-[11px] font-normal text-slate-500">
                    ({divSelectedCount}/{districtsList.length})
                  </span>
                  {isCollapsed ? (
                    <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                  ) : (
                    <ChevronUp className="w-3.5 h-3.5 text-slate-400" />
                  )}
                </button>

                {/* Toggle whole division */}
                <button
                  onClick={() => onSelectDivision(divName, !allDivSelected)}
                  className="text-[11px] font-semibold text-[#0f6b4f] hover:text-emerald-800 transition-colors cursor-pointer px-1.5 py-0.5 rounded-md hover:bg-emerald-50"
                >
                  {allDivSelected
                    ? lang === 'bn'
                      ? 'সব মুছুন'
                      : 'Clear'
                    : lang === 'bn'
                    ? 'সব যোগ'
                    : 'Add all'}
                </button>
              </div>

              {/* District Chips */}
              {!isCollapsed && (
                <div className="flex flex-wrap gap-1.5">
                  {districtsList.map((district) => {
                    const isSelected = selectedDistricts.has(district.id);
                    return (
                      <button
                        key={district.id}
                        onClick={() => onToggleDistrict(district.id)}
                        className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-150 cursor-pointer select-none border ${
                          isSelected
                            ? 'bg-[#0f6b4f] text-white border-[#0f6b4f] shadow-xs scale-[1.02]'
                            : 'bg-[#f3efe7] text-slate-700 border-transparent hover:border-[#d6cfc1] hover:bg-[#eae5dc]'
                        }`}
                        title={`${district.spots.slice(0, 2).join(', ')}`}
                      >
                        {isSelected && <Check className="w-3 h-3 stroke-[2.5]" />}
                        <span>{lang === 'bn' ? district.nameBn : district.nameEn}</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}

        {Object.keys(filteredDivisions).length === 0 && (
          <div className="py-8 text-center text-sm text-slate-400">
            {lang === 'bn' ? 'কোনো জেলা খুঁজে পাওয়া যায়নি' : 'No districts found matching your search'}
          </div>
        )}
      </div>
    </div>
  );
};
