import React, { useState } from 'react';
import { QUIZ_QUESTIONS, Question } from '../data/quizData';
import { MapPuzzleGame } from './MapPuzzleGame';
import { Award, CheckCircle, XCircle, RotateCcw, Sparkles, HelpCircle, Puzzle, BrainCircuit } from 'lucide-react';
import confetti from 'canvas-confetti';

interface TravelQuizProps {
  lang: 'bn' | 'en';
}

export const TravelQuiz: React.FC<TravelQuizProps> = ({ lang }) => {
  const [gameMode, setGameMode] = useState<'puzzle' | 'quiz'>('puzzle');
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [showHint, setShowHint] = useState<boolean>(false);
  const [isFinished, setIsFinished] = useState(false);

  // Take a round of 10 questions
  const [activeQuestions, setActiveQuestions] = useState<Question[]>(() => {
    return [...QUIZ_QUESTIONS].sort(() => 0.5 - Math.random()).slice(0, 10);
  });

  const currentQ = activeQuestions[currentIdx];
  const userChoice = currentQ ? selectedAnswers[currentQ.id] : undefined;
  const isAnswered = userChoice !== undefined;

  const handleSelect = (optionIdx: number) => {
    if (isAnswered || !currentQ) return;
    const nextAnswers = { ...selectedAnswers, [currentQ.id]: optionIdx };
    setSelectedAnswers(nextAnswers);

    if (optionIdx === currentQ.correctIdx) {
      confetti({ particleCount: 30, spread: 60, origin: { y: 0.7 } });
    }
  };

  const handleNext = () => {
    setShowHint(false);
    if (currentIdx < activeQuestions.length - 1) {
      setCurrentIdx((prev) => prev + 1);
    } else {
      setIsFinished(true);
      confetti({ particleCount: 90, spread: 80, origin: { y: 0.5 } });
    }
  };

  const resetQuiz = () => {
    setActiveQuestions([...QUIZ_QUESTIONS].sort(() => 0.5 - Math.random()).slice(0, 10));
    setCurrentIdx(0);
    setSelectedAnswers({});
    setShowHint(false);
    setIsFinished(false);
  };

  const correctCount = Object.entries(selectedAnswers).filter(
    ([qId, ans]) => activeQuestions.find((q) => q.id === Number(qId))?.correctIdx === ans
  ).length;

  return (
    <div className="space-y-6">
      {/* Game Mode Sub-Navigation Tabs */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 flex-wrap">
        <div className="inline-flex items-center gap-1.5 bg-white p-1.5 rounded-2xl border border-[#ebe6dc] shadow-xs">
          <button
            onClick={() => setGameMode('puzzle')}
            className={`px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center gap-2 ${
              gameMode === 'puzzle'
                ? 'bg-[#0f6b4f] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <Puzzle className="w-4 h-4" />
            <span>{lang === 'bn' ? 'ম্যাপ পাজল গেম' : 'Map Puzzle Game'}</span>
          </button>

          <button
            onClick={() => setGameMode('quiz')}
            className={`px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center gap-2 ${
              gameMode === 'quiz'
                ? 'bg-[#0f6b4f] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <BrainCircuit className="w-4 h-4" />
            <span>{lang === 'bn' ? 'ভ্রমণ কুইজ চ্যালেঞ্জ' : 'Travel Trivia Quiz'}</span>
          </button>
        </div>
      </div>

      {/* Mode 1: Map Puzzle Game */}
      {gameMode === 'puzzle' && <MapPuzzleGame lang={lang} />}

      {/* Mode 2: Expanded Travel Trivia Quiz */}
      {gameMode === 'quiz' && (
        <div className="bg-white border border-[#ebe6dc] rounded-3xl p-6 sm:p-10 shadow-xs max-w-3xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0f6b4f] bg-[#e3f0ea] px-3.5 py-1.5 rounded-full mb-3">
              <HelpCircle className="w-3.5 h-3.5" />
              <span>{lang === 'bn' ? 'বাংলাদেশ ভ্রমণ কুইজ' : 'Bangladesh Travel Trivia'}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              {lang === 'bn' ? 'আপনি বাংলাদেশকে কতটুকু চেনেন?' : 'How Well Do You Know Bangladesh?'}
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              {lang === 'bn'
                ? '৬৪ জেলার বিখ্যাত পর্যটন স্থান, ঐতিহ্যবাহী খাবার, নদী ও ভূগোল সম্পর্কে নিজের জ্ঞান যাচাই করুন।'
                : 'Test your travel and geography knowledge across all 64 districts.'}
            </p>
          </div>

          {!isFinished && currentQ ? (
            <div>
              {/* Question Progress bar */}
              <div className="flex items-center justify-between text-xs text-slate-500 font-bold mb-2">
                <span className="flex items-center gap-2">
                  <span className="bg-[#e3f0ea] text-[#0f6b4f] px-2 py-0.5 rounded-md font-semibold">
                    {lang === 'bn' ? currentQ.categoryBn : currentQ.categoryEn}
                  </span>
                  <span>
                    {lang === 'bn'
                      ? `প্রশ্ন ${currentIdx + 1} / ${activeQuestions.length}`
                      : `Question ${currentIdx + 1} of ${activeQuestions.length}`}
                  </span>
                </span>
                <span>
                  {lang === 'bn' ? `সঠিক: ${correctCount}` : `Score: ${correctCount}`}
                </span>
              </div>

              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mb-6">
                <div
                  className="bg-[#0f6b4f] h-full transition-all duration-300 rounded-full"
                  style={{ width: `${((currentIdx + 1) / activeQuestions.length) * 100}%` }}
                />
              </div>

              {/* Question Box */}
              <div className="bg-[#faf8f4] border border-[#ebe6dc] p-6 rounded-2xl mb-6">
                <h3 className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
                  {lang === 'bn' ? currentQ.questionBn : currentQ.questionEn}
                </h3>
              </div>

              {/* Option Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
                {(lang === 'bn' ? currentQ.optionsBn : currentQ.optionsEn).map((opt, idx) => {
                  const isSelected = userChoice === idx;
                  const isCorrect = currentQ.correctIdx === idx;

                  let btnStyle = 'bg-white border-[#ebe6dc] hover:border-[#0f6b4f] text-slate-800';

                  if (isAnswered) {
                    if (isCorrect) {
                      btnStyle = 'bg-emerald-50 border-emerald-500 text-emerald-900 font-bold';
                    } else if (isSelected) {
                      btnStyle = 'bg-rose-50 border-rose-500 text-rose-900';
                    } else {
                      btnStyle = 'bg-slate-50 border-slate-200 text-slate-400 opacity-60';
                    }
                  }

                  return (
                    <button
                      key={idx}
                      onClick={() => handleSelect(idx)}
                      disabled={isAnswered}
                      className={`p-4 rounded-xl border text-left text-sm transition-all duration-150 cursor-pointer flex items-center justify-between ${btnStyle}`}
                    >
                      <span>{opt}</span>
                      {isAnswered && isCorrect && <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />}
                      {isAnswered && isSelected && !isCorrect && <XCircle className="w-4 h-4 text-rose-600 shrink-0" />}
                    </button>
                  );
                })}
              </div>

              {/* Hint Box (if not answered yet) */}
              {!isAnswered && (
                <div className="mb-4 text-right">
                  {!showHint ? (
                    <button
                      onClick={() => setShowHint(true)}
                      className="text-xs font-bold text-[#0f6b4f] hover:underline cursor-pointer"
                    >
                      {lang === 'bn' ? 'ক্লু বা হিন্ট চান? 💡' : 'Need a hint? 💡'}
                    </button>
                  ) : (
                    <div className="p-3 bg-amber-50 border border-amber-200 text-amber-900 rounded-xl text-xs text-left">
                      <strong>{lang === 'bn' ? 'হিন্ট: ' : 'Hint: '}</strong>
                      {currentQ.hintBn}
                    </div>
                  )}
                </div>
              )}

              {/* Explanation Box after answer */}
              {isAnswered && (
                <div className="bg-[#e3f0ea]/70 border border-[#0f6b4f]/30 p-4 rounded-xl mb-6 text-xs text-slate-800 leading-relaxed">
                  <span className="font-bold text-[#0f6b4f] mr-1">
                    {lang === 'bn' ? 'ব্যাখ্যা:' : 'Explanation:'}
                  </span>
                  {lang === 'bn' ? currentQ.explanationBn : currentQ.explanationEn}
                </div>
              )}

              {/* Next Button */}
              {isAnswered && (
                <div className="flex justify-end">
                  <button
                    onClick={handleNext}
                    className="bg-[#0f6b4f] hover:bg-emerald-800 text-white font-bold text-sm px-6 py-2.5 rounded-xl transition-all cursor-pointer shadow-xs"
                  >
                    {currentIdx < activeQuestions.length - 1
                      ? lang === 'bn'
                        ? 'পরবর্তী প্রশ্ন →'
                        : 'Next Question →'
                      : lang === 'bn'
                      ? 'ফলাফল দেখুন'
                      : 'See Results'}
                  </button>
                </div>
              )}
            </div>
          ) : (
            /* Results View */
            <div className="text-center py-6">
              <div className="w-20 h-20 bg-[#e3f0ea] rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-[#0f6b4f]/30">
                <Award className="w-10 h-10 text-[#0f6b4f]" />
              </div>

              <h3 className="text-2xl font-black text-slate-900 mb-2">
                {lang === 'bn' ? 'কুইজ রাউন্ড সম্পন্ন!' : 'Quiz Round Completed!'}
              </h3>

              <p className="text-base text-slate-700 font-semibold mb-6">
                {lang === 'bn'
                  ? `আপনি ১০টির মধ্যে ${correctCount}টি প্রশ্নের সঠিক উত্তর দিয়েছেন!`
                  : `You scored ${correctCount} out of 10 correct!`}
              </p>

              <div className="p-4 bg-[#faf8f4] border border-[#ebe6dc] rounded-2xl max-w-sm mx-auto mb-6 text-xs text-slate-600">
                {correctCount >= 8
                  ? lang === 'bn'
                    ? '🏆 অসাধারণ! আপনি বাংলাদেশ ভ্রমণের সত্যিকার চ্যাম্পিয়ন ও মাস্টার!'
                    : '🏆 Outstanding! You are a certified Bangladesh travel master!'
                  : lang === 'bn'
                  ? '✨ বেশ ভালো! আরও কিছু জেলা ও নিদর্শন সম্পর্কে জেনে নিন।'
                  : '✨ Great effort! Keep exploring more corners of Bangladesh.'}
              </div>

              <button
                onClick={resetQuiz}
                className="inline-flex items-center gap-2 bg-[#0f6b4f] hover:bg-emerald-800 text-white font-bold text-sm px-6 py-3 rounded-xl transition-all cursor-pointer shadow-sm"
              >
                <RotateCcw className="w-4 h-4" />
                <span>{lang === 'bn' ? 'নতুন ১০টি প্রশ্ন খেলুন' : 'Play Another 10 Questions'}</span>
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
