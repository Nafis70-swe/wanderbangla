import React, { useState, useMemo, useEffect } from 'react';
import {
  PhoneCall,
  ShieldAlert,
  Smartphone,
  DollarSign,
  Compass,
  MapPin,
  Bus,
  Plane,
  Train,
  Hotel,
  Utensils,
  AlertTriangle,
  LifeBuoy,
  HeartHandshake,
  Check,
  Copy,
  ExternalLink,
  Calendar,
  Search,
  Sparkles,
  HelpCircle,
  Globe,
  Info,
  Sun,
  Waves,
  Mountain,
  Landmark,
  Trees,
  Clock,
  ArrowRight,
  ShieldCheck,
  CreditCard,
  Wifi,
  Coffee,
  CheckCircle2,
  Users,
  Car,
  Ship,
  FileText,
  BadgeAlert,
  ChevronRight,
  QrCode,
  Radio,
  RotateCw,
  TrendingUp,
  Ticket,
  Coins,
  TrainFront,
  Navigation,
} from 'lucide-react';
import { SimCompanyLogo } from './SimCompanyLogo';
import sajekImg from '../assets/images/hero_sajek_valley_1791467925600.jpg';
import coxsBazarImg from '../assets/images/coxs_bazar_sunset_1791467939002.jpg';
import sreemangalImg from '../assets/images/sreemangal_tea_gardens_1791467951603.jpg';
import sundarbansImg from '../assets/images/sundarbans_mangrove_forest_1791467963249.jpg';

export type CurrencyType = 'BDT' | 'USD' | 'EUR' | 'AED';

interface TouristHandbookProps {
  lang: 'bn' | 'en';
}

// Exchange rates relative to 1 BDT
// 1 USD ≈ 122 BDT
// 1 EUR ≈ 132 BDT
// 1 AED ≈ 33.2 BDT
const CURRENCY_RATES: Record<CurrencyType, { symbol: string; rateFromBdt: number; nameBn: string; nameEn: string }> = {
  BDT: { symbol: '৳', rateFromBdt: 1, nameBn: 'টাকা (BDT)', nameEn: 'Bangladeshi Taka (BDT)' },
  USD: { symbol: '$', rateFromBdt: 1 / 122, nameBn: 'ডলার (USD)', nameEn: 'US Dollar (USD)' },
  EUR: { symbol: '€', rateFromBdt: 1 / 132, nameBn: 'ইউরো (EUR)', nameEn: 'Euro (EUR)' },
  AED: { symbol: 'AED', rateFromBdt: 1 / 33.2, nameBn: 'ইউএই দিরহাম (AED)', nameEn: 'UAE Dirham (AED)' },
};

// Emergency contact numbers
interface EmergencyContact {
  id: string;
  nameBn: string;
  nameEn: string;
  number: string;
  displayNumber?: string;
  typeBn: string;
  typeEn: string;
  descBn: string;
  descEn: string;
  tag: 'critical' | 'police' | 'health' | 'airport' | 'help';
  available: string;
  tollFree?: boolean;
}

const EMERGENCY_CONTACTS: EmergencyContact[] = [
  {
    id: 'national-emergency',
    nameBn: 'জাতীয় জরুরি সেবা (পুলিশ, ফায়ার সার্ভিস, অ্যাম্বুলেন্স)',
    nameEn: 'National Emergency Service (Police, Fire, Ambulance)',
    number: '999',
    typeBn: 'সর্বজনীন জরুরি',
    typeEn: 'Universal Emergency',
    descBn: 'যেকোনো বিপদে পুলিশ সহায়তা, দুর্ঘটনা, অগ্নিকাণ্ড বা জরুরি অ্যাম্বুলেন্সের জন্য অবিলম্বে কল করুন।',
    descEn: 'Instant 24/7 emergency response for police assistance, road accidents, fire, and ambulance nationwide.',
    tag: 'critical',
    available: '24/7',
    tollFree: true,
  },
  {
    id: 'tourist-police-hq',
    nameBn: 'ট্যুরিস্ট পুলিশ বাংলাদেশ (হেডকোয়ার্টার হটলাইন)',
    nameEn: 'Tourist Police Bangladesh (HQ Hotline)',
    number: '+8801320222222',
    displayNumber: '01320-222222',
    typeBn: 'পর্যটক নিরাপত্তা ও সহায়তা',
    typeEn: 'Tourist Safety & Protection',
    descBn: 'বিদেশি ও দেশি পর্যটকদের নিরাপত্তা, প্রতারণা রোধ, গাইড সহায়তা ও দর্শনীয় স্থানে সার্বক্ষণিক নজরদারি।',
    descEn: 'Dedicated police branch ensuring traveler security, scam prevention, spot assistance across BD.',
    tag: 'police',
    available: '24/7',
  },
  {
    id: 'tourist-police-control',
    nameBn: 'ট্যুরিস্ট পুলিশ সেন্ট্রাল কন্ট্রোল রুম',
    nameEn: 'Tourist Police Central Control Room',
    number: '+8801320163599',
    displayNumber: '01320-163599',
    typeBn: 'জরুরি বার্তা ও নিয়ন্ত্রণ কক্ষ',
    typeEn: 'Central Control & Incident Desk',
    descBn: 'কক্সবাজার, কুয়াকাটা, সিলেট, সাজেক ও সুন্দরবনসহ যেকোনো পর্যটন এলাকায় তাৎক্ষণিক সাহায্যের জন্য।',
    descEn: 'Direct incident desk covering Cox’s Bazar, Sylhet, Sajek, Kuakata, Sundarbans, and heritage zones.',
    tag: 'police',
    available: '24/7',
  },
  {
    id: 'health-call-center',
    nameBn: 'স্বাস্থ্য বাতায়ন (সরকারি ২৪ ঘণ্টা স্বাস্থ্য হটলাইন)',
    nameEn: 'National Health Helpline (Doctor Advice & Ambulance)',
    number: '16263',
    typeBn: 'চিকিৎসা ও ডাক্তার পরামর্শ',
    typeEn: 'Medical Advice & Hospitals',
    descBn: 'ভ্রমণকালীন হঠাৎ অসুস্থতা, সরকারি হাসপাতালের অ্যাম্বুলেন্স বা বিশেষজ্ঞ চিকিৎসকের পরামর্শ পেতে।',
    descEn: 'Govt health helpline for immediate medical counsel, hospital guidance, and ambulance dispatch.',
    tag: 'health',
    available: '24/7',
    tollFree: false,
  },
  {
    id: 'women-children',
    nameBn: 'জাতীয় নারী ও শিশু নির্যাতন প্রতিরোধ হেল্পলাইন',
    nameEn: 'National Women & Child Helpline',
    number: '109',
    typeBn: 'নারী পর্যটক সহায়তা',
    typeEn: 'Women Traveler Safety',
    descBn: 'নারী একক পরিব্রাজক (Solo Female Travelers) এবং শিশুদের জরুরি সুরক্ষার জন্য বিশেষায়িত সেবা।',
    descEn: 'Toll-free immediate support for solo female travelers and children in distress.',
    tag: 'help',
    available: '24/7',
    tollFree: true,
  },
  {
    id: 'fire-service',
    nameBn: 'ফায়ার সার্ভিস ও সিভিল ডিফেন্স নিয়ন্ত্রণ কক্ষ',
    nameEn: 'Fire Service & Civil Defence Central Station',
    number: '102',
    displayNumber: '102 / 02-223355555',
    typeBn: 'অগ্নিনির্বাপণ ও উদ্ধার',
    typeEn: 'Fire & Water Rescue',
    descBn: 'নৌ-দুর্ঘটনা, অগ্নিকাণ্ড, ভূমিধস কিংবা পাহাড়ি রাস্তায় উদ্ধার অভিযানের জন্য প্রস্তুত বিশেষ দল।',
    descEn: 'Fire fighting, river rescue, flash flood and technical hill rescue squad across Bangladesh.',
    tag: 'critical',
    available: '24/7',
    tollFree: true,
  },
  {
    id: 'citizen-info',
    nameBn: 'জাতীয় তথ্য বাতায়ন ও সরকারি হেল্পলাইন',
    nameEn: 'National Citizen & Public Services Helpline',
    number: '333',
    typeBn: 'তথ্য সেবা',
    typeEn: 'Information Desk',
    descBn: 'সরকারি যেকোনো তথ্য, জেলা প্রশাসনের যোগাযোগ এবং স্থানীয় জরুরি সেবা জানতে কল করুন।',
    descEn: 'Government information helpline for district administration contacts and public guidance.',
    tag: 'help',
    available: '24/7',
    tollFree: false,
  },
  {
    id: 'airport-hotline',
    nameBn: 'হযরত শাহজালাল আন্তর্জাতিক বিমানবন্দর (HSIA) তথ্য ও হেল্পডেস্ক',
    nameEn: 'Hazrat Shahjalal Int’l Airport (Dhaka) Tourist Helpdesk',
    number: '+88028901449',
    displayNumber: '+880 2 8901449 / 13600',
    typeBn: 'বিমানবন্দর ও লস্ট অ্যান্ড ফাউন্ড',
    typeEn: 'Airport & Lost & Found',
    descBn: 'ফ্লাইট শিডিউল, হারিয়ে যাওয়া লাগেজ, ইমিগ্রেশন ও পর্যটক সহায়তার জন্য বিমানবন্দর কন্ট্রোল রুম।',
    descEn: 'Flight status, baggage assistance, immigration queries and arrival support in Dhaka.',
    tag: 'airport',
    available: '24/7',
  },
  {
    id: 'railway-police',
    nameBn: 'বাংলাদেশ রেলওয়ে সেবা ও নিরাপত্তা হেল্পলাইন',
    nameEn: 'Bangladesh Railway Helpline & Security',
    number: '131',
    typeBn: 'ট্রেন ভ্রমণ তথ্য ও নিরাপত্তা',
    typeEn: 'Train Travel Safety',
    descBn: 'ট্রেন শিডিউল, ট্রেনের টিকিট সমস্যা এবং ট্রেনযাত্রায় নিরাপত্তা সমস্যার সমাধান পেতে।',
    descEn: 'Official passenger inquiry, schedule updates and security for train journeys across BD.',
    tag: 'help',
    available: '6:00 AM - 11:00 PM',
  },
  {
    id: 'biman-airlines',
    nameBn: 'বিমান বাংলাদেশ এয়ারলাইন্স কাস্টমার কেয়ার',
    nameEn: 'Biman Bangladesh Airlines Customer Care',
    number: '13636',
    typeBn: 'এয়ার টিকিট ও অভ্যন্তরীণ ফ্লাইট',
    typeEn: 'Domestic & Int’l Flights',
    descBn: 'অভ্যন্তরীণ রুট (কক্সবাজার, সিলেট, সৈয়দপুর, যশোর, চট্টগ্রাম) ও আন্তর্জাতিক ফ্লাইটের জন্য।',
    descEn: 'Reservations, flight schedule changes and domestic network support across BD airports.',
    tag: 'airport',
    available: '24/7',
  },
];

// SIM Card Operators Information
interface SimOperator {
  id: string;
  name: string;
  nameBn: string;
  badgeBn: string;
  badgeEn: string;
  website: string;
  websiteDisplay: string;
  helpline: string;
  sloganBn: string;
  sloganEn: string;
  coverageRating: number; // out of 5
  speedRating: number;
  highlightBn: string;
  highlightEn: string;
  bestForBn: string;
  bestForEn: string;
  touristSimAvailable: boolean;
  eSimAvailable: boolean;
  airportBooth: boolean;
  color: string;
  bgGradient: string;
  borderColor: string;
  recommendedPacks: {
    data: string;
    validityBn: string;
    validityEn: string;
    bdtPrice: number;
    descBn: string;
    descEn: string;
  }[];
  airportLocationBn: string;
  airportLocationEn: string;
}

const SIM_OPERATORS: SimOperator[] = [
  {
    id: 'grameenphone',
    name: 'Grameenphone (GP)',
    nameBn: 'গ্রামীণফোন (GP)',
    badgeBn: 'দেশসেরা কভারেজ (৯৯%+ নেটওয়ার্ক)',
    badgeEn: 'Best Nationwide Coverage (99%+)',
    website: 'https://www.grameenphone.com',
    websiteDisplay: 'grameenphone.com',
    helpline: '121',
    sloganBn: 'চলো বহুদূর (Go Beyond)',
    sloganEn: 'Go Beyond • Telenor Group',
    coverageRating: 5,
    speedRating: 4.5,
    highlightBn: 'বাংলাদেশের দুর্গম পাহাড়, সাজেক, সুন্দরবন, হাওর ও মহাসড়কে সবচেয়ে শক্তিশালী ৪জি সিগন্যাল।',
    highlightEn: 'Strongest 4G coverage across remote hills (Sajek/Bandarban), Sundarbans, highways and wetlands.',
    bestForBn: 'পাহাড় ও দুর্গম অঞ্চলে ভ্রমণকারী এবং দীর্ঘমেয়াদি ট্যুরিস্টদের জন্য সেরা পছন্দ।',
    bestForEn: 'Best overall choice for long journeys, remote hiking, and reliable high-speed backup.',
    touristSimAvailable: true,
    eSimAvailable: true,
    airportBooth: true,
    color: '#0070BA',
    bgGradient: 'from-blue-50/70 to-sky-50/40',
    borderColor: 'border-blue-200',
    airportLocationBn: 'ঢাকা বিমানবন্দর অ্যারাইভাল টার্মিনাল ১ ও ২ এক্সিটের সামনে ২৪/৭ বুথ।',
    airportLocationEn: 'Arrival Concourse Exit (Terminals 1 & 2), Hazrat Shahjalal Int’l Airport (24/7).',
    recommendedPacks: [
      {
        data: '15 GB 4G Data + 200 Min',
        validityBn: '১৫ দিন মেয়াদ',
        validityEn: '15 Days Validity',
        bdtPrice: 399,
        descBn: 'শর্ট ট্রিপ বা ২ সপ্তাহের জন্য আদর্শ প্যাকেজ',
        descEn: 'Perfect bundle for 1-2 week vacation',
      },
      {
        data: '30 GB 4G Data + 400 Min',
        validityBn: '৩০ দিন মেয়াদ',
        validityEn: '30 Days Validity',
        bdtPrice: 599,
        descBn: 'ট্যুরিস্টদের সবচেয়ে জনপ্রিয় আনলিমিটেড ব্রাউজিং প্যাক',
        descEn: 'Most popular tourist pack for maps & social media',
      },
    ],
  },
  {
    id: 'robi',
    name: 'Robi (Robi Axiata)',
    nameBn: 'রবি (Robi Axiata)',
    badgeBn: 'সেরা ভ্যালু ও হাইওয়ে নেটওয়ার্ক',
    badgeEn: 'Best Value & Strong Highways',
    website: 'https://www.robi.com.bd',
    websiteDisplay: 'robi.com.bd',
    helpline: '123',
    sloganBn: 'নতুন দিগন্তের উন্মোচন',
    sloganEn: 'Ignite New Possibilities • Axiata Group',
    coverageRating: 4.6,
    speedRating: 4.4,
    highlightBn: 'বাজেটবান্ধব ডাটা প্যাকেজ, দ্রুতগতির ৪জি এবং যেকোনো প্রধান শহরে চমৎকার নেটওয়ার্ক গতি।',
    highlightEn: 'Cost-efficient data plans, seamless highway transit coverage and robust urban 4G connectivity.',
    bestForBn: 'বাজেট ট্রাভেলার এবং দ্রুত কিউআর কোড দিয়ে ইনস্ট্যান্ট ই-সিম (eSIM) নিতে আগ্রহীদের জন্য।',
    bestForEn: 'Great for digital nomads, budget travelers, and instant QR-code eSIM activations.',
    touristSimAvailable: true,
    eSimAvailable: true,
    airportBooth: true,
    color: '#E31B23',
    bgGradient: 'from-red-50/70 to-rose-50/40',
    borderColor: 'border-red-200',
    airportLocationBn: 'ঢাকা বিমানবন্দরের লাগেজ বেল্ট পরবর্তী অ্যারাইভাল লাউঞ্জে বুথ রয়েছে।',
    airportLocationEn: 'Hazrat Shahjalal Int’l Airport Arrival Concourse counter.',
    recommendedPacks: [
      {
        data: '20 GB Data + 150 Min',
        validityBn: '৩০ দিন মেয়াদ',
        validityEn: '30 Days Validity',
        bdtPrice: 449,
        descBn: 'সাশ্রয়ী মূল্যে প্রচুর ডাটা ও লোকাল কল',
        descEn: 'Budget friendly with generous data',
      },
      {
        data: '40 GB High-Speed Data',
        validityBn: '৩০ দিন মেয়াদ',
        validityEn: '30 Days Validity',
        bdtPrice: 649,
        descBn: 'হেভি ইউটিউব ও ভিডিও স্ট্রিমিং প্যাক',
        descEn: 'High capacity for video uploads and live streams',
      },
    ],
  },
  {
    id: 'banglalink',
    name: 'Banglalink',
    nameBn: 'বাংলালিংক',
    badgeBn: ' Ookla অ্যাওয়ার্ডপ্রাপ্ত দ্রুততম ৪জি স্পিড',
    badgeEn: 'Fastest 4G Speed (Ookla Winner)',
    website: 'https://www.banglalink.net',
    websiteDisplay: 'banglalink.net',
    helpline: '121',
    sloganBn: 'করছি আমরা জয়',
    sloganEn: 'Up Next • VEON Group',
    coverageRating: 4.4,
    speedRating: 4.8,
    highlightBn: 'ঢাকা, চট্টগ্রাম, সিলেটসহ বিভাগীয় শহরগুলোতে শীর্ষস্থানীয় ৪জি ইন্টারনেট গতি ও কম মূল্যের অফার।',
    highlightEn: 'Leading 4G download speed in metropolitan centers like Dhaka, Chittagong, and Sylhet.',
    bestForBn: 'শহুরে পর্যটক, দ্রুত ভিডিও আপলোডকারী এবং সোশ্যাল মিডিয়া কনটেন্ট ক্রিয়েটরদের জন্য।',
    bestForEn: 'Urban explorers and vloggers needing maximum upload speeds in key cities.',
    touristSimAvailable: true,
    eSimAvailable: true,
    airportBooth: true,
    color: '#FF6600',
    bgGradient: 'from-orange-50/70 to-amber-50/40',
    borderColor: 'border-orange-200',
    airportLocationBn: 'টার্মিনাল ২ অ্যারাইভাল লাউঞ্জ এবং এয়ারপোর্ট রোড আউটলেট।',
    airportLocationEn: 'Arrival Lounge booth & Airport Road experience center.',
    recommendedPacks: [
      {
        data: '25 GB Ultra Fast Data',
        validityBn: '৩০ দিন মেয়াদ',
        validityEn: '30 Days Validity',
        bdtPrice: 479,
        descBn: 'হাই-স্পিড ডাউনলোড ও দ্রুত ব্রাউজিং',
        descEn: 'High-speed web surfing & video calls',
      },
    ],
  },
  {
    id: 'teletalk',
    name: 'Teletalk (State-Owned)',
    nameBn: 'টেলিটক (সরকারি অপারেটর)',
    badgeBn: 'সবচেয়ে সাশ্রয়ী সরকারি নেটওয়ার্ক',
    badgeEn: 'Affordable Govt Provider',
    website: 'https://www.teletalk.com.bd',
    websiteDisplay: 'teletalk.com.bd',
    helpline: '121',
    sloganBn: 'আমাদের ফোন (The People’s Phone)',
    sloganEn: 'The People’s Phone • Govt of Bangladesh',
    coverageRating: 3.9,
    speedRating: 3.7,
    highlightBn: 'বাংলাদেশের একমাত্র সরকারি মোবাইল অপারেটর, সর্বনিম্ন কলরেট এবং ঐতিহাসিক স্থানে কাভারেজ।',
    highlightEn: 'State-owned operator with the lowest local tariffs and reach into government heritage sites.',
    bestForBn: 'ব্যাকপ্যাকার যারা খুব কম খরচে স্থানীয় সিম রাখতে চান।',
    bestForEn: 'Secondary SIM for emergency backup and cheap calling.',
    touristSimAvailable: true,
    eSimAvailable: true,
    airportBooth: false,
    color: '#28A745',
    bgGradient: 'from-emerald-50/70 to-green-50/40',
    borderColor: 'border-emerald-200',
    airportLocationBn: 'গুলশান, মতিঝিল ও কাওরানবাজার কাস্টমার কেয়ার সেন্টার।',
    airportLocationEn: 'Available at Teletalk Customer Care centers across Dhaka.',
    recommendedPacks: [
      {
        data: '10 GB Data + 100 Min',
        validityBn: '৩০ দিন মেয়াদ',
        validityEn: '30 Days Validity',
        bdtPrice: 220,
        descBn: 'অতি সুলভ মূল্যের মাসিক ডাটা প্যাক',
        descEn: 'Super low-cost local package',
      },
    ],
  },
];

// Top Must-Visit Circuits & Destinations
interface TouristDestination {
  id: string;
  nameBn: string;
  nameEn: string;
  category: 'hills' | 'sea' | 'forest' | 'heritage' | 'river';
  locationBn: string;
  locationEn: string;
  avgCostPerDayBdt: number;
  bestSeasonBn: string;
  bestSeasonEn: string;
  howToReachBn: string;
  howToReachEn: string;
  highlightsBn: string[];
  highlightsEn: string[];
  safetyTipsBn: string;
  safetyTipsEn: string;
  image?: string;
  imageAlt?: string;
  fallbackGradient?: string;
  tagBn?: string;
  tagEn?: string;
}

const DESTINATIONS: TouristDestination[] = [
  {
    id: 'coxs-bazar-stmartin',
    nameBn: 'কক্সবাজার ও সেন্টমার্টিন প্রবাল দ্বীপ',
    nameEn: "Cox's Bazar & Saint Martin Coral Island",
    category: 'sea',
    locationBn: 'চট্টগ্রাম বিভাগ (দক্ষিণ-পূর্ব বাংলাদেশ)',
    locationEn: 'Chittagong Division (South-Eastern BD)',
    avgCostPerDayBdt: 3800,
    bestSeasonBn: 'নভেম্বর থেকে মার্চ (জাহাজ চলাচল ও পরিচ্ছন্ন সমুদ্র)',
    bestSeasonEn: 'November to March (Ferry season & clear skies)',
    howToReachBn: 'ঢাকা থেকে বিমানে মাত্র ৫০ মিনিট (Cox’s Bazar Airport) অথবা নন-স্টপ এসি বাস / নতুন ট্রেন (কক্সবাজার এক্সপ্রেস)।',
    howToReachEn: 'Direct 50-min domestic flight from Dhaka, or scenic AC Express Train / Luxury Sleeper Bus.',
    highlightsBn: ['বিশ্বের দীর্ঘতম ১২০ কিমি নিরবচ্ছিন্ন বালুকাময় সমুদ্র সৈকত', 'ইনানী পাথুরে সৈকত ও মেরিন ড্রাইভ রোড', 'জাহাজে সেন্টমার্টিন দ্বীপ ভ্রমণ', 'ছেঁড়া দ্বীপের প্রবাল ও সাইক্লিং'],
    highlightsEn: ["World's longest 120km unbroken sand beach", "Scenic Marine Drive to Inani coral beach", "Cruise ship to Saint Martin Island", "Chhera Dwip cycling & fresh sea fish"],
    safetyTipsBn: 'সমুদ্রে নামার সময় লাল পতাকার সংকেত মেনে চলুন। সেন্টমার্টিনে প্লাস্টিক বর্জ্য ফেলবেন না।',
    safetyTipsEn: 'Observe beach safety flags. Carry cash to Saint Martin as ATMs are limited.',
    image: coxsBazarImg,
    imageAlt: "Cox's Bazar sunset over turquoise ocean and golden sandy shore",
    tagBn: 'বিশ্বের দীর্ঘতম সমুদ্র সৈকত',
    tagEn: "World's Longest Beach",
  },
  {
    id: 'sajek-bandarban',
    nameBn: 'সাজেক ভ্যালি ও বান্দরবানের মেঘের রাজ্য',
    nameEn: 'Sajek Valley & Bandarban Hill District',
    category: 'hills',
    locationBn: 'পার্বত্য চট্টগ্রাম (রাঙ্গামাটি ও বান্দরবান)',
    locationEn: 'Chittagong Hill Tracts (Rangamati & Bandarban)',
    avgCostPerDayBdt: 3200,
    bestSeasonBn: 'আগস্ট থেকে ফেব্রুয়ারি (বর্ষার মেঘ ও শীতের কুয়াশা)',
    bestSeasonEn: 'August to February (Floating cloud sea & cool mist)',
    howToReachBn: 'ঢাকা থেকে খাগড়াছড়ি এসি বাসে গিয়ে সেখান থেকে চাঁন্দের গাড়িতে আর্মি এসকর্ট নিয়ে সাজেক। বান্দরবানের জন্য চট্টগ্রাম হয়ে সরাসরি বাস।',
    howToReachEn: 'Overnight AC bus to Khagrachhari, then 4x4 open Chander Gari with army escort to Sajek. Direct buses to Bandarban.',
    highlightsBn: ['কটেজের বারান্দা থেকে ভাসমান মেঘের সমুদ্র', 'কংলাক পাহাড় চূড়া থেকে ৩৬০ ডিগ্রি পাহাড়ি ভিউ', 'নীলগিরি, চিম্বুক ও শৈলপ্রপাত', 'বগা লেক ও নাফাখুম জলপ্রপাত ট্র্যাকিং'],
    highlightsEn: ['Panoramic floating cloud ocean from cottage balconies', 'Konglak Peak 360-degree hilltop scenery', 'Nilgiri resort & Chimbuk hill viewpoint', 'Boga Lake & Nafakhum waterfall trekking'],
    safetyTipsBn: 'বিদেশি পর্যটকদের জন্য পার্বত্য অঞ্চলে বিশেষ ট্রাভেল পারমিট/পাসপোর্ট এন্ট্রি প্রয়োজন (সেনাবাহিনী ও প্রশাসনের সহায়তা নিন)।',
    safetyTipsEn: 'Foreign nationals require simple district registration at military checkpoints (bring passport copies).',
    image: sajekImg,
    imageAlt: 'Sajek Valley morning clouds flowing around green wooden cottages and peaks',
    tagBn: 'মেঘের রাজ্য ও কংলাক চূড়া',
    tagEn: 'Floating Cloud Kingdom',
  },
  {
    id: 'sundarbans',
    nameBn: 'সুন্দরবন ম্যানগ্রোভ বন (ইউনেস্কো বিশ্ব ঐতিহ্য)',
    nameEn: 'The Sundarbans Mangrove (UNESCO World Heritage)',
    category: 'forest',
    locationBn: 'খুলনা ও বাগেরহাট জেলা (দক্ষিণ-পশ্চিম)',
    locationEn: 'Khulna & Bagerhat Districts (South-West)',
    avgCostPerDayBdt: 4500,
    bestSeasonBn: 'নভেম্বর থেকে ফেব্রুয়ারি (শান্ত নদী ও বন্যপ্রাণী দর্শন)',
    bestSeasonEn: 'November to February (Calm river waters & deer/tiger sightings)',
    howToReachBn: 'ঢাকা থেকে খুলনায় ট্রেনে বা বাসে গিয়ে মোংলা ঘাট থেকে ৩ দিন ২ রাতের বিলাসবহুল ক্রুজ জাহাজে যাত্রা।',
    howToReachEn: 'Train/Bus to Khulna or Mongla Port, followed by a 3D/2N guided river cruise vessel with forest rangers.',
    highlightsBn: ['বিশ্বের বৃহত্তম ম্যানগ্রোভ বনভূমি ও রয়েল বেঙ্গল টাইগার', 'কোটকা অভয়ারণ্য ও জামতলা সমুদ্র সৈকত', 'হরিণ, কুমির ও ইরাবতী ডলফিন দর্শন', 'নিস্তব্ধ খাঁড়িতে কাঠের নৌকায় ক্যানাল ক্রুজ'],
    highlightsEn: ['Largest mangrove forest on Earth & Royal Bengal Tiger habitat', 'Kotka wildlife sanctuary & Jamtola watchtower', 'Spotted deer, saltwater crocodiles & dolphins', 'Silent canal country boat ride through creeks'],
    safetyTipsBn: 'বন বিভাগের সশস্ত্র গার্ড এবং লাইসেন্সধারী অনুমোদিত ট্যুর অপারেটর ছাড়া বনে নামা নিষেধ।',
    safetyTipsEn: 'Always travel with registered cruise operators and armed forest department escorts.',
    image: sundarbansImg,
    imageAlt: 'Sundarbans lush wild mangrove forest and serene river canals',
    tagBn: 'ইউনেস্কো বিশ্ব ঐতিহ্য ও রয়েল বেঙ্গল টাইগার',
    tagEn: 'UNESCO World Heritage',
  },
  {
    id: 'sreemangal-sylhet',
    nameBn: 'শ্রীমঙ্গল ও সিলেটের চায়ের বাগান ও জলপ্রপাত',
    nameEn: 'Sreemangal & Sylhet (Tea Gardens & Waterfalls)',
    category: 'hills',
    locationBn: 'সিলেট বিভাগ (উত্তর-পূর্ব বাংলাদেশ)',
    locationEn: 'Sylhet Division (North-East BD)',
    avgCostPerDayBdt: 3000,
    bestSeasonBn: 'জুন থেকে সেপ্টেম্বর (জলপ্রপাতের পূর্ণ রূপ) এবং অক্টোবর-মার্চ (চা বাগান ভ্রমণ)',
    bestSeasonEn: 'June to September (Monsoon waterfalls) and Oct-March (Tea estates)',
    howToReachBn: 'ঢাকা থেকে পারাবত বা উপবন এক্সপ্ৰেস ট্রেনে মাত্র ৪.৫ ঘণ্টায় শ্রীমঙ্গল, অথবা সিলেট ওসমানী আন্তর্জাতিক বিমানবন্দরে ফ্লাইট।',
    howToReachEn: 'Scenic 4.5-hr AC train (Parabat Express) from Dhaka or direct 45-min flight to Osmani Airport Sylhet.',
    highlightsBn: ['সবুজ গালিচায় মোড়া শ্রীমঙ্গলের শতবর্ষী চা বাগান', 'লাউয়াছড়া জাতীয় উদ্যানের রেইনফরেস্ট ট্রেইল ও উল্লুক', 'রাতারগুল সোয়াম্প ফরেস্ট (মিঠাপানির জলাবন)', 'জাফলং ও বিছনাকান্দির স্বচ্ছ পাহাড়ি নদী ও পাথর'],
    highlightsEn: ['Rolling emerald green tea gardens of Sreemangal', 'Lawachara rainforest trail & endangered Gibbons', 'Ratargul freshwater swamp forest boat ride', 'Jaflong & Bisanakandi crystal clear riverbed'],
    safetyTipsBn: 'সোয়াম্প ফরেস্টে নৌকায় চড়ার সময় লাইফ জ্যাকেট ব্যবহার নিশ্চিত করুন।',
    safetyTipsEn: 'Wear life jackets during boat rides and non-slip sandals around riverbed stones.',
    image: sreemangalImg,
    imageAlt: 'Sreemangal lush rolling tea gardens covered in emerald green leaves',
    tagBn: 'সবুজ চা বাগান ও রেইনফরেস্ট',
    tagEn: 'Tea Capital & Rainforest',
  },
  {
    id: 'tanguar-haor',
    nameBn: 'টাঙ্গুয়ার হাওড় ও সুরমা নদী ক্রুজ',
    nameEn: 'Tanguar Haor & Sunamganj River Cruise',
    category: 'river',
    locationBn: 'সুনামগঞ্জ (সিলেট বিভাগ)',
    locationEn: 'Sunamganj (Sylhet Division)',
    avgCostPerDayBdt: 3500,
    bestSeasonBn: 'জুলাই থেকে অক্টোবর (বর্ষায় বিশাল জলরাশি ও বিলাসবহুল হাউসবোট)',
    bestSeasonEn: 'July to October (Monsoon high water & luxury houseboats)',
    howToReachBn: 'ঢাকা থেকে তাহিরপুর/সুনামগঞ্জ সরাসরি এসি বাস, সেখান থেকে হাউসবোটে চেক-ইন।',
    howToReachEn: 'Direct bus from Dhaka to Sunamganj/Tahirpur, then board traditional wooden luxury houseboats.',
    highlightsBn: ['সমুদ্রের মতো সুবিশাল মিষ্টি পানির জলরাশি', 'ঐতিহ্যবাহী কাঠের লাক্সারি হাউসবোটে রাতযাপন', 'শহীদ সিরাজ লেক (নীলাদ্রি লেক) ও টেকেরঘাট চুনাপাথর', 'যাদুকাটা নদী ও বারিক্কা টিলা'],
    highlightsEn: ['Ocean-like freshwater inland wetland (Ramsar site)', 'Overnight stay in modern wood-crafted luxury houseboats', 'Niladri Lake (Shahid Siraj Lake) backdrop', 'Jadukata clear water river & Barikka hill'],
    safetyTipsBn: 'হাউসবোট বুকিংয়ের সময় বিশ্বস্ত প্ল্যাটফর্ম বা সরাসরি রেজিস্ট্রার্ড বোটের সাথে যোগাযোগ করুন।',
    safetyTipsEn: 'Book houseboats in advance during peak monsoon weekends. Solar electricity available.',
    fallbackGradient: 'from-sky-700 via-teal-700 to-emerald-900',
    tagBn: 'রামসার সাইট ও লাক্সারি হাউসবোট',
    tagEn: 'Ramsar Wetland & Houseboats',
  },
  {
    id: 'historical-heritage',
    nameBn: 'ঐতিহাসিক প্রত্নতত্ত্ব (বাগেরহাট ষাট গম্বুজ ও পাহাড়পুর)',
    nameEn: 'Archaeological Heritage (Sixty Dome Mosque & Paharpur)',
    category: 'heritage',
    locationBn: 'খুলনা ও রাজশাহী/নওগাঁ বিভাগ',
    locationEn: 'Khulna & Rajshahi Divisions',
    avgCostPerDayBdt: 2400,
    bestSeasonBn: 'অক্টোবর থেকে মার্চ (শীতকালের আরামদায়ক আবহাওয়া)',
    bestSeasonEn: 'October to March (Pleasant mild winter breeze)',
    howToReachBn: 'পাহাড়পুরের জন্য জয়পুরহাট বা সান্তাহারগামী ট্রেনে। ষাট গম্বুজ মসজিদের জন্য ঢাকা থেকে পদ্মা সেতু হয়ে সরাসরি বাসে বাগেরহাট।',
    howToReachEn: 'Smooth transit via Padma Bridge highway to Bagerhat. High-speed intercity train to Paharpur.',
    highlightsBn: ['বাগেরহাটের ষাট গম্বুজ মসজিদ (১৫ শতকের সুলতানি স্থাপত্য)', 'পাহাড়পুর সোমপুর মহাবিহার (বৌদ্ধ যুগের বৃহত্তম বিহার)', 'মহাস্থানগড় ও পুঠিয়া রাজবাড়ি কমপ্লেক্স', 'লালবাগ কেল্লা ও আহসান মঞ্জিল (পুরান ঢাকা)'],
    highlightsEn: ['Sixty Dome Mosque in Bagerhat (15th-century architecture)', 'Somapura Mahavihara at Paharpur (Buddhist UNESCO site)', 'Mahasthangarh ancient citadel & Puthia Temple city', 'Lalbagh Fort & Ahsan Manzil Pink Palace in Dhaka'],
    safetyTipsBn: 'ঐতিহাসিক স্থাপনায় টিকিট কাউন্টারে পাসপোর্ট বা এনআইডি দেখিয়ে সরকারি মূল্যে টিকিট সংগ্রহ করুন।',
    safetyTipsEn: 'Govt ticket counters offer modest pricing. Wear modest clothing inside holy mosque complexes.',
    fallbackGradient: 'from-amber-800 via-orange-900 to-stone-900',
    tagBn: 'ইউনেস্কো সুলতানি ও বৌদ্ধ স্থাপত্য',
    tagEn: 'Ancient Medieval Heritage',
  },
];

// =====================================================================
// DHAKA METRO RAIL (MRT LINE 6) STATIONS, FARE MATRIX & SMART CARDS DATA
// =====================================================================
export interface MetroStation {
  id: string;
  nameBn: string;
  nameEn: string;
  code: string;
  distKm: number;
}

export const METRO_LINE_6_STATIONS: MetroStation[] = [
  { id: 'uttara-north', nameBn: 'উত্তরা উত্তর (দিয়াবাড়ী)', nameEn: 'Uttara North (Diabari)', code: 'UN', distKm: 0.0 },
  { id: 'uttara-center', nameBn: 'উত্তরা সেন্টার', nameEn: 'Uttara Center', code: 'UC', distKm: 1.5 },
  { id: 'uttara-south', nameBn: 'উত্তরা দক্ষিণ', nameEn: 'Uttara South', code: 'US', distKm: 2.8 },
  { id: 'pallabi', nameBn: 'পল্লবী', nameEn: 'Pallabi', code: 'PL', distKm: 4.6 },
  { id: 'mirpur-11', nameBn: 'মিরপুর ১১', nameEn: 'Mirpur 11', code: 'M11', distKm: 6.0 },
  { id: 'mirpur-10', nameBn: 'মিরপুর ১০', nameEn: 'Mirpur 10', code: 'M10', distKm: 7.2 },
  { id: 'kazipara', nameBn: 'কাজীপাড়া', nameEn: 'Kazipara', code: 'KP', distKm: 8.4 },
  { id: 'shewrapara', nameBn: 'শেওড়াপাড়া', nameEn: 'Shewrapara', code: 'SP', distKm: 9.3 },
  { id: 'agargaon', nameBn: 'আগারগাঁও', nameEn: 'Agargaon', code: 'AG', distKm: 11.7 },
  { id: 'bijoy-sarani', nameBn: 'বিজয় সরণি', nameEn: 'Bijoy Sarani', code: 'BS', distKm: 13.1 },
  { id: 'farmgate', nameBn: 'ফার্মগেট', nameEn: 'Farmgate', code: 'FG', distKm: 14.2 },
  { id: 'karwan-bazar', nameBn: 'কারওয়ান বাজার', nameEn: 'Karwan Bazar', code: 'KB', distKm: 15.3 },
  { id: 'shahbagh', nameBn: 'শাহবাগ', nameEn: 'Shahbagh', code: 'SB', distKm: 16.5 },
  { id: 'dhaka-university', nameBn: 'ঢাকা বিশ্ববিদ্যালয়', nameEn: 'Dhaka University', code: 'DU', distKm: 17.8 },
  { id: 'bangladesh-secretariat', nameBn: 'বাংলাদেশ সচিবালয়', nameEn: 'Bangladesh Secretariat', code: 'SC', distKm: 18.9 },
  { id: 'motijheel', nameBn: 'মতিঝিল', nameEn: 'Motijheel', code: 'MJ', distKm: 20.1 },
];

export const calculateMetroFare = (fromIdx: number, toIdx: number): { singleFare: number; rapidPassFare: number; stationsCount: number; distKm: number } => {
  if (fromIdx === toIdx) {
    return { singleFare: 0, rapidPassFare: 0, stationsCount: 0, distKm: 0 };
  }
  const minIdx = Math.min(fromIdx, toIdx);
  const maxIdx = Math.max(fromIdx, toIdx);
  const stationsCount = maxIdx - minIdx;
  const distKm = Math.abs(METRO_LINE_6_STATIONS[maxIdx].distKm - METRO_LINE_6_STATIONS[minIdx].distKm);

  let singleFare = 20;
  if (distKm <= 2) singleFare = 20;
  else if (distKm <= 5) singleFare = 30;
  else if (distKm <= 7) singleFare = 40;
  else if (distKm <= 9) singleFare = 50;
  else if (distKm <= 11) singleFare = 60;
  else if (distKm <= 13) singleFare = 70;
  else if (distKm <= 16) singleFare = 80;
  else if (distKm <= 18) singleFare = 90;
  else singleFare = 100;

  const rapidPassFare = Math.round(singleFare * 0.9);
  return { singleFare, rapidPassFare, stationsCount, distKm: Number(distKm.toFixed(1)) };
};

export const TouristHandbook: React.FC<TouristHandbookProps> = ({ lang }) => {
  const [selectedCurrency, setSelectedCurrency] = useState<CurrencyType>('BDT');
  const [activeSubTab, setActiveSubTab] = useState<'emergency' | 'tickets' | 'sim' | 'budget' | 'destinations' | 'facilities' | 'about'>('emergency');
  const [copiedNumber, setCopiedNumber] = useState<string | null>(null);
  const [emergencyFilter, setEmergencyFilter] = useState<string>('all');
  const [destinationFilter, setDestinationFilter] = useState<string>('all');
  const [metroOrigin, setMetroOrigin] = useState<string>('uttara-north');
  const [metroDestination, setMetroDestination] = useState<string>('motijheel');

  // Live Exchange Rates (BDT equivalent of 1 currency unit)
  const [liveRates, setLiveRates] = useState<Record<string, number>>({
    USD: 122.5,
    EUR: 132.8,
    GBP: 158.4,
    SAR: 32.65,
    AED: 33.35,
    CAD: 89.2,
    INR: 1.45,
    MYR: 27.8,
    SGD: 93.5,
    BDT: 1,
  });
  const [lastUpdatedRates, setLastUpdatedRates] = useState<string>('Live (12 Oct 2026)');
  const [isLoadingRates, setIsLoadingRates] = useState<boolean>(false);
  const [rateFetchSuccess, setRateFetchSuccess] = useState<boolean>(false);

  // Quick Currency Converter calculator states
  const [calcAmount, setCalcAmount] = useState<number>(100);
  const [calcFromCurrency, setCalcFromCurrency] = useState<string>('USD');
  const [calcToCurrency, setCalcToCurrency] = useState<string>('BDT');

  // Fetch live exchange rates from public API
  const fetchLiveRates = async () => {
    setIsLoadingRates(true);
    try {
      const res = await fetch('https://open.er-api.com/v6/latest/USD');
      if (res.ok) {
        const data = await res.json();
        if (data && data.rates && data.rates.BDT) {
          const usdBdt = Number(data.rates.BDT);
          const newRates: Record<string, number> = {
            USD: usdBdt,
            EUR: usdBdt / (data.rates.EUR || 0.92),
            GBP: usdBdt / (data.rates.GBP || 0.77),
            SAR: usdBdt / (data.rates.SAR || 3.75),
            AED: usdBdt / (data.rates.AED || 3.67),
            CAD: usdBdt / (data.rates.CAD || 1.37),
            INR: usdBdt / (data.rates.INR || 84.0),
            MYR: usdBdt / (data.rates.MYR || 4.3),
            SGD: usdBdt / (data.rates.SGD || 1.31),
            BDT: 1,
          };
          setLiveRates(newRates);
          const nowTime = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
          setLastUpdatedRates(nowTime);
          setRateFetchSuccess(true);
          setTimeout(() => setRateFetchSuccess(false), 3000);
        }
      }
    } catch {
      // Keep robust baseline rates if offline
    } finally {
      setIsLoadingRates(false);
    }
  };

  useEffect(() => {
    fetchLiveRates();
  }, []);

  // Budget Calculator state
  const [tripDays, setTripDays] = useState<number>(7);
  const [travelStyle, setTravelStyle] = useState<'budget' | 'standard' | 'luxury'>('standard');
  const [numTravelers, setNumTravelers] = useState<number>(2);

  const currencyMeta = CURRENCY_RATES[selectedCurrency];

  const formatPrice = (bdt: number): string => {
    if (selectedCurrency === 'BDT') {
      return `৳${Math.round(bdt).toLocaleString('en-US')}`;
    }
    const rateToBdt = liveRates[selectedCurrency] || (selectedCurrency === 'USD' ? 122.5 : selectedCurrency === 'EUR' ? 132.8 : 33.35);
    const converted = bdt / rateToBdt;
    if (selectedCurrency === 'USD') {
      return `$${converted.toFixed(2)}`;
    }
    if (selectedCurrency === 'EUR') {
      return `€${converted.toFixed(2)}`;
    }
    if (selectedCurrency === 'AED') {
      return `${converted.toFixed(1)} AED`;
    }
    return `${Math.round(converted)}`;
  };

  const handleCopyNumber = (num: string) => {
    navigator.clipboard.writeText(num);
    setCopiedNumber(num);
    setTimeout(() => setCopiedNumber(null), 2500);
  };

  // Filtered emergency contacts
  const filteredEmergency = useMemo(() => {
    if (emergencyFilter === 'all') return EMERGENCY_CONTACTS;
    return EMERGENCY_CONTACTS.filter((c) => c.tag === emergencyFilter);
  }, [emergencyFilter]);

  // Filtered destinations
  const filteredDestinations = useMemo(() => {
    if (destinationFilter === 'all') return DESTINATIONS;
    return DESTINATIONS.filter((d) => d.category === destinationFilter);
  }, [destinationFilter]);

  // Daily costs based on travel style
  const styleDailyCostBdt = {
    budget: 2200, // Budget backpacker
    standard: 5500, // Mid-range 3-star AC, ride sharing
    luxury: 18000, // 5-star, domestic flights, chauffeur
  };

  const totalCalculatedCostBdt = styleDailyCostBdt[travelStyle] * tripDays * numTravelers;
  const perPersonDailyCostBdt = styleDailyCostBdt[travelStyle];

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Main Feature Sub-Navigation Tabs - Premium Sleek Modern Pill Bar */}
      <div className="bg-[#ede8df]/80 backdrop-blur-md p-1.5 rounded-2xl flex items-center gap-1.5 overflow-x-auto scrollbar-none border border-[#e2dcd2] shadow-2xs">
        <button
          onClick={() => setActiveSubTab('tickets')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold whitespace-nowrap transition-all duration-300 cursor-pointer ${
            activeSubTab === 'tickets'
              ? 'bg-white text-[#0f6b4f] shadow-sm font-black scale-[1.02] ring-1 ring-[#0f6b4f]/15'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
          }`}
        >
          <Car className={`w-4 h-4 transition-transform duration-300 ${activeSubTab === 'tickets' ? 'text-emerald-700 scale-110' : 'text-slate-500'}`} />
          <span>{lang === 'bn' ? 'রাইড ও টিকিট' : 'Rides & Tickets'}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('emergency')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold whitespace-nowrap transition-all duration-300 cursor-pointer ${
            activeSubTab === 'emergency'
              ? 'bg-white text-rose-600 shadow-sm font-black scale-[1.02] ring-1 ring-rose-200'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
          }`}
        >
          <PhoneCall className={`w-4 h-4 transition-transform duration-300 ${activeSubTab === 'emergency' ? 'text-rose-600 scale-110' : 'text-slate-500'}`} />
          <span>{lang === 'bn' ? 'জরুরি হেল্পলাইন (৯৯৯)' : 'Emergency (999)'}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('sim')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold whitespace-nowrap transition-all duration-300 cursor-pointer ${
            activeSubTab === 'sim'
              ? 'bg-white text-[#0f6b4f] shadow-sm font-black scale-[1.02] ring-1 ring-[#0f6b4f]/15'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
          }`}
        >
          <Smartphone className={`w-4 h-4 transition-transform duration-300 ${activeSubTab === 'sim' ? 'text-emerald-700 scale-110' : 'text-slate-500'}`} />
          <span>{lang === 'bn' ? 'সিম ও ইন্টারনেট' : 'SIM & Data'}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('budget')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold whitespace-nowrap transition-all duration-300 cursor-pointer ${
            activeSubTab === 'budget'
              ? 'bg-white text-[#0f6b4f] shadow-sm font-black scale-[1.02] ring-1 ring-[#0f6b4f]/15'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
          }`}
        >
          <DollarSign className={`w-4 h-4 transition-transform duration-300 ${activeSubTab === 'budget' ? 'text-emerald-700 scale-110' : 'text-slate-500'}`} />
          <span>{lang === 'bn' ? 'ডলার রেট ও বাজেট' : 'FX & Budget'}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('destinations')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold whitespace-nowrap transition-all duration-300 cursor-pointer ${
            activeSubTab === 'destinations'
              ? 'bg-white text-[#0f6b4f] shadow-sm font-black scale-[1.02] ring-1 ring-[#0f6b4f]/15'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
          }`}
        >
          <Compass className={`w-4 h-4 transition-transform duration-300 ${activeSubTab === 'destinations' ? 'text-emerald-700 scale-110' : 'text-slate-500'}`} />
          <span>{lang === 'bn' ? 'দর্শনীয় স্থান' : 'Destinations'}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('facilities')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold whitespace-nowrap transition-all duration-300 cursor-pointer ${
            activeSubTab === 'facilities'
              ? 'bg-white text-[#0f6b4f] shadow-sm font-black scale-[1.02] ring-1 ring-[#0f6b4f]/15'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
          }`}
        >
          <Hotel className={`w-4 h-4 transition-transform duration-300 ${activeSubTab === 'facilities' ? 'text-emerald-700 scale-110' : 'text-slate-500'}`} />
          <span>{lang === 'bn' ? 'সুবিধা ও নিয়ম' : 'Facilities'}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('about')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold whitespace-nowrap transition-all duration-300 cursor-pointer ${
            activeSubTab === 'about'
              ? 'bg-white text-[#0f6b4f] shadow-sm font-black scale-[1.02] ring-1 ring-[#0f6b4f]/15'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
          }`}
        >
          <Info className={`w-4 h-4 transition-transform duration-300 ${activeSubTab === 'about' ? 'text-emerald-700 scale-110' : 'text-slate-500'}`} />
          <span>{lang === 'bn' ? 'বাংলাদেশ সম্পর্কে' : 'About BD'}</span>
        </button>
      </div>

      {/* ============================================================== */}
      {/* 0. RIDE SHARING, BUS TICKETS & METRO RAIL */}
      {/* ============================================================== */}
      {activeSubTab === 'tickets' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#ebe6dc]">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-bold text-[#0f6b4f] flex items-center gap-1.5">
                  <Ticket className="w-4 h-4" />
                  {lang === 'bn' ? 'পরিবহন ও টিকিট সেবা' : 'Transit & Ticketing'}
                </span>
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-slate-900">
                {lang === 'bn' ? 'রাইড শেয়ারিং, বাস টিকিট ও মেট্রোরেল' : 'Ride Sharing, Bus Tickets & Metro Rail'}
              </h3>
            </div>

            {/* Quick official Metro portal pill */}
            <a
              href="https://dmtcl.gov.bd/"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3.5 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs transition-all shadow-xs inline-flex items-center justify-center gap-1.5 shrink-0 self-start sm:self-auto"
            >
              <TrainFront className="w-3.5 h-3.5" />
              <span>{lang === 'bn' ? 'মেট্রোরেল ওয়েবসাইট (DMTCL)' : 'Dhaka Metro (DMTCL)'}</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          {/* 1. RIDE SHARING WEBSITES */}
          <div className="bg-white border border-[#ebe6dc] rounded-2xl p-5 sm:p-6 shadow-xs">
            <div className="flex items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center">
                  <Car className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-base sm:text-lg font-black text-slate-900">
                    {lang === 'bn' ? '১. রাইড শেয়ারিং ওয়েবসাইট ও সেবা' : '1. Ride Sharing Portals'}
                  </h4>
                  <p className="text-xs text-slate-500">
                    {lang === 'bn' ? 'সরাসরি ওয়েবসাইটে গিয়ে বা অ্যাপে রাইড বুক করুন' : 'Instant city rides and airport pickups'}
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {/* Pathao */}
              <div className="p-4 rounded-xl border border-red-100 bg-red-50/30 flex flex-col justify-between hover:border-red-300 transition-all">
                <div className="mb-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="w-7 h-7 rounded-lg bg-red-600 text-white flex items-center justify-center font-black text-xs">P</span>
                      <span className="font-extrabold text-sm text-slate-900">Pathao Ride</span>
                    </div>
                    <span className="text-[10px] font-bold text-red-700 bg-red-100 px-2 py-0.5 rounded-full">পাঠাও</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {lang === 'bn' ? 'বাইক রাইড, এসি কার এবং পার্সেল সার্ভিস বুকিং।' : 'Motorbike rides, AC cars and instant courier.'}
                  </p>
                </div>
                <a
                  href="https://pathao.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-red-600 hover:bg-red-700 text-white font-bold text-xs py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5"
                >
                  <span>{lang === 'bn' ? 'পাঠাও ওয়েবসাইটে যান' : 'Visit Pathao Website'}</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              {/* Uber */}
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between hover:border-slate-300 transition-all">
                <div className="mb-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="w-7 h-7 rounded-lg bg-black text-white flex items-center justify-center font-black text-xs">UB</span>
                      <span className="font-extrabold text-sm text-slate-900">Uber Ride</span>
                    </div>
                    <span className="text-[10px] font-bold text-slate-800 bg-slate-200 px-2 py-0.5 rounded-full">উবার</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {lang === 'bn' ? 'ঢাকা এয়ারপোর্ট পিকআপ, উবার প্রিমিয়ার ও কার রাইড।' : 'Airport terminal pickups, premier cabs and cars.'}
                  </p>
                </div>
                <a
                  href="https://m.uber.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-slate-900 hover:bg-black text-white font-bold text-xs py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5"
                >
                  <span>{lang === 'bn' ? 'উবার ওয়েবসাইটে যান' : 'Visit Uber Website'}</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              {/* Obhai */}
              <div className="p-4 rounded-xl border border-emerald-100 bg-emerald-50/30 flex flex-col justify-between hover:border-emerald-300 transition-all">
                <div className="mb-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-black text-xs">OB</span>
                      <span className="font-extrabold text-sm text-slate-900">OBHAI</span>
                    </div>
                    <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full">ওভাই সিএনজি</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {lang === 'bn' ? 'সিএনজি অটো-রিকশা ও কার রাইড শেয়ারিং প্ল্যাটফর্ম।' : 'CNG auto-rickshaw meters and city car rides.'}
                  </p>
                </div>
                <a
                  href="https://www.obhai.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5"
                >
                  <span>{lang === 'bn' ? 'ওভাই ওয়েবসাইটে যান' : 'Visit OBHAI Website'}</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>

          {/* 2. BUS TICKET WEBSITES */}
          <div className="bg-white border border-[#ebe6dc] rounded-2xl p-5 sm:p-6 shadow-xs">
            <div className="flex items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
                  <Bus className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-base sm:text-lg font-black text-slate-900">
                    {lang === 'bn' ? '২. বাস টিকিট কাটার অফিসিয়াল ওয়েবসাইট' : '2. Bus Ticket Booking Websites'}
                  </h4>
                  <p className="text-xs text-slate-500">
                    {lang === 'bn' ? 'অনলাইনে সরাসরি সিট পছন্দ করে টিকিট কেনার বিশ্বস্ত লিঙ্ক' : 'Online bus ticket portals & official operator websites'}
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3.5">
              {[
                { name: 'Shohoz Bus', tagBn: 'অল-ইন-ওয়ান', tagEn: 'All in One', descBn: 'হানিফ, শ্যামলী, এনা সহ সব বাস টিকিট।', descEn: '50+ operators, seats selection.', url: 'https://www.shohoz.com/bus-tickets', color: 'emerald' },
                { name: 'Busbd.com.bd', tagBn: 'পোর্টাল', tagEn: 'Portal', descBn: 'দেশব্যাপী বিভিন্ন রুটের বাস টিকিট।', descEn: 'Intercity online bus booking portal.', url: 'https://busbd.com.bd/', color: 'purple' },
                { name: 'গ্রীন লাইন পরিবহন', tagBn: 'Green Line', tagEn: 'Luxury AC', descBn: 'স্ক্যানিয়া স্লিপার ও এসি বাস টিকিট।', descEn: 'Scania multi-axle sleeper bus.', url: 'https://greenlinebd.com/', color: 'emerald' },
                { name: 'হানিফ এন্টারপ্রাইজ', tagBn: 'Hanif', tagEn: 'Nationwide', descBn: 'সারাদেশের বৃহত্তম বাস নেটওয়ার্ক।', descEn: 'Largest bus network across 64 districts.', url: 'https://hanifenterprise.com/', color: 'red' },
                { name: 'শ্যামলী পরিবহন', tagBn: 'Shyamoli', tagEn: 'NR Travels', descBn: 'দেশব্যাপী ও কলকাতা আন্তর্জাতিক বাস।', descEn: 'Trusted AC & Kolkata international route.', url: 'https://shyamolibd.com/', color: 'blue' },
                { name: 'এনা ট্রান্সপোর্ট', tagBn: 'Ena', tagEn: 'Sylhet Route', descBn: 'সিলেট, মৌলভীবাজার ও উত্তরবঙ্গ রুট।', descEn: 'Fast express buses to Sylhet & North.', url: 'https://enatransport.com/', color: 'amber' },
                { name: 'দেশ ট্রাভেলস', tagBn: 'Desh', tagEn: 'Rajshahi', descBn: 'রাজশাহী ও চাঁপাইনবাবগঞ্জ এসি বাস।', descEn: 'Hyundai luxury coaches for Rajshahi.', url: 'https://deshtravelsbd.com/', color: 'sky' },
                { name: 'সেন্টমার্টিন পরিবহন', tagBn: 'Saintmartin', tagEn: 'Cox’s Bazar', descBn: 'কক্সবাজার ও টেকনাফ বিচ এক্সপ্রেস।', descEn: 'Direct coaches to Cox’s Bazar & beach.', url: 'https://saintmartinparibahan.com/', color: 'teal' },
              ].map((bus, idx) => (
                <div key={idx} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/40 hover:bg-white hover:border-slate-300 transition-all flex flex-col justify-between">
                  <div className="mb-2.5">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="font-extrabold text-xs text-slate-900">{bus.name}</span>
                      <span className="text-[9px] font-bold text-slate-700 bg-slate-200 px-1.5 py-0.5 rounded-full">
                        {lang === 'bn' ? bus.tagBn : bus.tagEn}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600 line-clamp-2">
                      {lang === 'bn' ? bus.descBn : bus.descEn}
                    </p>
                  </div>
                  <a
                    href={bus.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full bg-slate-900 hover:bg-black text-white font-bold text-[11px] py-1.5 px-2.5 rounded-lg transition-all flex items-center justify-center gap-1.5"
                  >
                    <span>{lang === 'bn' ? 'টিকিট কাটুন' : 'Book Ticket'}</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              ))}
            </div>
          </div>

          {/* 3. DHAKA METRO RAIL (MRT LINE 6) - MAP, FARE MATRIX, WEBSITES & SMART CARDS */}
          <div className="bg-white border-2 border-emerald-600/30 rounded-2xl p-5 sm:p-6 shadow-sm space-y-6">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-700 text-white flex items-center justify-center font-bold shadow-xs">
                  <TrainFront className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-lg sm:text-xl font-black text-slate-900">
                      {lang === 'bn' ? '৩. ঢাকা মেট্রোরেল (এমআরটি লাইন-৬)' : '3. Dhaka Metro Rail (MRT Line-6)'}
                    </h4>
                    <span className="text-[10px] font-black bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full uppercase">
                      MRT-6
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">
                    {lang === 'bn'
                      ? 'উত্তরা উত্তর (দিয়াবাড়ী) থেকে মতিঝিল পর্যন্ত ১৬টি স্টেশন ও লাইভ ভাড়া তালিকা'
                      : 'Uttara North to Motijheel — 16 elevated stations, route map & fare calculator'}
                  </p>
                </div>
              </div>

              {/* Direct links to DMTCL & Rapid Pass */}
              <div className="flex flex-wrap items-center gap-2">
                <a
                  href="https://dmtcl.gov.bd/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs transition-all flex items-center gap-1"
                >
                  <span>{lang === 'bn' ? 'অফিসিয়াল DMTCL ওয়েবসাইট' : 'Official DMTCL Website'}</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
                <a
                  href="https://rapidpass.com.bd/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs transition-all flex items-center gap-1"
                >
                  <span>{lang === 'bn' ? 'র‍্যাপিড পাস পোর্টাল' : 'Rapid Pass Portal'}</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>

            {/* A. VISUAL METRO ROUTE MAP (উত্তরা থেকে মতিঝিল) */}
            <div className="bg-[#fcfbf9] border border-[#ebe6dc] rounded-2xl p-4 sm:p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-emerald-600 animate-pulse" />
                  <h5 className="font-extrabold text-sm text-slate-900">
                    {lang === 'bn' ? 'মেট্রোরেল রুট ম্যাপ (এমআরটি লাইন ৬)' : 'Metro Rail Route Map (MRT Line 6)'}
                  </h5>
                </div>
                <span className="text-[11px] font-mono font-bold text-slate-500">
                  {lang === 'bn' ? 'মোট ২০.১ কিমি • ১৬টি স্টেশন' : 'Total 20.1 km • 16 Stations'}
                </span>
              </div>

              {/* Graphical Line Strip */}
              <div className="overflow-x-auto pb-4 pt-2">
                <div className="min-w-[850px] px-3">
                  {/* Track Bar */}
                  <div className="relative flex items-center justify-between mb-3">
                    <div className="absolute top-1/2 left-3 right-3 h-2 bg-emerald-600 rounded-full -translate-y-1/2 z-0 shadow-inner" />
                    {METRO_LINE_6_STATIONS.map((station, idx) => {
                      const isOrigin = station.id === metroOrigin;
                      const isDest = station.id === metroDestination;
                      const originIdx = METRO_LINE_6_STATIONS.findIndex((s) => s.id === metroOrigin);
                      const destIdx = METRO_LINE_6_STATIONS.findIndex((s) => s.id === metroDestination);
                      const minI = Math.min(originIdx, destIdx);
                      const maxI = Math.max(originIdx, destIdx);
                      const isInRoute = idx >= minI && idx <= maxI;

                      return (
                        <button
                          key={station.id}
                          onClick={() => {
                            if (station.id === metroOrigin) return;
                            setMetroDestination(station.id);
                          }}
                          title={`${station.nameEn} (${station.nameBn}) - ${station.distKm} km`}
                          className="relative z-10 flex flex-col items-center group cursor-pointer"
                        >
                          <div
                            className={`w-6 h-6 rounded-full flex items-center justify-center font-mono text-[9px] font-black transition-all ${
                              isOrigin
                                ? 'bg-amber-400 text-slate-900 ring-4 ring-amber-200 scale-125 shadow-md'
                                : isDest
                                ? 'bg-rose-600 text-white ring-4 ring-rose-200 scale-125 shadow-md'
                                : isInRoute
                                ? 'bg-emerald-500 text-white ring-2 ring-emerald-200'
                                : 'bg-white text-emerald-800 border-2 border-emerald-600 hover:scale-110'
                            }`}
                          >
                            {idx + 1}
                          </div>
                          <span
                            className={`mt-2 text-[10px] text-center font-bold max-w-[55px] leading-tight transition-colors ${
                              isOrigin
                                ? 'text-amber-700 font-black'
                                : isDest
                                ? 'text-rose-700 font-black'
                                : isInRoute
                                ? 'text-emerald-900 font-extrabold'
                                : 'text-slate-600 group-hover:text-slate-900'
                            }`}
                          >
                            {lang === 'bn' ? station.nameBn.split(' ')[0] : station.code}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 font-semibold px-2 pt-1 border-t border-slate-200">
                    <span className="text-emerald-800 font-bold">
                      {lang === 'bn' ? '⬅ উত্তরা উত্তর (দিয়াবাড়ী)' : '⬅ Uttara North (Diabari)'}
                    </span>
                    <span className="text-slate-400 font-mono text-[10px]">
                      {lang === 'bn' ? 'স্টেশনে ক্লিক করে গন্তব্য পরিবর্তন করুন' : 'Click any station node to set destination'}
                    </span>
                    <span className="text-emerald-800 font-bold">
                      {lang === 'bn' ? 'মতিঝিল (বাণিজ্যিক এলাকা) ➡' : 'Motijheel (Commercial Hub) ➡'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* B. INTERACTIVE FARE CALCULATOR (কোথা থেকে কতটুকু ভাড়া) */}
            <div className="bg-gradient-to-br from-emerald-50/60 via-white to-amber-50/40 border border-emerald-200 rounded-2xl p-4 sm:p-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 pb-3 border-b border-emerald-100">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                    ৳
                  </div>
                  <div>
                    <h5 className="font-black text-base text-slate-900">
                      {lang === 'bn' ? 'ভাড়া ক্যালকুলেটর: কোথা থেকে কত ভাড়া?' : 'Interactive Fare Calculator'}
                    </h5>
                    <p className="text-[11px] text-slate-500">
                      {lang === 'bn'
                        ? 'উত্তোলনের স্টেশন এবং নামার স্টেশন নির্বাচন করুন'
                        : 'Select boarding and destination stations to see official ticket price'}
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2.5 py-1 rounded-full self-start sm:self-auto">
                  {lang === 'bn' ? 'DMTCL সরকারি রেট' : 'Govt Approved Tariffs'}
                </span>
              </div>

              {/* Selectors */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-5">
                {/* From Station */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                    <span>{lang === 'bn' ? 'কোথা থেকে (বোর্ডিং স্টেশন):' : 'Boarding From Station:'}</span>
                  </label>
                  <select
                    value={metroOrigin}
                    onChange={(e) => setMetroOrigin(e.target.value)}
                    className="w-full bg-white border-2 border-slate-200 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm font-bold text-slate-900 focus:outline-hidden focus:border-emerald-600 transition-all cursor-pointer"
                  >
                    {METRO_LINE_6_STATIONS.map((s, idx) => (
                      <option key={s.id} value={s.id}>
                        {idx + 1}. {lang === 'bn' ? s.nameBn : s.nameEn}
                      </option>
                    ))}
                  </select>
                </div>

                {/* To Station */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-600" />
                    <span>{lang === 'bn' ? 'কোথায় যাবেন (গন্তব্য স্টেশন):' : 'Destination Station:'}</span>
                  </label>
                  <select
                    value={metroDestination}
                    onChange={(e) => setMetroDestination(e.target.value)}
                    className="w-full bg-white border-2 border-slate-200 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm font-bold text-slate-900 focus:outline-hidden focus:border-emerald-600 transition-all cursor-pointer"
                  >
                    {METRO_LINE_6_STATIONS.map((s, idx) => (
                      <option key={s.id} value={s.id}>
                        {idx + 1}. {lang === 'bn' ? s.nameBn : s.nameEn}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Calculated Results Box */}
              {(() => {
                const originIdx = METRO_LINE_6_STATIONS.findIndex((s) => s.id === metroOrigin);
                const destIdx = METRO_LINE_6_STATIONS.findIndex((s) => s.id === metroDestination);
                const fareData = calculateMetroFare(originIdx, destIdx);
                const originStation = METRO_LINE_6_STATIONS[originIdx];
                const destStation = METRO_LINE_6_STATIONS[destIdx];

                return (
                  <div className="bg-white rounded-xl p-4 border border-emerald-200 shadow-xs">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      {/* Route Path summary */}
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
                          <span>{lang === 'bn' ? 'নির্বাচিত রুট:' : 'Selected Route:'}</span>
                          <span className="font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md font-bold">
                            {fareData.distKm} km • {fareData.stationsCount} {lang === 'bn' ? 'টি স্টেশন ব্যবধান' : 'stations gap'}
                          </span>
                        </div>
                        <div className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
                          <span className="text-amber-700">{lang === 'bn' ? originStation?.nameBn : originStation?.nameEn}</span>
                          <span className="text-slate-400">➔</span>
                          <span className="text-rose-700">{lang === 'bn' ? destStation?.nameBn : destStation?.nameEn}</span>
                        </div>
                      </div>

                      {/* Pricing Pills */}
                      <div className="flex items-center gap-3">
                        {/* Single Journey Ticket */}
                        <div className="bg-slate-50 border border-slate-200 px-4 py-2.5 rounded-xl text-center">
                          <div className="text-[10px] font-bold text-slate-500 uppercase">
                            {lang === 'bn' ? 'সিঙ্গেল টিকিট' : 'Single Ticket'}
                          </div>
                          <div className="text-2xl font-black text-slate-900">
                            ৳{fareData.singleFare}
                          </div>
                          <div className="text-[9px] text-slate-400">
                            {lang === 'bn' ? 'নগদ / কাউন্টার কয়েন' : 'Standard token'}
                          </div>
                        </div>

                        {/* MRT / Rapid Pass (10% Discount) */}
                        <div className="bg-emerald-600 text-white px-4 py-2.5 rounded-xl text-center shadow-xs">
                          <div className="text-[10px] font-black text-amber-300 uppercase flex items-center justify-center gap-1">
                            <span>MRT/র‍্যাপিড পাস</span>
                            <span className="bg-amber-400 text-slate-900 text-[8px] font-black px-1 rounded-sm">১০% ছাড়</span>
                          </div>
                          <div className="text-2xl font-black text-white">
                            ৳{fareData.rapidPassFare}
                          </div>
                          <div className="text-[9px] text-emerald-100">
                            {lang === 'bn' ? 'স্মার্টকার্ড ট্যাপ' : 'Smart Card tap'}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* C. POPULAR KEY ROUTE FARES TABLE (এক নজরে প্রধান রুটসমূহের ভাড়া) */}
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
              <div className="bg-slate-50 px-4 py-3 border-b border-slate-200 flex items-center justify-between">
                <span className="text-xs font-black text-slate-900">
                  {lang === 'bn' ? 'প্রধান প্রধান রুটের সরকারি ভাড়া চার্ট' : 'Quick Key Route Fare Tariffs'}
                </span>
                <span className="text-[10px] font-bold text-slate-500">
                  {lang === 'bn' ? 'সর্বনিম্ন ভাড়া ২০ টাকা • সর্বোচ্চ ১০০ টাকা' : 'Min ৳20 • Max ৳100'}
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 divide-x divide-y divide-slate-100 text-xs">
                {[
                  { from: 'উত্তরা', to: 'মতিঝিল', fare: 100, cardFare: 90 },
                  { from: 'উত্তরা', to: 'আগারগাঁও', fare: 60, cardFare: 54 },
                  { from: 'উত্তরা', to: 'মিরপুর ১০', fare: 40, cardFare: 36 },
                  { from: 'মিরপুর ১০', to: 'মতিঝিল', fare: 60, cardFare: 54 },
                  { from: 'আগারগাঁও', to: 'মতিঝিল', fare: 50, cardFare: 45 },
                  { from: 'ফার্মগেট', to: 'মতিঝিল', fare: 30, cardFare: 27 },
                ].map((route, i) => (
                  <div key={i} className="p-3 text-center bg-white hover:bg-slate-50 transition-colors">
                    <div className="font-bold text-slate-800 text-[11px] mb-1">
                      {route.from} ➔ {route.to}
                    </div>
                    <div className="text-base font-black text-slate-900">৳{route.fare}</div>
                    <div className="text-[10px] font-bold text-emerald-700">পাস: ৳{route.cardFare}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* D. METRO SMART CARDS GUIDE (মেট্রো কার্ডের নাম ও ব্যবহারের নিয়ম) */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-emerald-700" />
                <h5 className="font-black text-sm text-slate-900">
                  {lang === 'bn'
                    ? 'মেট্রোরেলে ব্যবহৃত কার্ডসমূহ ও ব্যবহারের নিয়ম'
                    : 'Dhaka Metro Rail Smart Cards & Pass Guide'}
                </h5>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* 1. MRT PASS */}
                <div className="p-4 rounded-xl border-2 border-emerald-500/40 bg-emerald-50/30 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-black text-sm text-emerald-900">MRT Pass (এমআরটি পাস)</span>
                      <span className="text-[9px] font-black text-white bg-emerald-700 px-2 py-0.5 rounded-full">
                        DMTCL অফিসিয়াল
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mb-3 leading-relaxed">
                      {lang === 'bn'
                        ? 'মেট্রোরেল স্টেশনের টিকিট কাউন্টার থেকে এনআইডি/পাসপোর্ট জমা দিয়ে ফর্ম পূরণ করে কেনা যায়। মূল্য ৫০০ টাকা (২০০ টাকা কার্ড সিকিউরিটি + ৩০০ টাকা রিচার্জ)।'
                        : 'Official Dhaka Metro smart card issued at station ticket booths. Cost ৳500 (৳200 security deposit + ৳300 initial balance).'}
                    </p>
                    <ul className="text-[11px] text-slate-600 space-y-1 mb-3">
                      <li className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-700" />
                        <span><strong>{lang === 'bn' ? '১০% ভাড়া ছাড়:' : '10% Fare Discount:'}</strong> প্রতি ট্রিপে ১০% সাশ্রয়</span>
                      </li>
                      <li className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-700" />
                        <span><strong>{lang === 'bn' ? 'মেয়াদ:' : 'Validity:'}</strong> ১০ বছর মেয়াদ</span>
                      </li>
                      <li className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-700" />
                        <span><strong>{lang === 'bn' ? 'রিচার্জ:' : 'Recharge:'}</strong> কাউন্টার ও ভেন্ডিং মেশিন (TVM)</span>
                      </li>
                    </ul>
                  </div>
                  <a
                    href="https://dmtcl.gov.bd/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-[11px] py-1.5 px-3 rounded-lg text-center flex items-center justify-center gap-1.5"
                  >
                    <span>{lang === 'bn' ? 'এমআরটি পাস বিস্তারিত' : 'MRT Pass Details'}</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                {/* 2. RAPID PASS */}
                <div className="p-4 rounded-xl border-2 border-purple-400/40 bg-purple-50/30 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-black text-sm text-purple-900">Rapid Pass (র‍্যাপিড পাস)</span>
                      <span className="text-[9px] font-black text-white bg-purple-700 px-2 py-0.5 rounded-full">
                        সার্বজনীন কার্ড
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mb-3 leading-relaxed">
                      {lang === 'bn'
                        ? 'মেট্রোরেল ছাড়াও বিআরটিসি এসি বাস ও হাতিরঝিল ওয়াটার ট্যাক্সিতে ব্যবহারযোগ্য ইন্টিগ্রেটেড স্মার্টকার্ড। ডিবিবিএল ফাস্টট্র্যাক ও নির্দিষ্ট বুথ থেকে পাওয়া যায়।'
                        : 'Intermodal transit pass valid on Metro Rail, BRTC AC buses and Hatirjheel water taxis. Managed by DTCA & DBBL.'}
                    </p>
                    <ul className="text-[11px] text-slate-600 space-y-1 mb-3">
                      <li className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-purple-700" />
                        <span><strong>{lang === 'bn' ? '১০% ভাড়া ছাড়:' : '10% Fare Discount:'}</strong> মেট্রোরেলে ১০% ক্যাশব্যাক</span>
                      </li>
                      <li className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-purple-700" />
                        <span><strong>{lang === 'bn' ? 'মাল্টি-ট্রান্সপোর্ট:' : 'Multi-modal:'}</strong> বাস ও ওয়াটার ট্যাক্সিতে চলে</span>
                      </li>
                      <li className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-purple-700" />
                        <span><strong>{lang === 'bn' ? 'রিচার্জ:' : 'Recharge:'}</strong> ডিবিবিএল ও স্টেশন ভেন্ডিং বুথ</span>
                      </li>
                    </ul>
                  </div>
                  <a
                    href="https://rapidpass.com.bd/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full bg-purple-700 hover:bg-purple-800 text-white font-bold text-[11px] py-1.5 px-3 rounded-lg text-center flex items-center justify-center gap-1.5"
                  >
                    <span>{lang === 'bn' ? 'র‍্যাপিড পাস পোর্টাল' : 'Rapid Pass Portal'}</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                {/* 3. SINGLE JOURNEY TICKET */}
                <div className="p-4 rounded-xl border-2 border-slate-300 bg-slate-50/50 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-black text-sm text-slate-900">Single Journey Ticket (একক যাত্রা)</span>
                      <span className="text-[9px] font-black text-slate-800 bg-slate-200 px-2 py-0.5 rounded-full">
                        এককালীন টোকেন
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mb-3 leading-relaxed">
                      {lang === 'bn'
                        ? 'মেট্রোরেল স্টেশনের অটোমেটিক টিকিট ভেন্ডিং মেশিন (TVM) বা ম্যানুয়াল কাউন্টার থেকে নগদ টাকা দিয়ে নির্দিষ্ট গন্তব্যের একক টিকিট (কার্ড টোকেন)।'
                        : 'One-time contactless magnetic smart card purchased from station Ticket Vending Machines (TVM) using cash/notes.'}
                    </p>
                    <ul className="text-[11px] text-slate-600 space-y-1 mb-3">
                      <li className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-slate-700" />
                        <span><strong>{lang === 'bn' ? 'প্রবেশ:' : 'Entry:'}</strong> এন্ট্রি গেটে কার্ড পাঞ্চ/ট্যাপ করতে হয়</span>
                      </li>
                      <li className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-slate-700" />
                        <span><strong>{lang === 'bn' ? 'প্রস্থান:' : 'Exit:'}</strong> নামার স্টেশনে এক্সিট গেটের স্লটে কার্ড ফেলতে হয়</span>
                      </li>
                      <li className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-slate-700" />
                        <span><strong>{lang === 'bn' ? 'মেয়াদ:' : 'Validity:'}</strong> ইস্যুর দিনে ওই নির্দিষ্ট যাত্রার জন্য প্রযোজ্য</span>
                      </li>
                    </ul>
                  </div>
                  <div className="text-[11px] font-bold text-center text-slate-500 py-1.5 bg-white border border-slate-200 rounded-lg">
                    {lang === 'bn' ? 'স্টেশনের যেকোনো ভেন্ডিং মেশিনে প্রাপ্য' : 'Available at all station TVMs'}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 1. EMERGENCY CONTACT NUMBERS (জরুরি কল নম্বরসমূহ) */}
      {/* ============================================================== */}
      {activeSubTab === 'emergency' && (
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-rose-500/10 via-amber-500/10 to-transparent border border-rose-200/80 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-md">
                <ShieldAlert className="w-5 h-5 animate-bounce" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-extrabold text-slate-900">
                  {lang === 'bn'
                    ? 'বাংলাদেশের অতি জরুরি ফোন নম্বরসমূহ (Emergency Hotlines)'
                    : 'Bangladesh Essential Emergency Phone Numbers'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 mt-1">
                  {lang === 'bn'
                    ? 'যেকোনো বিপদে, আইনি সুরক্ষা, হারানো লাগেজ বা স্বাস্থ্য সমস্যায় সরাসরি কল বা নম্বর কপি করুন। নম্বরগুলো ২৪/৭ সক্রিয়।'
                    : 'Direct one-tap calling and copy for immediate assistance, police escort, medical aid, or airport support.'}
                </p>
              </div>
            </div>

            {/* Quick Filter buttons */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
              {[
                { id: 'all', labelBn: 'সকল নম্বর', labelEn: 'All' },
                { id: 'critical', labelBn: 'জাতীয় জরুরি', labelEn: 'Critical' },
                { id: 'police', labelBn: 'ট্যুরিস্ট পুলিশ', labelEn: 'Tourist Police' },
                { id: 'health', labelBn: 'স্বাস্থ্য', labelEn: 'Health' },
                { id: 'airport', labelBn: 'বিমানবন্দর', labelEn: 'Airport' },
              ].map((filter) => (
                <button
                  key={filter.id}
                  onClick={() => setEmergencyFilter(filter.id)}
                  className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                    emergencyFilter === filter.id
                      ? 'bg-rose-600 text-white shadow-xs'
                      : 'bg-white border border-slate-200 text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {lang === 'bn' ? filter.labelBn : filter.labelEn}
                </button>
              ))}
            </div>
          </div>

          {/* Emergency Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredEmergency.map((contact) => {
              const isCrit = contact.tag === 'critical';
              const isPol = contact.tag === 'police';
              const isCopied = copiedNumber === contact.number;

              return (
                <div
                  key={contact.id}
                  className={`rounded-2xl border p-5 transition-all duration-300 flex flex-col justify-between premium-card ${
                    isCrit
                      ? 'bg-gradient-to-b from-rose-50/80 via-white to-white border-rose-300 hover:border-rose-400 hover:shadow-md'
                      : isPol
                      ? 'bg-gradient-to-b from-emerald-50/80 via-white to-white border-emerald-300 hover:border-emerald-400 hover:shadow-md'
                      : 'bg-white border-[#ebe6dc] hover:border-slate-300 hover:shadow-sm'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <span
                        className={`text-[11px] font-extrabold px-2.5 py-0.5 rounded-full ${
                          isCrit
                            ? 'bg-rose-100 text-rose-700'
                            : isPol
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {lang === 'bn' ? contact.typeBn : contact.typeEn}
                      </span>

                      <div className="flex items-center gap-1.5 text-[11px] text-slate-500 font-bold">
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span>{contact.available}</span>
                        {contact.tollFree && (
                          <span className="bg-emerald-600 text-white px-1.5 py-0.2 rounded text-[10px] font-extrabold">
                            FREE
                          </span>
                        )}
                      </div>
                    </div>

                    <h4 className="text-base font-extrabold text-slate-900 mb-1 leading-snug">
                      {lang === 'bn' ? contact.nameBn : contact.nameEn}
                    </h4>

                    <p className="text-xs text-slate-500 mb-3.5 leading-relaxed line-clamp-2">
                      {lang === 'bn' ? contact.descBn : contact.descEn}
                    </p>
                  </div>

                  {/* Dial and Copy Actions */}
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                    <a
                      href={`tel:${contact.number}`}
                      className={`flex-1 inline-flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-black transition-all shadow-xs cursor-pointer active:scale-[0.98] ${
                        isCrit
                          ? 'bg-rose-600 text-white hover:bg-rose-700 shadow-rose-200'
                          : isPol
                          ? 'bg-[#0f6b4f] text-white hover:bg-[#0c5740] shadow-emerald-200'
                          : 'bg-slate-900 text-white hover:bg-slate-800'
                      }`}
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      <span>{lang === 'bn' ? 'সরাসরি কল:' : 'Call:'} {contact.displayNumber || contact.number}</span>
                    </a>

                    <button
                      onClick={() => handleCopyNumber(contact.number)}
                      title={lang === 'bn' ? 'নম্বর কপি করুন' : 'Copy Number'}
                      className="p-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 hover:text-slate-900 transition-all cursor-pointer hover:border-slate-300 active:scale-95"
                    >
                      {isCopied ? (
                        <Check className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Tourist Police App and Safety Guidance Notice */}
          <div className="bg-[#f7fbf9] border border-[#0f6b4f]/30 rounded-2xl p-5 sm:p-6 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-[#0f6b4f] text-white flex items-center justify-center shrink-0">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-base font-extrabold text-slate-900">
                  {lang === 'bn'
                    ? 'ট্যুরিস্ট পুলিশ বাংলাদেশ মোবাইল অ্যাপ: Hello Tourist Police'
                    : 'Official App: "Hello Tourist Police BD"'}
                </h4>
                <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl leading-relaxed">
                  {lang === 'bn'
                    ? 'গুগল প্লে স্টোর ও অ্যাপল অ্যাপ স্টোরে ট্যুরিস্ট পুলিশের অফিশিয়াল অ্যাপ রয়েছে। এটি থেকে এক ক্লিকে প্যানিক বাটন, লাইভ লোকেশন শেয়ার এবং সরাসরি সাহায্য চাওয়া যায়।'
                    : 'Download the official "Hello Tourist Police BD" app on Google Play/App Store for one-tap panic button, live location sharing with patrols, and spot guides.'}
                </p>
              </div>
            </div>

            <a
              href="https://play.google.com/store/apps/details?id=com.touristpolice.helpline"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white border border-[#0f6b4f] text-[#0f6b4f] hover:bg-[#0f6b4f] hover:text-white transition-all text-xs font-bold shrink-0 shadow-2xs"
            >
              <span>{lang === 'bn' ? 'প্লে স্টোরে অ্যাপ দেখুন' : 'View on Play Store'}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 2. BEST SIM CARD COMPANIES (কোন কোন সিম কোম্পানি সেরা) */}
      {/* ============================================================== */}
      {activeSubTab === 'sim' && (
        <div className="space-y-6">
          <div className="bg-white border border-[#ebe6dc] rounded-2xl p-6 shadow-xs">
            <div className="max-w-3xl mb-6">
              <div className="inline-flex items-center gap-2 text-xs font-bold text-[#0f6b4f] mb-1">
                <Wifi className="w-4 h-4" />
                <span>{lang === 'bn' ? 'মোবাইল নেটওয়ার্ক ও ইন্টারনেট গাইড' : 'Mobile Operators & Internet Guide'}</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                {lang === 'bn'
                  ? 'বাংলাদেশে কোন কোন সিম কোম্পানি সেরা? (ট্যুরিস্ট সিম ও কাভারেজ)'
                  : 'Best SIM Card Companies in Bangladesh for Travelers'}
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                {lang === 'bn'
                  ? 'বাংলাদেশে মূলত ৪টি অনুমোদিত সেলুলার অপারেটর রয়েছে। পাহাড়, সমুদ্র ও রিমোট এলাকায় ভ্রমণের জন্য Grameenphone (GP) এবং ভালো বাজেট ও হাইওয়ের জন্য Robi সবচেয়ে জনপ্রিয়।'
                  : 'Four telecom providers operate in Bangladesh. Grameenphone provides the strongest nationwide 4G (critical for hill tracts & wetlands), while Robi offers the best budget data.'}
              </p>
            </div>

            {/* Quick Logo Showcase Bar with Official Links */}
            <div className="mb-6 p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200/90 shadow-2xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3.5 pb-2.5 border-b border-slate-200">
                <span className="text-xs sm:text-sm font-extrabold text-slate-800 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  {lang === 'bn' ? 'অফিসিয়াল টেলিকম কোম্পানি ও ওয়েব পোর্টাল' : 'Official Telecom Operators & Web Portals'}
                </span>
                <span className="text-[11px] text-slate-500 font-medium">
                  {lang === 'bn' ? 'লোগো বা লিংকে ক্লিক করে সরাসরি অফিশিয়াল ওয়েবসাইটে প্রবেশ করুন' : 'Click any operator card to visit official website'}
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {SIM_OPERATORS.map((op) => (
                  <a
                    key={op.id}
                    href={op.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex flex-col p-3 rounded-xl bg-white border border-slate-200/90 hover:border-slate-400 hover:shadow-sm transition-all group cursor-pointer"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <SimCompanyLogo operatorId={op.id} size="sm" showText={false} />
                      <ExternalLink className="w-3.5 h-3.5 text-slate-400 group-hover:text-slate-800 shrink-0 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </div>
                    <span className="font-extrabold text-xs text-slate-900 group-hover:text-emerald-700 transition-colors">
                      {lang === 'bn' ? op.nameBn : op.name}
                    </span>
                    <span className="text-[10px] text-slate-500 font-medium flex items-center gap-1 mt-0.5">
                      <Globe className="w-2.5 h-2.5 text-slate-400" />
                      {op.websiteDisplay}
                    </span>
                  </a>
                ))}
              </div>
            </div>

            {/* SIM Cards Comparison Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {SIM_OPERATORS.map((op) => (
                <div
                  key={op.id}
                  className={`rounded-2xl border p-5 sm:p-6 bg-gradient-to-br ${op.bgGradient} ${op.borderColor} shadow-xs flex flex-col justify-between premium-card transition-all duration-300 hover:shadow-md`}
                >
                  <div>
                    {/* Header with Official Logo & Badges */}
                    <div className="flex items-start justify-between gap-3 mb-3.5">
                      <div className="flex items-start gap-3">
                        <SimCompanyLogo operatorId={op.id} size="md" showText={false} />
                        <div>
                          <div className="flex flex-wrap items-center gap-1.5 mb-1">
                            <span className="text-[11px] font-extrabold px-2.5 py-0.5 rounded-full bg-white/90 text-slate-800 border border-slate-200">
                              {lang === 'bn' ? op.badgeBn : op.badgeEn}
                            </span>
                          </div>
                          <h4 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
                            <span>{lang === 'bn' ? op.nameBn : op.name}</span>
                          </h4>
                          <span className="text-[11px] text-slate-500 font-semibold italic block mt-0.5">
                            “{lang === 'bn' ? op.sloganBn : op.sloganEn}”
                          </span>
                        </div>
                      </div>

                      {/* Capabilities badges */}
                      <div className="flex flex-col items-end gap-1 shrink-0">
                        {op.eSimAvailable && (
                          <span className="text-[10px] font-black bg-emerald-700 text-white px-2 py-0.5 rounded-md flex items-center gap-1 shadow-2xs">
                            <QrCode className="w-3 h-3" /> eSIM OK
                          </span>
                        )}
                        {op.airportBooth && (
                          <span className="text-[10px] font-bold bg-sky-700 text-white px-2 py-0.5 rounded-md flex items-center gap-1 shadow-2xs">
                            <Plane className="w-3 h-3" /> {lang === 'bn' ? 'এয়ারপোর্ট বুথ' : 'Airport Booth'}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Official Website Pill */}
                    <div className="mb-3 flex items-center justify-between bg-white/70 px-3 py-1.5 rounded-lg border border-black/5 text-xs">
                      <span className="text-slate-500 font-medium">
                        {lang === 'bn' ? 'অফিসিয়াল পোর্টাল:' : 'Official Web:'}
                      </span>
                      <a
                        href={op.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-bold text-slate-800 hover:text-emerald-700 flex items-center gap-1 group"
                      >
                        <Globe className="w-3 h-3 text-slate-400 group-hover:text-emerald-600" />
                        <span className="underline">{op.websiteDisplay}</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>

                    {/* Ratings */}
                    <div className="flex items-center gap-4 py-2 border-y border-black/5 text-xs text-slate-700 mb-3">
                      <div>
                        <span className="text-slate-500">{lang === 'bn' ? 'কাভারেজ:' : 'Coverage:'} </span>
                        <strong className="text-slate-900">{op.coverageRating}/5 ⭐</strong>
                      </div>
                      <div>
                        <span className="text-slate-500">{lang === 'bn' ? 'গতি (Speed):' : 'Speed:'} </span>
                        <strong className="text-slate-900">{op.speedRating}/5 ⚡</strong>
                      </div>
                    </div>

                    {/* Highlights */}
                    <p className="text-xs text-slate-700 mb-3 leading-relaxed font-medium">
                      {lang === 'bn' ? op.highlightBn : op.highlightEn}
                    </p>

                    <div className="bg-white/80 rounded-xl p-3 border border-black/5 text-xs text-slate-600 mb-4">
                      <strong className="text-slate-900">
                        {lang === 'bn' ? 'কার জন্য সেরা: ' : 'Best For: '}
                      </strong>
                      {lang === 'bn' ? op.bestForBn : op.bestForEn}
                    </div>

                    {/* Airport location */}
                    <div className="flex items-start gap-2 text-xs text-slate-600 mb-4 bg-white/60 p-2.5 rounded-xl border border-black/5">
                      <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0 mt-0.5" />
                      <span>
                        <strong className="text-slate-800">{lang === 'bn' ? 'এয়ারপোর্টে অবস্থান: ' : 'Airport Desk: '}</strong>
                        {lang === 'bn' ? op.airportLocationBn : op.airportLocationEn}
                      </span>
                    </div>

                    {/* Recommended Packs */}
                    <div>
                      <div className="text-[11px] font-bold text-slate-700 mb-2 flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-amber-500" />
                        <span>{lang === 'bn' ? 'জনপ্রিয় ট্যুরিস্ট ডাটা প্যাক:' : 'Recommended Tourist Packs:'}</span>
                      </div>
                      <div className="space-y-2">
                        {op.recommendedPacks.map((pack, idx) => (
                          <div
                            key={idx}
                            className="bg-white rounded-xl p-2.5 border border-slate-200/80 flex items-center justify-between gap-3 text-xs"
                          >
                            <div>
                              <div className="font-extrabold text-slate-900">{pack.data}</div>
                              <div className="text-[11px] text-slate-500">{lang === 'bn' ? pack.validityBn : pack.validityEn}</div>
                            </div>
                            <div className="text-right">
                              <div className="font-black text-[#0f6b4f] text-sm">
                                {formatPrice(pack.bdtPrice)}
                              </div>
                              <div className="text-[10px] text-slate-400">
                                (৳{pack.bdtPrice})
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Direct Website Link & Call Helpline CTA */}
                  <div className="mt-5 pt-4 border-t border-black/5 flex flex-wrap items-center gap-2.5">
                    <a
                      href={op.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 min-w-[200px] inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm text-white shadow-xs transition-all cursor-pointer hover:brightness-110 active:scale-[0.98]"
                      style={{ backgroundColor: op.color }}
                    >
                      <Globe className="w-4 h-4" />
                      <span>
                        {lang === 'bn'
                          ? `অফিসিয়াল ওয়েবসাইটে যান (${op.websiteDisplay})`
                          : `Visit Website (${op.websiteDisplay})`}
                      </span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                    <a
                      href={`tel:${op.helpline}`}
                      className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 text-xs font-bold transition-all shadow-2xs"
                      title={lang === 'bn' ? `হেল্পলাইনে কল করুন (${op.helpline})` : `Call Helpline (${op.helpline})`}
                    >
                      <PhoneCall className="w-3.5 h-3.5 text-[#0f6b4f]" />
                      <span>{lang === 'bn' ? `হটলাইন ${op.helpline}` : `Call ${op.helpline}`}</span>
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* How to Buy a SIM Card / Requirements for Foreigners & Locals */}
          <div className="bg-white border border-[#ebe6dc] rounded-2xl p-6 shadow-xs">
            <h4 className="text-lg font-extrabold text-slate-900 mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5 text-[#0f6b4f]" />
              <span>
                {lang === 'bn'
                  ? 'বাংলাদেশে সিম কার্ড কেনার নিয়মাবলী ও প্রয়োজনীয় কাগজপত্র'
                  : 'SIM Card Buying Guide: Documents Required (Foreigners & Locals)'}
              </span>
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* For Foreign Nationals */}
              <div className="rounded-xl border border-sky-100 bg-sky-50/50 p-4 text-xs leading-relaxed">
                <div className="flex items-center gap-2 font-bold text-sky-900 text-sm mb-2.5">
                  <Globe className="w-4 h-4 text-sky-700" />
                  <span>{lang === 'bn' ? 'বিদেশি পর্যটকদের জন্য (Foreign Tourists)' : 'For Foreign Tourists'}</span>
                </div>
                <ul className="space-y-2 text-slate-700">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-sky-600 shrink-0 mt-0.5" />
                    <span>
                      <strong>{lang === 'bn' ? 'মূল পাসপোর্ট ও ভিসা কপি:' : 'Passport & Visa Copy:'}</strong>{' '}
                      {lang === 'bn'
                        ? 'বৈধ বাংলাদেশ এন্ট্রি ভিসা সিলযুক্ত মূল পাসপোর্ট ও ফটোকপি।'
                        : 'Original passport with valid Bangladesh entry visa seal (photocopy also accepted).'}
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-sky-600 shrink-0 mt-0.5" />
                    <span>
                      <strong>{lang === 'bn' ? 'পাসপোর্ট সাইজ ছবি:' : 'Passport Photo:'}</strong>{' '}
                      {lang === 'bn'
                        ? '১ কপি পাসপোর্ট সাইজ ছবি (বিমানবন্দর বুথে তাৎক্ষণিক ডিজিটাল ছবি তুলেও দেওয়া হয়)।'
                        : '1 passport-size photograph (airport operator booths capture photo on-site free of charge).'}
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-sky-600 shrink-0 mt-0.5" />
                    <span>
                      <strong>{lang === 'bn' ? 'হোটেলের ঠিকানা:' : 'Hotel Address:'}</strong>{' '}
                      {lang === 'bn'
                        ? 'আপনার বুকিং করা হোটেল বা বাসস্থানের নাম ও স্থানীয় ঠিকানা।'
                        : 'Name and local address/contact of your reserved hotel or guesthouse in Bangladesh.'}
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-sky-600 shrink-0 mt-0.5" />
                    <span>
                      <strong>{lang === 'bn' ? 'eSIM সুবিধা:' : 'eSIM Availability:'}</strong>{' '}
                      {lang === 'bn'
                        ? 'আপনার ফোনে eSIM থাকলে পাসপোর্ট দেখিয়ে কিউআর কোড স্ক্যানে মাত্র ২ মিনিটে সক্রিয় করা যায়।'
                        : 'If your device supports eSIM, activate instantly in under 2 minutes by scanning the operator QR voucher.'}
                    </span>
                  </li>
                </ul>
              </div>

              {/* For Local Citizens & NRBs */}
              <div className="rounded-xl border border-emerald-100 bg-emerald-50/50 p-4 text-xs leading-relaxed">
                <div className="flex items-center gap-2 font-bold text-emerald-900 text-sm mb-2.5">
                  <HeartHandshake className="w-4 h-4 text-[#0f6b4f]" />
                  <span>{lang === 'bn' ? 'বাংলাদেশি নাগরিক ও প্রবাসীদের জন্য' : 'For Bangladeshi Citizens & NRBs'}</span>
                </div>
                <ul className="space-y-2 text-slate-700">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#0f6b4f] shrink-0 mt-0.5" />
                    <span>
                      <strong>{lang === 'bn' ? 'স্মার্ট এনআইডি (NID):' : 'Smart NID Card:'}</strong>{' '}
                      {lang === 'bn'
                        ? 'মূল স্মার্ট জাতীয় পরিচয়পত্র বা এনআইডি নম্বর।'
                        : 'Original Smart National ID (NID) card or verified NID number.'}
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#0f6b4f] shrink-0 mt-0.5" />
                    <span>
                      <strong>{lang === 'bn' ? 'বায়োমেট্রিক ফিঙ্গারপ্রিন্ট:' : 'Biometric Fingerprint:'}</strong>{' '}
                      {lang === 'bn'
                        ? 'যেকোনো অনুমোদিত টেলিকম এজেন্টের কাছে আঙুলের ছাপ দিয়ে তাৎক্ষণিক সিম চালু।'
                        : 'Quick fingerprint scan at any authorized retail outlet activates the SIM card immediately.'}
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#0f6b4f] shrink-0 mt-0.5" />
                    <span>
                      <strong>{lang === 'bn' ? 'প্রবাসী বাংলাদেশি (NRB):' : 'Expatriate Bangladeshis (NRB):'}</strong>{' '}
                      {lang === 'bn'
                        ? 'প্রবাসী বাংলাদেশিরা তাদের বৈধ বাংলাদেশি পাসপোর্ট বা এনআইডি ব্যবহার করে সিম নিতে পারেন।'
                        : 'Non-resident Bangladeshis can easily procure SIMs with their valid BD passport or NID.'}
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 3. TRAVEL COST & MULTI-CURRENCY BUDGET CALCULATOR */}
      {/* ============================================================== */}
      {activeSubTab === 'budget' && (
        <div className="space-y-8 animate-fadeIn">
          {/* LIVE CURRENCY EXCHANGE RATES SHOWCASE */}
          <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-white/10 relative overflow-hidden">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-white/15">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                  <span className="text-xs font-black uppercase tracking-widest text-emerald-300">
                    {lang === 'bn' ? 'লাইভ ফরেক্স মার্কেট রেট (Live Currency Rates)' : 'Live Forex Market Rates in BDT'}
                  </span>
                </div>
                <h3 className="text-xl sm:text-2xl font-black text-white">
                  {lang === 'bn'
                    ? 'ডলার ও শীর্ষ আন্তর্জাতিক মুদ্রার লাইভ রেট'
                    : 'US Dollar & Global Currency Exchange Rates'}
                </h3>
                <p className="text-xs text-slate-300 mt-1">
                  {lang === 'bn'
                    ? 'খোলা বাজার ও আন্তর্জাতিক রেটের সাথে নিয়মিত স্বয়ংক্রিয়ভাবে আপডেট হয়'
                    : 'Auto-updated from live open currency exchange market'}
                </p>
              </div>

              {/* Refresh Button & Timestamp */}
              <div className="flex items-center gap-3">
                <div className="text-right hidden sm:block text-[11px] text-slate-400">
                  <div>{lang === 'bn' ? 'সর্বশেষ আপডেট:' : 'Last Updated:'}</div>
                  <div className="font-mono text-emerald-300 font-bold">{lastUpdatedRates}</div>
                </div>

                <button
                  onClick={fetchLiveRates}
                  disabled={isLoadingRates}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-xs transition-all shadow-md inline-flex items-center gap-2 cursor-pointer"
                >
                  <RotateCw className={`w-3.5 h-3.5 ${isLoadingRates ? 'animate-spin' : ''}`} />
                  <span>{isLoadingRates ? (lang === 'bn' ? 'আপডেট হচ্ছে...' : 'Updating...') : (lang === 'bn' ? 'লাইভ রেট রিফ্রেশ' : 'Refresh Rates')}</span>
                </button>
              </div>
            </div>

            {/* Live Exchange Rate Cards Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 pt-6">
              {[
                { code: 'USD', flag: '🇺🇸', nameBn: 'মার্কিন ডলার', nameEn: 'US Dollar', rate: liveRates.USD, popular: true },
                { code: 'EUR', flag: '🇪🇺', nameBn: 'ইউরো', nameEn: 'Euro', rate: liveRates.EUR, popular: true },
                { code: 'GBP', flag: '🇬🇧', nameBn: 'ব্রিটিশ পাউন্ড', nameEn: 'British Pound', rate: liveRates.GBP, popular: false },
                { code: 'SAR', flag: '🇸🇦', nameBn: 'সৌদি রিয়াল', nameEn: 'Saudi Riyal', rate: liveRates.SAR, popular: true },
                { code: 'AED', flag: '🇦🇪', nameBn: 'ইউএই দিরহাম', nameEn: 'UAE Dirham', rate: liveRates.AED, popular: true },
                { code: 'CAD', flag: '🇨🇦', nameBn: 'কানাডিয়ান ডলার', nameEn: 'Canadian Dollar', rate: liveRates.CAD, popular: false },
                { code: 'MYR', flag: '🇲🇾', nameBn: 'মালয়েশিয়ান রিঙ্গিত', nameEn: 'Malaysian Ringgit', rate: liveRates.MYR, popular: false },
                { code: 'SGD', flag: '🇸🇬', nameBn: 'সিঙ্গাপুর ডলার', nameEn: 'Singapore Dollar', rate: liveRates.SGD, popular: false },
                { code: 'INR', flag: '🇮🇳', nameBn: 'ভারতীয় রুপি', nameEn: 'Indian Rupee', rate: liveRates.INR, popular: false },
                { code: 'BDT', flag: '🇧🇩', nameBn: 'বাংলাদেশি টাকা', nameEn: 'Base Taka', rate: 1, popular: false },
              ].map((item) => (
                <div
                  key={item.code}
                  className={`p-3.5 rounded-2xl border transition-all ${
                    item.popular
                      ? 'bg-emerald-950/40 border-emerald-500/40 hover:border-emerald-400'
                      : 'bg-white/5 border-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xl">{item.flag}</span>
                    <span className="font-mono font-black text-xs text-amber-300">{item.code}</span>
                  </div>
                  <div className="text-[11px] text-slate-300 font-semibold truncate">
                    {lang === 'bn' ? item.nameBn : item.nameEn}
                  </div>
                  <div className="text-base sm:text-lg font-black text-white mt-1">
                    {item.code === 'BDT' ? (
                      <span className="text-xs text-emerald-300">ভিত্তি মুদ্রা (Base)</span>
                    ) : (
                      <span>৳{item.rate.toFixed(2)}</span>
                    )}
                  </div>
                  <div className="text-[9px] text-slate-400 mt-0.5">
                    {item.code === 'BDT' ? '১ টাকা = ১ BDT' : `১ ${item.code} = ৳${item.rate.toFixed(2)} BDT`}
                  </div>
                </div>
              ))}
            </div>

            {/* Interactive Real-Time Live Currency Converter Box */}
            <div className="mt-6 pt-6 border-t border-white/15 bg-black/30 p-4 sm:p-5 rounded-2xl">
              <div className="flex items-center gap-2 mb-3">
                <Coins className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-black uppercase tracking-wider text-amber-300">
                  {lang === 'bn' ? 'তাৎক্ষণিক কারেন্সি কনভার্টার ক্যালকুলেটর' : 'Instant Live Currency Converter'}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
                {/* Amount */}
                <div className="sm:col-span-4">
                  <label className="block text-[10px] text-slate-400 font-bold uppercase mb-1">
                    {lang === 'bn' ? 'পরিমাণ:' : 'Amount:'}
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={calcAmount}
                    onChange={(e) => setCalcAmount(Math.max(1, Number(e.target.value)))}
                    className="w-full bg-slate-900 border border-slate-700 text-white font-mono font-bold text-sm px-3 py-2 rounded-xl focus:outline-none focus:border-emerald-400"
                  />
                </div>

                {/* From Currency */}
                <div className="sm:col-span-3">
                  <label className="block text-[10px] text-slate-400 font-bold uppercase mb-1">
                    {lang === 'bn' ? 'মুদ্রা থেকে:' : 'From:'}
                  </label>
                  <select
                    value={calcFromCurrency}
                    onChange={(e) => setCalcFromCurrency(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 text-white font-bold text-xs px-3 py-2 rounded-xl focus:outline-none focus:border-emerald-400 cursor-pointer"
                  >
                    <option value="USD">USD ($ - US Dollar)</option>
                    <option value="EUR">EUR (€ - Euro)</option>
                    <option value="GBP">GBP (£ - British Pound)</option>
                    <option value="SAR">SAR (Saudi Riyal)</option>
                    <option value="AED">AED (UAE Dirham)</option>
                    <option value="CAD">CAD (Canadian Dollar)</option>
                    <option value="MYR">MYR (Malaysian Ringgit)</option>
                    <option value="SGD">SGD (Singapore Dollar)</option>
                    <option value="INR">INR (Indian Rupee)</option>
                    <option value="BDT">BDT (৳ - Bangladeshi Taka)</option>
                  </select>
                </div>

                {/* To Currency */}
                <div className="sm:col-span-2 text-center text-xs text-amber-300 font-bold">
                  <span>→ সমান সমান →</span>
                </div>

                {/* Result */}
                <div className="sm:col-span-3 bg-emerald-900/60 border border-emerald-500/40 p-2.5 rounded-xl text-center">
                  <div className="text-[10px] text-emerald-200 font-bold uppercase">
                    {lang === 'bn' ? 'মোট সমপরিমাণ BDT টাকা:' : 'Converted Value in BDT:'}
                  </div>
                  <div className="text-base sm:text-lg font-black text-amber-300 font-mono">
                    {calcFromCurrency === 'BDT'
                      ? `৳${calcAmount.toLocaleString('en-US')} BDT`
                      : `৳${((calcAmount || 0) * (liveRates[calcFromCurrency] || 1)).toLocaleString('en-US', { maximumFractionDigits: 2 })} BDT`}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Calculator Section */}
          <div className="bg-white border border-[#ebe6dc] rounded-3xl p-6 sm:p-8 shadow-xs">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-6 border-b border-[#ebe6dc]">
              <div>
                <span className="text-xs font-bold text-[#0f6b4f] flex items-center gap-1.5 mb-1">
                  <DollarSign className="w-4 h-4" />
                  {lang === 'bn' ? 'বাংলাদেশ ভ্রমণ খরচ ও বাজেট নির্ণয়' : 'Interactive Budget Estimator'}
                </span>
                <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                  {lang === 'bn'
                    ? 'বাংলাদেশে ঘুরতে কত খরচ হবে? (লাইভ কারেন্সি কনভার্টার)'
                    : 'How Much Does It Cost to Travel Bangladesh?'}
                </h3>
              </div>

              {/* Currency badge */}
              <div className="flex items-center gap-1.5 bg-[#f3efe7] p-1.5 rounded-2xl border border-[#ebe6dc]">
                <span className="text-xs font-bold text-slate-600 px-2">
                  {lang === 'bn' ? 'মুদ্রা:' : 'Currency:'}
                </span>
                {(['BDT', 'USD', 'EUR', 'AED'] as CurrencyType[]).map((curr) => (
                  <button
                    key={curr}
                    onClick={() => setSelectedCurrency(curr)}
                    className={`px-3 py-1 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                      selectedCurrency === curr
                        ? 'bg-[#0f6b4f] text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {curr}
                  </button>
                ))}
              </div>
            </div>

            {/* Inputs: Days, Travel Style, Number of People */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {/* Trip Duration */}
              <div className="bg-[#faf8f4] p-5 rounded-2xl border border-[#ebe6dc]">
                <label className="text-xs font-bold text-slate-700 block mb-2 flex items-center justify-between">
                  <span>{lang === 'bn' ? 'ভ্রমণের সময়কাল (দিন):' : 'Trip Duration (Days):'}</span>
                  <span className="text-sm font-black text-[#0f6b4f]">{tripDays} {lang === 'bn' ? 'দিন' : 'Days'}</span>
                </label>
                <input
                  type="range"
                  min="2"
                  max="30"
                  step="1"
                  value={tripDays}
                  onChange={(e) => setTripDays(Number(e.target.value))}
                  className="w-full accent-[#0f6b4f] cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>{lang === 'bn' ? '২ দিন' : '2 Days'}</span>
                  <span>{lang === 'bn' ? '৭ দিন (১ সপ্তাহ)' : '7 Days (1 Wk)'}</span>
                  <span>{lang === 'bn' ? '১৫ দিন' : '15 Days'}</span>
                  <span>{lang === 'bn' ? '৩০ দিন' : '30 Days'}</span>
                </div>
              </div>

              {/* Travel Style */}
              <div className="bg-[#faf8f4] p-5 rounded-2xl border border-[#ebe6dc]">
                <label className="text-xs font-bold text-slate-700 block mb-2">
                  {lang === 'bn' ? 'ভ্রমণের ধরন ও সুযোগ-সুবিধা:' : 'Travel Style & Comfort:'}
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    onClick={() => setTravelStyle('budget')}
                    className={`p-2 rounded-xl text-xs font-bold text-center transition-all cursor-pointer ${
                      travelStyle === 'budget'
                        ? 'bg-amber-500 text-white shadow-xs font-extrabold'
                        : 'bg-white border border-slate-200 text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <div>🎒</div>
                    <div className="text-[11px] mt-1">{lang === 'bn' ? 'বাজেট' : 'Budget'}</div>
                  </button>

                  <button
                    onClick={() => setTravelStyle('standard')}
                    className={`p-2 rounded-xl text-xs font-bold text-center transition-all cursor-pointer ${
                      travelStyle === 'standard'
                        ? 'bg-[#0f6b4f] text-white shadow-xs font-extrabold'
                        : 'bg-white border border-slate-200 text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <div>🏨</div>
                    <div className="text-[11px] mt-1">{lang === 'bn' ? 'স্ট্যান্ডার্ড' : 'Mid-Range'}</div>
                  </button>

                  <button
                    onClick={() => setTravelStyle('luxury')}
                    className={`p-2 rounded-xl text-xs font-bold text-center transition-all cursor-pointer ${
                      travelStyle === 'luxury'
                        ? 'bg-indigo-600 text-white shadow-xs font-extrabold'
                        : 'bg-white border border-slate-200 text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <div>💎</div>
                    <div className="text-[11px] mt-1">{lang === 'bn' ? 'লাক্সারি' : 'Luxury'}</div>
                  </button>
                </div>
              </div>

              {/* Number of Travelers */}
              <div className="bg-[#faf8f4] p-5 rounded-2xl border border-[#ebe6dc]">
                <label className="text-xs font-bold text-slate-700 block mb-2 flex items-center justify-between">
                  <span>{lang === 'bn' ? 'ভ্রমণকারীর সংখ্যা:' : 'Total Travelers:'}</span>
                  <span className="text-sm font-black text-[#0f6b4f]">{numTravelers} {lang === 'bn' ? 'জন' : 'Person(s)'}</span>
                </label>
                <div className="flex items-center gap-2">
                  {[1, 2, 4, 6].map((count) => (
                    <button
                      key={count}
                      onClick={() => setNumTravelers(count)}
                      className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        numTravelers === count
                          ? 'bg-[#0f6b4f] text-white shadow-xs'
                          : 'bg-white border border-slate-200 text-slate-700 hover:border-slate-300'
                      }`}
                    >
                      {count} {lang === 'bn' ? 'জন' : 'P'}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Total Estimated Cost Banner in Active Currency */}
            <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-md mb-8">
              <div>
                <span className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                  {lang === 'bn' ? 'মোট আনুমানিক সম্ভাব্য খরচ' : 'Estimated Total Tour Cost'}
                </span>
                <div className="text-3xl sm:text-5xl font-black text-white mt-1 tracking-tight">
                  {formatPrice(totalCalculatedCostBdt)}
                </div>
                <div className="text-xs text-slate-400 mt-2 flex flex-wrap gap-4">
                  <span>
                    {lang === 'bn' ? 'জনপ্রতি দৈনিক খরচ: ' : 'Daily Per Person: '}
                    <strong className="text-emerald-300">{formatPrice(perPersonDailyCostBdt)}</strong>
                  </span>
                  <span>
                    ({tripDays} {lang === 'bn' ? 'দিন' : 'Days'}, {numTravelers} {lang === 'bn' ? 'জন' : 'Persons'}, {travelStyle.toUpperCase()})
                  </span>
                </div>
              </div>

              {/* Multi-Currency Equivalence Card */}
              <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 border border-white/15 text-xs space-y-2 min-w-[220px]">
                <div className="text-slate-300 font-bold text-[11px] pb-1 border-b border-white/10">
                  {lang === 'bn' ? 'চার মুদ্রায় রূপান্তর:' : 'Equivalent in All Currencies:'}
                </div>
                <div className="flex justify-between text-emerald-300 font-bold">
                  <span>Bangladeshi Taka:</span>
                  <span>৳{totalCalculatedCostBdt.toLocaleString('en-US')}</span>
                </div>
                <div className="flex justify-between text-sky-200 font-bold">
                  <span>US Dollar ($):</span>
                  <span>${(totalCalculatedCostBdt / 122).toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-indigo-200 font-bold">
                  <span>Euro (€):</span>
                  <span>€{(totalCalculatedCostBdt / 132).toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-amber-300 font-bold">
                  <span>UAE Dirham (AED):</span>
                  <span>{(totalCalculatedCostBdt / 33.2).toFixed(1)} AED</span>
                </div>
              </div>
            </div>

            {/* Category Breakdown Table */}
            <h4 className="text-base font-extrabold text-slate-900 mb-4">
              {lang === 'bn' ? 'খরচের খাতওয়ারি বিবরণ (প্রতিদিন গড়ে)' : 'Daily Cost Breakdown by Category'}
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Hotel / Stay */}
              <div className="rounded-xl border border-[#ebe6dc] bg-[#faf8f4] p-4">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-700 mb-1">
                  <Hotel className="w-4 h-4 text-[#0f6b4f]" />
                  <span>{lang === 'bn' ? 'হোটেল / রিসোর্ট' : 'Accommodation'}</span>
                </div>
                <div className="text-lg font-black text-slate-900 mt-1">
                  {formatPrice(
                    travelStyle === 'budget'
                      ? 1000
                      : travelStyle === 'standard'
                      ? 2800
                      : 10000
                  )}
                  <span className="text-xs font-normal text-slate-500"> / {lang === 'bn' ? 'রাত' : 'night'}</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  {travelStyle === 'budget'
                    ? (lang === 'bn' ? 'গেস্টহাউস বা বাজেট হোটেল' : 'Guesthouse / Budget room')
                    : travelStyle === 'standard'
                    ? (lang === 'bn' ? '৩-স্টার এসি হোটেল রুম' : '3-Star AC Hotel / Resort')
                    : (lang === 'bn' ? '৫-স্টার লাক্সারি রিসোর্ট / স্যুট' : '5-Star Resort / Premium')}
                </p>
              </div>

              {/* Food & Dining */}
              <div className="rounded-xl border border-[#ebe6dc] bg-[#faf8f4] p-4">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-700 mb-1">
                  <Utensils className="w-4 h-4 text-amber-600" />
                  <span>{lang === 'bn' ? 'খাবার ও পানীয়' : 'Food & Dining'}</span>
                </div>
                <div className="text-lg font-black text-slate-900 mt-1">
                  {formatPrice(
                    travelStyle === 'budget'
                      ? 600
                      : travelStyle === 'standard'
                      ? 1400
                      : 4000
                  )}
                  <span className="text-xs font-normal text-slate-500"> / {lang === 'bn' ? 'দিন' : 'day'}</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  {travelStyle === 'budget'
                    ? (lang === 'bn' ? 'সুস্বাদু লোকাল খাবার ও মিষ্টি' : 'Local Bengali diners & street food')
                    : travelStyle === 'standard'
                    ? (lang === 'bn' ? 'জনপ্রিয় রেস্তোরাঁ ও ক্যাফে' : 'Popular restaurants & cafes')
                    : (lang === 'bn' ? 'লাক্সারি ডাইনিং ও বুফে' : 'Fine dining & international cuisine')}
                </p>
              </div>

              {/* Transport */}
              <div className="rounded-xl border border-[#ebe6dc] bg-[#faf8f4] p-4">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-700 mb-1">
                  <Bus className="w-4 h-4 text-sky-600" />
                  <span>{lang === 'bn' ? 'লোকাল ও আন্তঃজেলা পরিবহন' : 'Transport'}</span>
                </div>
                <div className="text-lg font-black text-slate-900 mt-1">
                  {formatPrice(
                    travelStyle === 'budget'
                      ? 450
                      : travelStyle === 'standard'
                      ? 1000
                      : 3500
                  )}
                  <span className="text-xs font-normal text-slate-500"> / {lang === 'bn' ? 'দিন' : 'day'}</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  {travelStyle === 'budget'
                    ? (lang === 'bn' ? 'বাস, সিএনজি অটোরিকশা, ট্রেন' : 'Local bus, train & CNG')
                    : travelStyle === 'standard'
                    ? (lang === 'bn' ? 'এসি বাস, উবার, ট্রেনের শোভন/স্নিগ্ধা' : 'AC Bus, Uber, AC Trains')
                    : (lang === 'bn' ? 'প্রাইভেট এসি কার / ডোমেস্টিক ফ্লাইট' : 'Private chauffeured car / flights')}
                </p>
              </div>

              {/* Sightseeing & SIM */}
              <div className="rounded-xl border border-[#ebe6dc] bg-[#faf8f4] p-4">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-700 mb-1">
                  <Sparkles className="w-4 h-4 text-indigo-600" />
                  <span>{lang === 'bn' ? 'টিকেট, সিম ও বিবিধ' : 'Tickets, SIM & Guides'}</span>
                </div>
                <div className="text-lg font-black text-slate-900 mt-1">
                  {formatPrice(
                    travelStyle === 'budget'
                      ? 150
                      : travelStyle === 'standard'
                      ? 300
                      : 1000
                  )}
                  <span className="text-xs font-normal text-slate-500"> / {lang === 'bn' ? 'দিন' : 'day'}</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  {lang === 'bn'
                    ? 'স্মৃতিসৌধ এন্ট্রি ফি, বোট ভাড়া ও মোবাইল ডাটা'
                    : 'Attraction entry passes, boat fees & SIM'}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 4. WHERE TO VISIT (কোথায় কোথায় ঘুরবেন - CIRCUITS & DESTINATIONS) */}
      {/* ============================================================== */}
      {activeSubTab === 'destinations' && (
        <div className="space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-[#0f6b4f] flex items-center gap-1.5 mb-1">
                <Compass className="w-4 h-4" />
                {lang === 'bn' ? 'বাংলাদেশের শীর্ষ ভ্রমণ রুট' : 'Top Travel Circuits'}
              </span>
              <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                {lang === 'bn'
                  ? 'কোথায় কোথায় ঘোরা যায়? (জনপ্রিয় দর্শনীয় স্থান ও আনুমানিক খরচ)'
                  : 'Where to Visit in Bangladesh? (Highlights & Costs)'}
              </h3>
            </div>

            {/* Filter pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
              {[
                { id: 'all', labelBn: 'সব স্থান', labelEn: 'All' },
                { id: 'sea', labelBn: 'সমুদ্র ও দ্বীপ', labelEn: 'Sea & Beaches' },
                { id: 'hills', labelBn: 'পাহাড় ও চা বাগান', labelEn: 'Hills & Tea' },
                { id: 'forest', labelBn: 'সুন্দরবন ও বনভূমি', labelEn: 'Forests' },
                { id: 'river', labelBn: 'নদী ও হাওর', labelEn: 'Rivers & Haor' },
                { id: 'heritage', labelBn: 'ঐতিহাসিক প্রত্নতত্ত্ব', labelEn: 'Heritage' },
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => setDestinationFilter(f.id)}
                  className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                    destinationFilter === f.id
                      ? 'bg-[#0f6b4f] text-white shadow-xs'
                      : 'bg-white border border-slate-200 text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {lang === 'bn' ? f.labelBn : f.labelEn}
                </button>
              ))}
            </div>
          </div>

          {/* Destination Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDestinations.map((dest) => (
              <div
                key={dest.id}
                className="bg-white border border-[#ebe6dc] rounded-3xl overflow-hidden shadow-xs hover:border-[#0f6b4f]/40 hover:shadow-xl transition-all duration-300 flex flex-col justify-between group premium-card"
              >
                <div>
                  {/* Visual Photo Header */}
                  <div className="relative h-48 w-full overflow-hidden bg-slate-900">
                    {dest.image ? (
                      <img
                        src={dest.image}
                        alt={dest.imageAlt || (lang === 'bn' ? dest.nameBn : dest.nameEn)}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        loading="lazy"
                      />
                    ) : (
                      <div
                        className={`w-full h-full bg-gradient-to-br ${
                          dest.fallbackGradient || 'from-emerald-800 via-teal-900 to-slate-900'
                        } flex flex-col items-center justify-center p-6 text-center text-white relative`}
                      >
                        <div className="absolute inset-0 bg-black/20" />
                        <div className="relative z-10 flex flex-col items-center">
                          {dest.category === 'river' && <Ship className="w-10 h-10 text-cyan-300 mb-2 drop-shadow" />}
                          {dest.category === 'heritage' && <Landmark className="w-10 h-10 text-amber-300 mb-2 drop-shadow" />}
                          {dest.category === 'forest' && <Trees className="w-10 h-10 text-emerald-300 mb-2 drop-shadow" />}
                          {dest.category === 'hills' && <Mountain className="w-10 h-10 text-teal-300 mb-2 drop-shadow" />}
                          {dest.category === 'sea' && <Waves className="w-10 h-10 text-sky-300 mb-2 drop-shadow" />}
                          <span className="text-xs font-bold text-white/90 uppercase tracking-widest">
                            {lang === 'bn' ? dest.tagBn : dest.tagEn}
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Gradient scrim for text contrast */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent" />

                    {/* Badges on Top of Photo */}
                    <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2 z-10">
                      <span className="text-[10px] font-black px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-emerald-300 border border-white/20 uppercase tracking-wide">
                        {dest.category.toUpperCase()}
                      </span>
                      <span className="text-xs font-black px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-md text-amber-300 border border-white/20 shadow-xs">
                        {lang === 'bn' ? 'গড়ে দৈনিক ' : 'Avg. '}
                        {formatPrice(dest.avgCostPerDayBdt)}
                      </span>
                    </div>

                    {/* Bottom Title on Image */}
                    <div className="absolute bottom-2.5 left-3.5 right-3.5 z-10">
                      <span className="text-[11px] font-semibold text-emerald-200 block drop-shadow-sm">
                        {lang === 'bn' ? dest.tagBn : dest.tagEn}
                      </span>
                      <h4 className="text-base sm:text-lg font-black text-white leading-tight drop-shadow-md">
                        {lang === 'bn' ? dest.nameBn : dest.nameEn}
                      </h4>
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-5 sm:p-6">
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-3.5">
                      <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                      <span className="font-medium">{lang === 'bn' ? dest.locationBn : dest.locationEn}</span>
                    </div>

                    {/* Highlights */}
                    <div className="mb-4">
                      <span className="text-[11px] font-bold text-slate-700 block mb-1.5">
                        {lang === 'bn' ? 'মূল আকর্ষণসমূহ:' : 'Top Highlights:'}
                      </span>
                      <ul className="space-y-1">
                        {(lang === 'bn' ? dest.highlightsBn : dest.highlightsEn).map((h, i) => (
                          <li key={i} className="text-xs text-slate-600 flex items-start gap-1.5">
                            <Check className="w-3.5 h-3.5 text-[#0f6b4f] shrink-0 mt-0.5" />
                            <span>{h}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* How to reach */}
                    <div className="bg-[#faf8f4] p-3 rounded-xl border border-[#ebe6dc] text-xs text-slate-600 mb-3">
                      <div className="font-bold text-slate-800 flex items-center gap-1 mb-1">
                        <Bus className="w-3.5 h-3.5 text-sky-600" />
                        <span>{lang === 'bn' ? 'যাতায়াত মাধ্যম:' : 'How to Reach:'}</span>
                      </div>
                      <p className="leading-relaxed">{lang === 'bn' ? dest.howToReachBn : dest.howToReachEn}</p>
                    </div>

                    {/* Best season */}
                    <div className="flex items-center gap-1.5 text-xs text-slate-600 mb-2">
                      <Calendar className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                      <span>
                        <strong className="text-slate-800">{lang === 'bn' ? 'ভ্রমণের শ্রেষ্ঠ সময়: ' : 'Best Time: '}</strong>
                        {lang === 'bn' ? dest.bestSeasonBn : dest.bestSeasonEn}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Safety notes footer */}
                <div className="p-4 mx-5 mb-5 rounded-xl bg-amber-50/60 border border-amber-200/60 text-[11px] text-slate-600 flex items-start gap-1.5">
                  <Info className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                  <span>{lang === 'bn' ? dest.safetyTipsBn : dest.safetyTipsEn}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 5. FACILITIES, TRANSPORT & TIPS (সুবিধা, পরিবহন ও নিয়মাবলী) */}
      {/* ============================================================== */}
      {activeSubTab === 'facilities' && (
        <div className="space-y-6">
          <div className="bg-white border border-[#ebe6dc] rounded-2xl p-6 sm:p-8 shadow-xs">
            <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 mb-2">
              {lang === 'bn'
                ? 'পর্যটকদের জন্য কি কি সুবিধা ও সেবাসমূহ রয়েছে?'
                : 'Tourist Amenities, Transport, Banking & Dining Facilities'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mb-6 max-w-3xl leading-relaxed">
              {lang === 'bn'
                ? 'বাংলাদেশে ভ্রমণকালে যোগাযোগ, লেনদেন, পরিবহন ও স্বাস্থ্য ব্যবস্থার আধুনিক সুবিধা রয়েছে। পর্যটকদের জন্য প্রয়োজনীয় সুবিধাসমূহ নিচে দেওয়া হলো।'
                : 'From ride-sharing apps and luxury high-speed AC express trains to mobile banking (bKash/Nagad) and international card ATMs, here is what you need to know.'}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {/* Transport Facilities */}
              <div className="rounded-2xl border border-slate-200/90 bg-white p-5 shadow-xs premium-card hover:border-sky-300">
                <div className="w-10 h-10 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center mb-3 shadow-2xs">
                  <Car className="w-5 h-5" />
                </div>
                <h4 className="text-base font-extrabold text-slate-900 mb-1.5">
                  {lang === 'bn' ? 'উবার ও রাইড শেয়ারিং' : 'Ride-Sharing & Cabs'}
                </h4>
                <p className="text-xs text-slate-500 leading-relaxed mb-3">
                  {lang === 'bn'
                    ? 'Uber ও Pathao অ্যাপ দিয়ে ঢাকা, চট্টগ্রাম ও সিলেটে সরাসরি এসি কার বা মোটরবাইক মিলবে।'
                    : 'Uber & Pathao provide seamless GPS-metered AC cars, CNGs and bike rides in major cities.'}
                </p>
                <div className="text-[11px] font-bold text-sky-800 bg-sky-50 px-2.5 py-1 rounded-lg">
                  {lang === 'bn' ? 'টিপস: বিমানবন্দর থেকে সরাসরি উবার পিকআপ সুবিধা।' : 'Airport terminal pickup zones available.'}
                </div>
              </div>

              {/* Railway & Express Trains */}
              <div className="rounded-2xl border border-slate-200/90 bg-white p-5 shadow-xs premium-card hover:border-emerald-300">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-[#0f6b4f] flex items-center justify-center mb-3 shadow-2xs">
                  <Train className="w-5 h-5" />
                </div>
                <h4 className="text-base font-extrabold text-slate-900 mb-1.5">
                  {lang === 'bn' ? 'রেলওয়ে এসি এক্সপ্রেস ট্রেন' : 'Modern Intercity Trains'}
                </h4>
                <p className="text-xs text-slate-500 leading-relaxed mb-3">
                  {lang === 'bn'
                    ? 'কক্সবাজার, পর্যটক ও পারাবত এক্সপ্রেস দিয়ে আরামদায়ক ট্রেন জার্নি। অনলাইনে টিকিট বুকিং।'
                    : 'Comfortable high-speed AC express trains connecting Dhaka to Cox’s Bazar and Sylhet.'}
                </p>
                <div className="text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg">
                  {lang === 'bn' ? 'অনলাইন টিকিট: eticket.railway.gov.bd' : 'Official: eticket.railway.gov.bd'}
                </div>
              </div>

              {/* Banking, ATMs & Currency Exchange */}
              <div className="rounded-2xl border border-slate-200/90 bg-white p-5 shadow-xs premium-card hover:border-amber-300">
                <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center mb-3 shadow-2xs">
                  <CreditCard className="w-5 h-5" />
                </div>
                <h4 className="text-base font-extrabold text-slate-900 mb-1.5">
                  {lang === 'bn' ? 'আন্তর্জাতিক এটিএম ও এক্সচেঞ্জ' : 'ATMs & Currency Exchange'}
                </h4>
                <p className="text-xs text-slate-500 leading-relaxed mb-3">
                  {lang === 'bn'
                    ? 'আন্তর্জাতিক Visa ও MasterCard সমর্থিত এটিএম বুথ এবং বিমানবন্দরে ২৪ ঘণ্টা মানি এক্সচেঞ্জ।'
                    : 'International Visa & Mastercard ATMs everywhere, plus 24/7 airport currency booths.'}
                </p>
                <div className="text-[11px] font-bold text-amber-800 bg-amber-50 px-2.5 py-1 rounded-lg">
                  {lang === 'bn' ? 'ডলার, ইউরো ও দিরহাম সহজেই বিনিময়যোগ্য।' : 'USD, EUR, AED easily exchanged.'}
                </div>
              </div>

              {/* Water & Food Hygiene */}
              <div className="rounded-2xl border border-slate-200/90 bg-white p-5 shadow-xs premium-card hover:border-rose-300">
                <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center mb-3 shadow-2xs">
                  <Utensils className="w-5 h-5" />
                </div>
                <h4 className="text-base font-extrabold text-slate-900 mb-1.5">
                  {lang === 'bn' ? 'বিশুদ্ধ পানি ও হালাল খাবার' : 'Water & Authentic Halal Food'}
                </h4>
                <p className="text-xs text-slate-500 leading-relaxed mb-3">
                  {lang === 'bn'
                    ? 'সবসময় বোতলজাত মিনারেল ওয়াটার পান করুন। সব খাবার শতভাগ হালাল ও ঐতিহ্যবাহী সুস্বাদু।'
                    : 'Always choose bottled sealed water. 100% Halal delicacies with famous Biryani and fish.'}
                </p>
                <div className="text-[11px] font-bold text-rose-800 bg-rose-50 px-2.5 py-1 rounded-lg">
                  {lang === 'bn' ? 'টিপস: শ্রীমঙ্গলের সাত রঙের চা ও ঐতিহ্যবাহী মিষ্টি।' : 'Try 7-layer tea and fresh Bengali sweets.'}
                </div>
              </div>

              {/* River Cruising & Launches */}
              <div className="rounded-2xl border border-slate-200/90 bg-white p-5 shadow-xs premium-card hover:border-teal-300">
                <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center mb-3 shadow-2xs">
                  <Ship className="w-5 h-5" />
                </div>
                <h4 className="text-base font-extrabold text-slate-900 mb-1.5">
                  {lang === 'bn' ? 'নৌযান ও নদী ক্রুজ' : 'River Cruises & Launches'}
                </h4>
                <p className="text-xs text-slate-500 leading-relaxed mb-3">
                  {lang === 'bn'
                    ? 'সদরঘাট থেকে বরিশাল-পটুয়াখালীর বিলাসবহুল এসি কেবিন লঞ্চ এক অনন্য প্রাকৃতিক অভিজ্ঞতা।'
                    : 'Overnight river cruises with VIP AC cabins offering scenic journeys from Sadarghat.'}
                </p>
                <div className="text-[11px] font-bold text-teal-800 bg-teal-50 px-2.5 py-1 rounded-lg">
                  {lang === 'bn' ? 'রুট: ঢাকা সদরঘাট ⇋ বরিশাল ও সুন্দরবন।' : 'Departs from Dhaka Sadarghat terminal.'}
                </div>
              </div>

              {/* Safety & Hospitality */}
              <div className="rounded-2xl border border-slate-200/90 bg-white p-5 shadow-xs premium-card hover:border-purple-300">
                <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center mb-3 shadow-2xs">
                  <HeartHandshake className="w-5 h-5" />
                </div>
                <h4 className="text-base font-extrabold text-slate-900 mb-1.5">
                  {lang === 'bn' ? 'নিরাপত্তা ও আন্তরিক আতিথেয়তা' : 'Hospitality & Safety'}
                </h4>
                <p className="text-xs text-slate-500 leading-relaxed mb-3">
                  {lang === 'bn'
                    ? 'বাংলাদেশের মানুষ অত্যন্ত অমায়িক ও অতিথিপরায়ণ। যেকোনো প্রয়োজনে ৯৯৯ বা ট্যুরিস্ট পুলিশ আছে।'
                    : 'World-renowned warmth and hospitality. Tourist police & 999 available 24/7.'}
                </p>
                <div className="text-[11px] font-bold text-purple-800 bg-purple-50 px-2.5 py-1 rounded-lg">
                  {lang === 'bn' ? '২৪/৭ সরকারি হটলাইন ৯৯৯ সক্রিয়।' : '24/7 National Emergency Hotline: 999'}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 6. ABOUT BANGLADESH (বাংলাদেশ সম্পর্কে জানুন) */}
      {/* ============================================================== */}
      {activeSubTab === 'about' && (
        <div className="space-y-6">
          <div className="bg-white border border-[#ebe6dc] rounded-2xl p-6 sm:p-8 shadow-xs">
            <div className="max-w-3xl mb-6">
              <span className="text-xs font-bold text-[#0f6b4f] flex items-center gap-1.5 mb-1">
                <Globe className="w-4 h-4" />
                {lang === 'bn' ? 'দেশ পরিচিতি' : 'Country Profile'}
              </span>
              <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                {lang === 'bn' ? 'বাংলাদেশ সম্পর্কে গুরুত্বপূর্ণ তথ্য' : 'Essential Facts About Bangladesh'}
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                {lang === 'bn'
                  ? 'দক্ষিণ এশিয়ার সবুজ শ্যামল নদীমাতৃক দেশ বাংলাদেশ। এখানে রয়েছে বিশ্বের দীর্ঘতম প্রাকৃতিক সমুদ্র সৈকত, বৃহত্তম ম্যানগ্রোভ বন ও সমৃদ্ধ ইতিহাস।'
                  : 'A lush green riverine country in South Asia, home to the world’s longest natural sandy beach, the biggest mangrove forest, and UNESCO ancient Buddhist and Islamic heritage sites.'}
              </p>
            </div>

            {/* Quick Facts Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-8">
              <div className="bg-[#faf8f4] p-3.5 rounded-xl border border-[#ebe6dc] text-center">
                <div className="text-[11px] text-slate-500 font-bold">{lang === 'bn' ? 'রাজধানী' : 'Capital'}</div>
                <div className="text-sm font-black text-slate-900 mt-1">{lang === 'bn' ? 'ঢাকা' : 'Dhaka'}</div>
              </div>
              <div className="bg-[#faf8f4] p-3.5 rounded-xl border border-[#ebe6dc] text-center">
                <div className="text-[11px] text-slate-500 font-bold">{lang === 'bn' ? 'ভাষা' : 'Language'}</div>
                <div className="text-sm font-black text-slate-900 mt-1">{lang === 'bn' ? 'বাংলা (ইংরেজি প্রচলিত)' : 'Bengali (English widely used)'}</div>
              </div>
              <div className="bg-[#faf8f4] p-3.5 rounded-xl border border-[#ebe6dc] text-center">
                <div className="text-[11px] text-slate-500 font-bold">{lang === 'bn' ? 'মুদ্রা' : 'Currency'}</div>
                <div className="text-sm font-black text-slate-900 mt-1">{lang === 'bn' ? 'টাকা (BDT - ৳)' : 'Taka (BDT - ৳)'}</div>
              </div>
              <div className="bg-[#faf8f4] p-3.5 rounded-xl border border-[#ebe6dc] text-center">
                <div className="text-[11px] text-slate-500 font-bold">{lang === 'bn' ? 'সময় অঞ্চল' : 'Time Zone'}</div>
                <div className="text-sm font-black text-slate-900 mt-1">GMT +6:00</div>
              </div>
              <div className="bg-[#faf8f4] p-3.5 rounded-xl border border-[#ebe6dc] text-center">
                <div className="text-[11px] text-slate-500 font-bold">{lang === 'bn' ? 'কলিং কোড' : 'Dialing Code'}</div>
                <div className="text-sm font-black text-slate-900 mt-1">+880</div>
              </div>
              <div className="bg-[#faf8f4] p-3.5 rounded-xl border border-[#ebe6dc] text-center">
                <div className="text-[11px] text-slate-500 font-bold">{lang === 'bn' ? 'জরুরি নম্বর' : 'Emergency'}</div>
                <div className="text-sm font-black text-rose-600 mt-1">999</div>
              </div>
            </div>

            {/* Visa on Arrival & Entry Guide */}
            <div className="rounded-2xl border border-emerald-200 bg-emerald-50/40 p-5 sm:p-6 mb-6">
              <h4 className="text-base font-extrabold text-emerald-900 flex items-center gap-2 mb-2">
                <ShieldCheck className="w-5 h-5 text-[#0f6b4f]" />
                <span>
                  {lang === 'bn'
                    ? 'ভিসা ও প্রবেশ সংক্রান্ত তথ্য (Visa on Arrival & eVisa)'
                    : 'Visa On Arrival (VoA) & Entry Requirements'}
                </span>
              </h4>
              <p className="text-xs sm:text-sm text-slate-700 leading-relaxed mb-3">
                {lang === 'bn'
                  ? 'যুক্তরাষ্ট্র, কানাডা, যুক্তরাজ্য, ইউরোপীয় ইউনিয়ন, অস্ট্রেলিয়া, জাপান, সংযুক্ত আরব আমিরাত (UAE) সহ বহু দেশের নাগরিকদের জন্য হযরত শাহজালাল আন্তর্জাতিক বিমানবন্দরে (HSIA) ৩০ দিনের ভিসা অন অ্যারাইভাল (Visa on Arrival) সুবিধা রয়েছে।'
                  : 'Citizens of USA, Canada, UK, EU nations, Australia, Japan, UAE, and GCC nations are eligible for a 30-day Visa on Arrival (VoA) at Hazrat Shahjalal International Airport (Dhaka) for tourism purposes.'}
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-slate-700">
                <div className="bg-white p-3 rounded-xl border border-emerald-100">
                  <strong>{lang === 'bn' ? 'পাসপোর্ট মেয়াদ:' : 'Passport Validity:'}</strong>{' '}
                  {lang === 'bn'
                    ? 'সর্বনিম্ন ৬ মাসের বৈধ পাসপোর্ট থাকা বাধ্যতামূলক।'
                    : 'Minimum 6 months of validity on entry is mandatory.'}
                </div>
                <div className="bg-white p-3 rounded-xl border border-emerald-100">
                  <strong>{lang === 'bn' ? 'রিটার্ন টিকিট ও হোটেল:' : 'Return Ticket & Hotel:'}</strong>{' '}
                  {lang === 'bn'
                    ? 'ফিরতি বিমান টিকিট ও হোটেল বুকিং কপি সঙ্গে রাখুন।'
                    : 'Keep return flight ticket and proof of lodging ready.'}
                </div>
                <div className="bg-white p-3 rounded-xl border border-emerald-100">
                  <strong>{lang === 'bn' ? 'ফি:' : 'VoA Fee:'}</strong>{' '}
                  {lang === 'bn'
                    ? 'সাধারণত $51 USD (ফি কাউন্টারে কার্ড বা ক্যাশ ডলারে পরিশোধযোগ্য)।'
                    : 'Typically ~$51 USD (payable via card or cash USD at airport booth).'}
                </div>
              </div>
            </div>

            {/* Cultural Etiquette & Season guide */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs text-slate-700 leading-relaxed">
              <div className="p-4 rounded-xl border border-slate-200 bg-[#faf8f4]">
                <h5 className="font-extrabold text-slate-900 text-sm mb-2 flex items-center gap-1.5">
                  <Sun className="w-4 h-4 text-amber-500" />
                  <span>{lang === 'bn' ? 'আবহাওয়া ও ঋতু' : 'Weather & Best Seasons'}</span>
                </h5>
                <p>
                  <strong>{lang === 'bn' ? 'শীতকাল (নভেম্বর - ফেব্রুয়ারি):' : 'Winter (Nov - Feb):'}</strong>{' '}
                  {lang === 'bn'
                    ? 'ভ্রমণের শ্রেষ্ঠ সময়। মনোরম মিষ্টি রোদ, তাপমাত্রা ১৫°-২৫° সেলসিয়াসের মধ্যে থাকে।'
                    : 'Best overall season with dry sunny days, cool evenings and pleasant 15°-25°C temperatures.'}
                  <br />
                  <strong>{lang === 'bn' ? 'বর্ষাকাল (জুন - সেপ্টেম্বর):' : 'Monsoon (Jun - Sep):'}</strong>{' '}
                  {lang === 'bn'
                    ? 'জলপ্রপাত, পাহাড়ি মেঘ ও নদী-হাওরের অপরূপ রূপ উপভোগ করার উপযুক্ত সময়।'
                    : 'Magical for lush waterfalls, hill clouds in Sajek, and houseboating on Tanguar Haor.'}
                </p>
              </div>

              <div className="p-4 rounded-xl border border-slate-200 bg-[#faf8f4]">
                <h5 className="font-extrabold text-slate-900 text-sm mb-2 flex items-center gap-1.5">
                  <HeartHandshake className="w-4 h-4 text-rose-500" />
                  <span>{lang === 'bn' ? 'সাংস্কৃতিক শিষ্টাচার ও পোশাক' : 'Cultural Etiquette & Tips'}</span>
                </h5>
                <p>
                  {lang === 'bn'
                    ? 'মসজিদ, মন্দির বা ধর্মীয় স্থানে শালীন পোশাক পরিধান করুন (জুতো খুলে প্রবেশ করুন)। স্থানীয় মানুষের ছবি তোলার আগে হাসিমুখে অনুমতি নেওয়া সৌজন্যমূলক। হাত মেলানোর সময় সাধারণত ডান হাত ব্যবহার করা হয়।'
                    : 'Dress modestly when visiting mosques, temples, or historic monuments (remove footwear before entering). Always ask with a warm smile before photographing locals. Greet with the right hand or a courteous "Nomoshkar/Salam".'}
                </p>
              </div>
            </div>

            {/* Social Connect & Developer profile */}
            <div className="mt-5 p-4 rounded-2xl bg-gradient-to-r from-emerald-50 via-[#f7f5f0] to-rose-50 border border-emerald-200/70 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-800 text-white flex items-center justify-center font-black text-sm shrink-0 shadow-xs">
                  MN
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-500">
                    {lang === 'bn' ? 'ডেভেলপার ও কিউরেটর' : 'Developer & Curator'}
                  </div>
                  <div className="text-sm font-black text-slate-900">
                    Muhiuddin Ahmed Nafis
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2.5 flex-wrap justify-center sm:justify-end">
                <a
                  href="https://www.facebook.com/profile.php?id=61555816542974"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#1877F2] hover:bg-[#1565C0] text-white text-xs font-bold transition-all shadow-xs"
                >
                  <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                  </svg>
                  <span>Facebook</span>
                  <ExternalLink className="w-3 h-3" />
                </a>

                <a
                  href="https://www.instagram.com/muhiudden_nafis/?hl=en"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 hover:opacity-95 text-white text-xs font-bold transition-all shadow-xs"
                >
                  <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                  </svg>
                  <span>Instagram (@muhiudden_nafis)</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
