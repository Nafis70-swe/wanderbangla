import React, { useState } from 'react';
import { Globe, Check, Plus, Plane, Compass, Award } from 'lucide-react';

interface WorldMapTrackerProps {
  lang: 'bn' | 'en';
}

interface Country {
  id: string;
  nameBn: string;
  nameEn: string;
  region: string;
  flag: string;
}

const POPULAR_COUNTRIES: Country[] = [
  { id: 'in', nameBn: 'ভারত', nameEn: 'India', region: 'দক্ষিণ এশিয়া', flag: '🇮🇳' },
  { id: 'np', nameBn: 'নেপাল', nameEn: 'Nepal', region: 'দক্ষিণ এশিয়া', flag: '🇳🇵' },
  { id: 'bt', nameBn: 'ভুটান', nameEn: 'Bhutan', region: 'দক্ষিণ এশিয়া', flag: '🇧🇹' },
  { id: 'mv', nameBn: 'মালদ্বীপ', nameEn: 'Maldives', region: 'দক্ষিণ এশিয়া', flag: '🇲🇻' },
  { id: 'lk', nameBn: 'শ্রীলঙ্কা', nameEn: 'Sri Lanka', region: 'দক্ষিণ এশিয়া', flag: '🇱🇰' },
  { id: 'th', nameBn: 'থাইল্যান্ড', nameEn: 'Thailand', region: 'দক্ষিণ-পূর্ব এশিয়া', flag: '🇹🇭' },
  { id: 'my', nameBn: 'মালয়েশিয়া', nameEn: 'Malaysia', region: 'দক্ষিণ-পূর্ব এশিয়া', flag: '🇲🇾' },
  { id: 'sg', nameBn: 'সিঙ্গাপুর', nameEn: 'Singapore', region: 'দক্ষিণ-পূর্ব এশিয়া', flag: '🇸🇬' },
  { id: 'id', nameBn: 'ইন্দোনেশিয়া (বালি)', nameEn: 'Indonesia (Bali)', region: 'দক্ষিণ-পূর্ব এশিয়া', flag: '🇮🇩' },
  { id: 'vn', nameBn: 'ভিয়েতনাম', nameEn: 'Vietnam', region: 'দক্ষিণ-পূর্ব এশিয়া', flag: '🇻🇳' },
  { id: 'ae', nameBn: 'সংযুক্ত আরব আমিরাত (দুবাই)', nameEn: 'UAE (Dubai)', region: 'মধ্যপ্রাচ্য', flag: '🇦🇪' },
  { id: 'sa', nameBn: 'সৌদি আরব', nameEn: 'Saudi Arabia', region: 'মধ্যপ্রাচ্য', flag: '🇸🇦' },
  { id: 'tr', nameBn: 'তুরস্ক', nameEn: 'Turkey', region: 'ইউরেশিয়া', flag: '🇹🇷' },
  { id: 'qa', nameBn: 'কাতার', nameEn: 'Qatar', region: 'মধ্যপ্রাচ্য', flag: '🇶🇦' },
  { id: 'uk', nameBn: 'যুক্তরাজ্য', nameEn: 'United Kingdom', region: 'ইউরোপ', flag: '🇬🇧' },
  { id: 'us', nameBn: 'যুক্তরাষ্ট্র', nameEn: 'United States', region: 'উত্তর আমেরিকা', flag: '🇺🇸' },
  { id: 'ca', nameBn: 'কানাডা', nameEn: 'Canada', region: 'উত্তর আমেরিকা', flag: '🇨🇦' },
  { id: 'fr', nameBn: 'ফ্রান্স', nameEn: 'France', region: 'ইউরোপ', flag: '🇫🇷' },
  { id: 'ch', nameBn: 'সুইজারল্যান্ড', nameEn: 'Switzerland', region: 'ইউরোপ', flag: '🇨🇭' },
  { id: 'jp', nameBn: 'জাপান', nameEn: 'Japan', region: 'পূর্ব এশিয়া', flag: '🇯🇵' },
];

export const WorldMapTracker: React.FC<WorldMapTrackerProps> = ({ lang }) => {
  const [visitedCountries, setVisitedCountries] = useState<Set<string>>(
    new Set(['in', 'np', 'th'])
  );

  const toggleCountry = (id: string) => {
    setVisitedCountries((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const total = POPULAR_COUNTRIES.length;
  const visited = visitedCountries.size;

  return (
    <div className="bg-white border border-[#ebe6dc] rounded-3xl p-6 sm:p-8 shadow-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-6 border-b border-[#ebe6dc]">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0f6b4f] bg-[#e3f0ea] px-3 py-1 rounded-full mb-2">
            <Globe className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? 'গ্লোবাল ট্রাভেল ট্র্যাকার' : 'Global Travel Tracker'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            {lang === 'bn' ? 'বিশ্ব ম্যাপ — দেশ ভ্রমণ ট্র্যাকার' : 'World Map — Country Tracker'}
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            {lang === 'bn'
              ? 'বাংলাদেশ ছাড়িয়ে বিশ্বের কোন কোন দেশে আপনি পা রেখেছেন? সিলেক্ট করে নিজের পাসপোর্ট লিস্ট সাজান।'
              : 'Beyond Bangladesh, which countries have you set foot in? Track your international journeys.'}
          </p>
        </div>

        <div className="flex items-center gap-3 bg-[#faf8f4] p-4 rounded-2xl border border-[#ebe6dc] self-start sm:self-auto">
          <Plane className="w-8 h-8 text-[#0f6b4f]" />
          <div>
            <div className="text-xl font-black text-slate-900">
              {visited} / {total} {lang === 'bn' ? 'দেশ' : 'Countries'}
            </div>
            <div className="text-xs text-slate-500 font-medium">
              {lang === 'bn' ? 'আন্তর্জাতিক ভ্রমণ সমাপ্ত' : 'Destinations Visited'}
            </div>
          </div>
        </div>
      </div>

      {/* Grid of Countries */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3.5">
        {POPULAR_COUNTRIES.map((country) => {
          const isVisited = visitedCountries.has(country.id);

          return (
            <button
              key={country.id}
              onClick={() => toggleCountry(country.id)}
              className={`p-3.5 rounded-2xl border text-left transition-all duration-150 cursor-pointer flex flex-col justify-between ${
                isVisited
                  ? 'bg-[#f7fbf9] border-[#0f6b4f] shadow-xs scale-101 ring-1 ring-[#0f6b4f]/30'
                  : 'bg-[#faf8f4] border-[#ebe6dc] hover:border-slate-300'
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <span className="text-2xl leading-none">{country.flag}</span>
                <span
                  className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                    isVisited ? 'bg-[#0f6b4f] text-white' : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  {isVisited ? <Check className="w-3 h-3 stroke-[2.5]" /> : '+'}
                </span>
              </div>

              <div>
                <div className="font-bold text-xs text-slate-900 leading-tight">
                  {lang === 'bn' ? country.nameBn : country.nameEn}
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">{country.region}</div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
