import React, { useState, useEffect } from 'react';
import { Compass, ChevronRight, ChevronLeft, MapPin, PhoneCall } from 'lucide-react';
import sajekImg from '../assets/images/hero_sajek_valley_1791467925600.jpg';
import coxsBazarImg from '../assets/images/coxs_bazar_sunset_1791467939002.jpg';
import sreemangalImg from '../assets/images/sreemangal_tea_gardens_1791467951603.jpg';
import sundarbansImg from '../assets/images/sundarbans_mangrove_forest_1791467963249.jpg';

interface HeroSectionProps {
  onStartClick: () => void;
  onOpenTouristGuide?: () => void;
  lang: 'bn' | 'en';
}

const HERO_IMAGES = [
  {
    src: sajekImg,
    titleBn: 'সাজেক ভ্যালি, রাঙ্গামাটি',
    titleEn: 'Sajek Valley, Rangamati',
    subtitleBn: 'পাহাড় ও মেঘের অবিরাম মিতালী',
    subtitleEn: 'Rolling clouds above the green valleys'
  },
  {
    src: coxsBazarImg,
    titleBn: 'কক্সবাজার সমুদ্র সৈকত',
    titleEn: "Cox's Bazar Sea Beach",
    subtitleBn: 'বিশ্বের দীর্ঘতম ১২০ কিমি বালুকাময় সৈকত',
    subtitleEn: "World's longest natural sandy beach"
  },
  {
    src: sreemangalImg,
    titleBn: 'শ্রীমঙ্গল চা বাগান, সিলেট',
    titleEn: 'Sreemangal Tea Estates',
    subtitleBn: 'সবুজে ঘেরা চায়ের স্নিগ্ধ রূপকথা',
    subtitleEn: 'Endless emerald green tea hills'
  },
  {
    src: sundarbansImg,
    titleBn: 'সুন্দরবন ম্যানগ্রোভ বনভূমি',
    titleEn: 'Sundarbans Mangrove',
    subtitleBn: 'বিশ্ব ঐতিহ্যের বুনো জল ও অরণ্য',
    subtitleEn: 'UNESCO World Heritage wild mangroves'
  },
];

export const HeroSection: React.FC<HeroSectionProps> = ({
  onStartClick,
  onOpenTouristGuide,
  lang,
}) => {
  const [activeImageIdx, setActiveImageIdx] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Auto Slideshow Effect every 4 seconds with smooth crossfade
  useEffect(() => {
    if (isPaused) return;
    const interval = setInterval(() => {
      setActiveImageIdx((prev) => (prev + 1) % HERO_IMAGES.length);
    }, 4000);

    return () => clearInterval(interval);
  }, [isPaused]);

  const handlePrev = () => {
    setActiveImageIdx((prev) => (prev - 1 + HERO_IMAGES.length) % HERO_IMAGES.length);
  };

  const handleNext = () => {
    setActiveImageIdx((prev) => (prev + 1) % HERO_IMAGES.length);
  };

  return (
    <header
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      className="relative isolate overflow-hidden rounded-3xl mb-8 p-6 sm:p-12 md:p-16 text-white bg-[#0b241b] shadow-xl group"
    >
      {/* Background Images Layer: 60% Visibility with Smooth Ken Burns Scale Pan Transition */}
      {HERO_IMAGES.map((img, idx) => {
        const isActive = activeImageIdx === idx;
        return (
          <div
            key={idx}
            className={`absolute inset-0 -z-20 transition-all duration-1000 ease-in-out ${
              isActive ? 'opacity-65 scale-105' : 'opacity-0 scale-100 pointer-events-none'
            }`}
          >
            <img
              src={img.src}
              alt={img.titleBn}
              referrerPolicy="no-referrer"
              className="h-full w-full object-cover object-center brightness-[0.9] contrast-[1.05]"
            />
          </div>
        );
      })}

      {/* Balanced Overlay Scrim ensuring high readability while keeping photos 60% visible */}
      <div className="absolute inset-0 -z-10 bg-gradient-to-t from-[#04160f]/85 via-[#04160f]/40 to-[#04160f]/30" />

      {/* Slideshow Arrow Navigation */}
      <button
        onClick={handlePrev}
        aria-label="Previous slide"
        className="hidden sm:flex absolute left-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-black/40 hover:bg-black/70 text-white items-center justify-center backdrop-blur-md border border-white/20 transition-all cursor-pointer opacity-80 hover:opacity-100"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>

      <button
        onClick={handleNext}
        aria-label="Next slide"
        className="hidden sm:flex absolute right-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-black/40 hover:bg-black/70 text-white items-center justify-center backdrop-blur-md border border-white/20 transition-all cursor-pointer opacity-80 hover:opacity-100"
      >
        <ChevronRight className="w-5 h-5" />
      </button>

      <div className="max-w-3xl mx-auto text-center flex flex-col items-center relative z-10 py-2">
        {/* Main Headline - Comfortable line-height and letter-spacing */}
        <h1 className="text-3xl sm:text-5xl md:text-6xl font-extrabold tracking-normal leading-[1.3] sm:leading-[1.25] md:leading-[1.22] mb-5 sm:mb-6 text-balance drop-shadow-sm">
          {lang === 'bn' ? (
            <>
              বাংলাদেশের{' '}
              <span className="bg-gradient-to-r from-[#8fe9c4] via-white to-[#ff8090] bg-clip-text text-transparent">
                কতটুকু
              </span>
              <br className="hidden sm:inline" />{' '}
              <span className="bg-gradient-to-r from-[#ff8090] via-white to-[#8fe9c4] bg-clip-text text-transparent">
                ঘুরেছেন
              </span>{' '}
              আপনি?
            </>
          ) : (
            <>
              How Much of{' '}
              <span className="bg-gradient-to-r from-[#8fe9c4] via-white to-[#ff8090] bg-clip-text text-transparent">
                Bangladesh
              </span>
              <br className="hidden sm:inline" />{' '}
              Have You Explored?
            </>
          )}
        </h1>

        {/* Short, crisp subtitle with relaxed line-height and generous gap */}
        <p className="text-sm sm:text-base md:text-lg text-white/90 max-w-lg mx-auto mb-8 sm:mb-9 font-normal leading-relaxed drop-shadow-xs">
          {lang === 'bn'
            ? 'ঘুরে আসা জেলা মার্ক করুন এবং নিজের ট্রাভেল ম্যাপ তৈরি করুন।'
            : 'Track your visited districts and build your travel map.'}
        </p>

        {/* Clean CTA Buttons with comfortable spacing */}
        <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4 mb-2">
          <button
            onClick={onStartClick}
            className="inline-flex items-center gap-2 bg-white hover:bg-slate-100 text-[#17201c] font-bold text-sm sm:text-base px-6 sm:px-7 py-3 rounded-full shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all duration-200 cursor-pointer"
          >
            <span>{lang === 'bn' ? 'ম্যাপ তৈরি শুরু করুন' : 'Start Making Map'}</span>
            <ChevronRight className="w-4 h-4 text-[#0f6b4f]" />
          </button>

          {onOpenTouristGuide && (
            <button
              onClick={onOpenTouristGuide}
              className="inline-flex items-center gap-2 bg-emerald-950/70 hover:bg-emerald-900/90 border border-emerald-400/30 text-emerald-100 font-bold text-sm sm:text-base px-5 sm:px-6 py-3 rounded-full backdrop-blur-md shadow-md transition-all duration-200 cursor-pointer hover:border-emerald-300"
            >
              <PhoneCall className="w-3.5 h-3.5 text-amber-300" />
              <span>{lang === 'bn' ? 'সেবা' : 'Seba'}</span>
            </button>
          )}
        </div>

        {/* Minimal Location Badge & Dots */}
        <div className="mt-6 flex flex-col items-center gap-2.5">
          <div className="flex items-center gap-1.5 text-xs text-white/95 font-medium bg-black/40 backdrop-blur-md px-3.5 py-1 rounded-full border border-white/20">
            <MapPin className="w-3.5 h-3.5 text-[#8fe9c4]" />
            <span>{HERO_IMAGES[activeImageIdx][lang === 'bn' ? 'titleBn' : 'titleEn']}</span>
          </div>

          {/* Dots Indicator */}
          <div className="flex items-center gap-1.5">
            {HERO_IMAGES.map((_, dotIdx) => (
              <button
                key={dotIdx}
                onClick={() => setActiveImageIdx(dotIdx)}
                aria-label={`Go to slide ${dotIdx + 1}`}
                className={`h-1.5 rounded-full transition-all duration-300 cursor-pointer ${
                  activeImageIdx === dotIdx
                    ? 'w-6 bg-[#8fe9c4]'
                    : 'w-1.5 bg-white/40 hover:bg-white/70'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </header>
  );
};
