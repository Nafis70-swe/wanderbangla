import React, { useState, useMemo, useRef } from 'react';
import {
  Download,
  Search,
  Check,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Book,
  RotateCcw,
  Globe2,
  Loader2,
  CheckCircle2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { toPng } from 'html-to-image';
import mapData from '../data/bangladeshMapPaths.json';
import { WanderBanglaLogo } from './WanderBanglaLogo';

export interface DestinationItem {
  id: string;
  nameBn: string;
  nameEn: string;
  districtBn: string;
  districtEn: string;
  color?: 'emerald' | 'navy' | 'crimson' | 'purple' | 'amber';
}

// Exactly 130 authentic destinations across Bangladesh (popular ones first)
export const BANGLADESH_130_DESTINATIONS: DestinationItem[] = [
  { id: 'coxs-bazar', nameBn: 'কক্সবাজার', nameEn: "Cox's Bazar", districtBn: 'কক্সবাজার', districtEn: "Cox's Bazar", color: 'navy' },
  { id: 'saint-martin', nameBn: 'সেন্টমার্টিন', nameEn: 'Saint Martin', districtBn: 'কক্সবাজার', districtEn: "Cox's Bazar", color: 'navy' },
  { id: 'sajek-valley', nameBn: 'সাজেক ভ্যালি', nameEn: 'Sajek Valley', districtBn: 'রাঙ্গামাটি', districtEn: 'Rangamati', color: 'crimson' },
  { id: 'ratargul', nameBn: 'রাতারগুল', nameEn: 'Ratargul Swamp', districtBn: 'সিলেট', districtEn: 'Sylhet', color: 'emerald' },
  { id: 'jaflong', nameBn: 'জাফলং', nameEn: 'Jaflong', districtBn: 'সিলেট', districtEn: 'Sylhet', color: 'emerald' },
  { id: 'sundarbans', nameBn: 'সুন্দরবন', nameEn: 'Sundarbans', districtBn: 'খুলনা', districtEn: 'Khulna', color: 'emerald' },
  { id: 'kuakata', nameBn: 'কুয়াকাটা', nameEn: 'Kuakata', districtBn: 'পটুয়াখালী', districtEn: 'Patuakhali', color: 'amber' },
  { id: 'nilgiri', nameBn: 'নীলগিরি', nameEn: 'Nilgiri Peak', districtBn: 'বান্দরবান', districtEn: 'Bandarban', color: 'purple' },
  { id: 'sreemangal', nameBn: 'শ্রীমঙ্গল', nameEn: 'Sreemangal', districtBn: 'মৌলভীবাজার', districtEn: 'Moulvibazar', color: 'emerald' },
  { id: 'tanguar-haor', nameBn: 'টাঙ্গুয়ার হাওর', nameEn: 'Tanguar Haor', districtBn: 'সুনামগঞ্জ', districtEn: 'Sunamganj', color: 'navy' },
  { id: 'kaptai-lake', nameBn: 'কাপ্তাই লেক', nameEn: 'Kaptai Lake', districtBn: 'রাঙ্গামাটি', districtEn: 'Rangamati', color: 'navy' },
  { id: 'bichanakandi', nameBn: 'বিছনাকান্দি', nameEn: 'Bichanakandi', districtBn: 'সিলেট', districtEn: 'Sylhet', color: 'emerald' },
  { id: 'nafakhum', nameBn: 'নাফাখুম', nameEn: 'Nafakhum Fall', districtBn: 'বান্দরবান', districtEn: 'Bandarban', color: 'crimson' },
  { id: 'shat-gombuj', nameBn: 'ষাট গম্বুজ মসজিদ', nameEn: 'Sixty Dome Mosque', districtBn: 'বাগেরহাট', districtEn: 'Bagerhat', color: 'amber' },
  { id: 'paharpur', nameBn: 'পাহাড়পুর', nameEn: 'Paharpur Vihara', districtBn: 'নওগাঁ', districtEn: 'Naogaon', color: 'purple' },
  { id: 'mahasthangarh', nameBn: 'মহাস্থানগড়', nameEn: 'Mahasthangarh', districtBn: 'বগুড়া', districtEn: 'Bogura', color: 'amber' },
  { id: 'sonargaon', nameBn: 'সোনারগাঁ', nameEn: 'Sonargaon', districtBn: 'নারায়ণগঞ্জ', districtEn: 'Narayanganj', color: 'crimson' },
  { id: 'lalbagh-fort', nameBn: 'লালবাগ কেল্লা', nameEn: 'Lalbagh Fort', districtBn: 'ঢাকা', districtEn: 'Dhaka', color: 'crimson' },
  { id: 'ahsan-manzil', nameBn: 'আহসান মঞ্জিল', nameEn: 'Ahsan Manzil', districtBn: 'ঢাকা', districtEn: 'Dhaka', color: 'crimson' },
  { id: 'boga-lake', nameBn: 'বগালেক', nameEn: 'Boga Lake', districtBn: 'বান্দরবান', districtEn: 'Bandarban', color: 'navy' },
  { id: 'keokradong', nameBn: 'কেওক্রাডং', nameEn: 'Keokradong Peak', districtBn: 'বান্দরবান', districtEn: 'Bandarban', color: 'crimson' },
  { id: 'amiakhum', nameBn: 'আমিয়াখুম', nameEn: 'Amiakhum Fall', districtBn: 'বান্দরবান', districtEn: 'Bandarban', color: 'purple' },
  { id: 'himchari', nameBn: 'হিমছড়ি', nameEn: 'Himchari', districtBn: 'কক্সবাজার', districtEn: "Cox's Bazar", color: 'navy' },
  { id: 'inani-beach', nameBn: 'ইনানী বিচ', nameEn: 'Inani Beach', districtBn: 'কক্সবাজার', districtEn: "Cox's Bazar", color: 'navy' },
  { id: 'maheshkhali', nameBn: 'মহেশখালী', nameEn: 'Moheshkhali', districtBn: 'কক্সবাজার', districtEn: "Cox's Bazar", color: 'navy' },
  { id: 'chheradwip', nameBn: 'ছেঁড়াদ্বীপ', nameEn: 'Chera Dwip', districtBn: 'কক্সবাজার', districtEn: "Cox's Bazar", color: 'navy' },
  { id: 'sonarchar', nameBn: 'সোনারচর', nameEn: 'Sonarchar Beach', districtBn: 'পটুয়াখালী', districtEn: 'Patuakhali', color: 'amber' },
  { id: 'lawachara', nameBn: 'লাউয়াছড়া উদ্যান', nameEn: 'Lawachara Forest', districtBn: 'মৌলভীবাজার', districtEn: 'Moulvibazar', color: 'emerald' },
  { id: 'madhabkunda', nameBn: 'মাধবকুণ্ড জলপ্রপাত', nameEn: 'Madhabkunda Waterfall', districtBn: 'মৌলভীবাজার', districtEn: 'Moulvibazar', color: 'navy' },
  { id: 'humhum', nameBn: 'হামহাম জলপ্রপাত', nameEn: 'Humhum Waterfall', districtBn: 'মৌলভীবাজার', districtEn: 'Moulvibazar', color: 'emerald' },
  { id: 'malnicherra', nameBn: 'মালনীছড়া চা বাগান', nameEn: 'Malnicherra Tea Estate', districtBn: 'সিলেট', districtEn: 'Sylhet', color: 'emerald' },
  { id: 'shah-jalal', nameBn: 'শাহজালাল মাজার', nameEn: 'Hazrat Shah Jalal Dargah', districtBn: 'সিলেট', districtEn: 'Sylhet', color: 'emerald' },
  { id: 'bholaganj', nameBn: 'ভোলাগঞ্জ সাদাপাথর', nameEn: 'Bholaganj Sada Pathor', districtBn: 'সিলেট', districtEn: 'Sylhet', color: 'navy' },
  { id: 'panthumai', nameBn: 'পান্থুমাই ঝরনা', nameEn: 'Panthumai Waterfall', districtBn: 'সিলেট', districtEn: 'Sylhet', color: 'emerald' },
  { id: 'jadukata', nameBn: 'জাদুকাটা নদী', nameEn: 'Jadukata River', districtBn: 'সুনামগঞ্জ', districtEn: 'Sunamganj', color: 'navy' },
  { id: 'barek-tila', nameBn: 'বারেক টিলা', nameEn: 'Barek Tila', districtBn: 'সুনামগঞ্জ', districtEn: 'Sunamganj', color: 'emerald' },
  { id: 'shimul-bagan', nameBn: 'শিমুল বাগান', nameEn: 'Shimul Bagan', districtBn: 'সুনামগঞ্জ', districtEn: 'Sunamganj', color: 'crimson' },
  { id: 'haringhata', nameBn: 'হরিণঘাটা বন', nameEn: 'Haringhata Forest', districtBn: 'বরগুনা', districtEn: 'Barguna', color: 'emerald' },
  { id: 'shuvoshondha', nameBn: 'শুভসন্ধ্যা বিচ', nameEn: 'Shuvoshondha Beach', districtBn: 'বরগুনা', districtEn: 'Barguna', color: 'amber' },
  { id: 'guthia-mosque', nameBn: 'গুঠিয়া মসজিদ', nameEn: 'Guthia Mosque', districtBn: 'বরিশাল', districtEn: 'Barishal', color: 'emerald' },
  { id: 'durgasagar', nameBn: 'দুর্গাসাগর দীঘি', nameEn: 'Durgasagar Dighi', districtBn: 'বরিশাল', districtEn: 'Barishal', color: 'navy' },
  { id: 'floating-guava', nameBn: 'ভাসমান পেয়ারা বাজার', nameEn: 'Floating Guava Market', districtBn: 'ঝালকাঠি', districtEn: 'Jhalokathi', color: 'emerald' },
  { id: 'monpura', nameBn: 'মনপুরা দ্বীপ', nameEn: 'Monpura Island', districtBn: 'ভোলা', districtEn: 'Bhola', color: 'navy' },
  { id: 'kukri-mukri', nameBn: 'চর কুকরি মুকরি', nameEn: 'Char Kukri Mukri', districtBn: 'ভোলা', districtEn: 'Bhola', color: 'emerald' },
  { id: 'nijhum-dwip', nameBn: 'নিঝুম দ্বীপ', nameEn: 'Nijhum Dwip', districtBn: 'নোয়াখালী', districtEn: 'Noakhali', color: 'emerald' },
  { id: 'chandranath', nameBn: 'চন্দ্রনাথ পাহাড়', nameEn: 'Chandranath Peak', districtBn: 'চট্টগ্রাম', districtEn: 'Chittagong', color: 'crimson' },
  { id: 'guliakhali', nameBn: 'গুলিয়াখালী বিচ', nameEn: 'Guliakhali Beach', districtBn: 'চট্টগ্রাম', districtEn: 'Chittagong', color: 'emerald' },
  { id: 'patenga', nameBn: 'পতেঙ্গা সমুদ্র সৈকত', nameEn: 'Patenga Beach', districtBn: 'চট্টগ্রাম', districtEn: 'Chittagong', color: 'navy' },
  { id: 'naval-beach', nameBn: 'নেভাল বিচ', nameEn: 'Naval Beach', districtBn: 'চট্টগ্রাম', districtEn: 'Chittagong', color: 'navy' },
  { id: 'foy-lake', nameBn: 'ফয়েজ লেক', nameEn: "Foy's Lake", districtBn: 'চট্টগ্রাম', districtEn: 'Chittagong', color: 'navy' },
  { id: 'war-cemetery', nameBn: 'ওয়ার সিমেট্রি', nameEn: 'War Cemetery', districtBn: 'চট্টগ্রাম', districtEn: 'Chittagong', color: 'purple' },
  { id: 'kantaji', nameBn: 'কান্তজিউ মন্দির', nameEn: 'Kantajew Temple', districtBn: 'দিনাজপুর', districtEn: 'Dinajpur', color: 'amber' },
  { id: 'swapnapuri', nameBn: 'স্বপ্নপুরী', nameEn: 'Swapnapuri Park', districtBn: 'দিনাজপুর', districtEn: 'Dinajpur', color: 'purple' },
  { id: 'ramsagar', nameBn: 'রামসাগর দীঘি', nameEn: 'Ramsagar Dighi', districtBn: 'দিনাজপুর', districtEn: 'Dinajpur', color: 'navy' },
  { id: 'tetulia', nameBn: 'তেঁতুলিয়া বাংলাবান্ধা', nameEn: 'Tetulia Banglabandha', districtBn: 'পঞ্চগড়', districtEn: 'Panchagarh', color: 'emerald' },
  { id: 'teesta-barrage', nameBn: 'তিস্তা ব্যারেজ', nameEn: 'Teesta Barrage', districtBn: 'লালমনিরহাট', districtEn: 'Lalmonirhat', color: 'navy' },
  { id: 'tajhat-palace', nameBn: 'তাজহাট জমিদার বাড়ি', nameEn: 'Tajhat Palace', districtBn: 'রংপুর', districtEn: 'Rangpur', color: 'crimson' },
  { id: 'sompur-vihara', nameBn: 'সোমপুর মহাবিহার', nameEn: 'Somapura Mahavihara', districtBn: 'নওগাঁ', districtEn: 'Naogaon', color: 'purple' },
  { id: 'kusumba-mosque', nameBn: 'কুসুম্বা মসজিদ', nameEn: 'Kusumba Mosque', districtBn: 'নওগাঁ', districtEn: 'Naogaon', color: 'amber' },
  { id: 'bagha-mosque', nameBn: 'বাঘা মসজিদ', nameEn: 'Bagha Mosque', districtBn: 'রাজশাহী', districtEn: 'Rajshahi', color: 'crimson' },
  { id: 'puthia-palace', nameBn: 'পুঠিয়া রাজবাড়ি', nameEn: 'Puthia Rajbari', districtBn: 'রাজশাহী', districtEn: 'Rajshahi', color: 'purple' },
  { id: 'padma-garden', nameBn: 'পদ্মা গার্ডেন', nameEn: 'Padma Garden', districtBn: 'রাজশাহী', districtEn: 'Rajshahi', color: 'navy' },
  { id: 'uttara-ganabhaban', nameBn: 'উত্তরা গণভবন', nameEn: 'Uttara Gonobhaban', districtBn: 'নাটোর', districtEn: 'Natore', color: 'amber' },
  { id: 'chalan-beel', nameBn: 'চলনবিল', nameEn: 'Chalan Beel', districtBn: 'নাটোর', districtEn: 'Natore', color: 'navy' },
  { id: 'hardinge-bridge', nameBn: 'হার্ডিঞ্জ ব্রিজ', nameEn: 'Hardinge Bridge', districtBn: 'পাবনা', districtEn: 'Pabna', color: 'navy' },
  { id: 'lalon-mosholeum', nameBn: 'লালন শাহ মাজার', nameEn: 'Lalon Shah Mazar', districtBn: 'কুষ্টিয়া', districtEn: 'Kushtia', color: 'purple' },
  { id: 'shilaidaha', nameBn: 'শিলাইদহ রবীন্দ্র কুঠিবাড়ি', nameEn: 'Shilaidaha Kuthibari', districtBn: 'কুষ্টিয়া', districtEn: 'Kushtia', color: 'amber' },
  { id: 'mujibnagar', nameBn: 'মুজিবনগর স্মৃতিসৌধ', nameEn: 'Mujibnagar Monument', districtBn: 'মেহেরপুর', districtEn: 'Meherpur', color: 'emerald' },
  { id: 'khan-jahan-ali', nameBn: 'খানজাহান আলী মাজার', nameEn: 'Khan Jahan Ali Mazar', districtBn: 'বাগেরহাট', districtEn: 'Bagerhat', color: 'amber' },
  { id: 'kotka-beach', nameBn: 'কটকা বিচ', nameEn: 'Kotka Beach', districtBn: 'খুলনা', districtEn: 'Khulna', color: 'emerald' },
  { id: 'hiron-point', nameBn: 'হিরণ পয়েন্ট', nameEn: 'Hiron Point', districtBn: 'খুলনা', districtEn: 'Khulna', color: 'navy' },
  { id: 'dublar-char', nameBn: 'দুবলার চর', nameEn: 'Dublar Char', districtBn: 'খুলনা', districtEn: 'Khulna', color: 'navy' },
  { id: 'karamjal', nameBn: 'করমজল', nameEn: 'Karamjal Sundarbans', districtBn: 'খুলনা', districtEn: 'Khulna', color: 'emerald' },
  { id: 'nokshikatha-village', nameBn: 'নকশীকাঁথা গ্রাম', nameEn: 'Nakshi Kantha Village', districtBn: 'যশোর', districtEn: 'Jashore', color: 'amber' },
  { id: 'modhusudan-bari', nameBn: 'মাইকেল মধুসূদন দত্ত বাড়ি', nameEn: 'Michael Madhusudan House', districtBn: 'যশোর', districtEn: 'Jashore', color: 'purple' },
  { id: 'smrity-soudha', nameBn: 'জাতীয় স্মৃতিসৌধ', nameEn: 'National Martyrs Monument', districtBn: 'ঢাকা', districtEn: 'Dhaka', color: 'crimson' },
  { id: 'shaheed-minar', nameBn: 'কেন্দ্রীয় শহীদ মিনার', nameEn: 'Central Shaheed Minar', districtBn: 'ঢাকা', districtEn: 'Dhaka', color: 'crimson' },
  { id: 'national-parliament', nameBn: 'জাতীয় সংসদ ভবন', nameEn: 'National Parliament', districtBn: 'ঢাকা', districtEn: 'Dhaka', color: 'emerald' },
  { id: 'baliati-palace', nameBn: 'বালিয়াটি প্রাসাদ', nameEn: 'Baliati Palace', districtBn: 'মানিকগঞ্জ', districtEn: 'Manikganj', color: 'amber' },
  { id: 'panam-city', nameBn: 'পানাম নগর', nameEn: 'Panam City', districtBn: 'নারায়ণগঞ্জ', districtEn: 'Narayanganj', color: 'crimson' },
  { id: 'shalban-vihara', nameBn: 'শালবন বৌদ্ধ বিহার', nameEn: 'Shalban Vihara', districtBn: 'কুমিল্লা', districtEn: 'Cumilla', color: 'purple' },
  { id: 'dharmasagar', nameBn: 'ধর্মসাগর দীঘি', nameEn: 'Dharmasagar Dighi', districtBn: 'কুমিল্লা', districtEn: 'Cumilla', color: 'navy' },
  { id: 'birishiri', nameBn: 'বিরিশিরি চীনা মাটির পাহাড়', nameEn: 'Birishiri Ceramic Hill', districtBn: 'নেত্রকোনা', districtEn: 'Netrokona', color: 'navy' },
  { id: 'susang-durgapur', nameBn: 'সুসং দুর্গাপুর', nameEn: 'Susang Durgapur', districtBn: 'নেত্রকোনা', districtEn: 'Netrokona', color: 'emerald' },
  { id: 'garo-hills', nameBn: 'গারো পাহাড়', nameEn: 'Garo Hills', districtBn: 'শেরপুর', districtEn: 'Sherpur', color: 'emerald' },
  { id: 'madhupur-forest', nameBn: 'মধুপুর শালবন', nameEn: 'Madhupur Sal Forest', districtBn: 'টাঙ্গাইল', districtEn: 'Tangail', color: 'emerald' },
  { id: 'mohera-zamindar', nameBn: 'মহেরা জমিদার বাড়ি', nameEn: 'Mohera Zamindar Bari', districtBn: 'টাঙ্গাইল', districtEn: 'Tangail', color: 'amber' },
  { id: 'idrakpur-fort', nameBn: 'ইদ্রাকপুর কেল্লা', nameEn: 'Idrakpur Fort', districtBn: 'মুন্সীগঞ্জ', districtEn: 'Munshiganj', color: 'crimson' },
  { id: 'ariyal-beel', nameBn: 'আড়িয়াল বিল', nameEn: 'Ariyal Beel', districtBn: 'মুন্সীগঞ্জ', districtEn: 'Munshiganj', color: 'navy' },
  { id: 'someshwari-river', nameBn: 'সোমেশ্বরী নদী', nameEn: 'Someshwari River', districtBn: 'নেত্রকোনা', districtEn: 'Netrokona', color: 'navy' },
  { id: 'nikli-haor', nameBn: 'নিকলী হাওর', nameEn: 'Nikli Haor', districtBn: 'কিশোরগঞ্জ', districtEn: 'Kishoreganj', color: 'navy' },
  { id: 'ashtagram-road', nameBn: 'অষ্টগ্রাম অলওয়েদার রোড', nameEn: 'Ashtagram All-Weather Road', districtBn: 'কিশোরগঞ্জ', districtEn: 'Kishoreganj', color: 'navy' },
  { id: 'mithamoin-haor', nameBn: 'মিঠামইন হাওর', nameEn: 'Mithamoin Haor', districtBn: 'কিশোরগঞ্জ', districtEn: 'Kishoreganj', color: 'navy' },
  { id: 'chimbuk-hill', nameBn: 'চিম্বুক পাহাড়', nameEn: 'Chimbuk Hill', districtBn: 'বান্দরবান', districtEn: 'Bandarban', color: 'crimson' },
  { id: 'dim-pahar', nameBn: 'ডিম পাহাড়', nameEn: 'Dim Pahar Thanchi', districtBn: 'বান্দরবান', districtEn: 'Bandarban', color: 'purple' },
  { id: 'thanchi', nameBn: 'থানচি সাঙ্গু নদী', nameEn: 'Thanchi Sangu River', districtBn: 'বান্দরবান', districtEn: 'Bandarban', color: 'navy' },
  { id: 'rema-kalenga', nameBn: 'রেমা-কালেঙ্গা বন', nameEn: 'Rema-Kalenga Forest', districtBn: 'হবিগঞ্জ', districtEn: 'Habiganj', color: 'emerald' },
  { id: 'satchari-park', nameBn: 'সাতছড়ি জাতীয় উদ্যান', nameEn: 'Satchari National Park', districtBn: 'হবিগঞ্জ', districtEn: 'Habiganj', color: 'emerald' },
  { id: 'terokhada-beel', nameBn: 'তেরখাদা পদ্মবিল', nameEn: 'Terokhada Lotus Beel', districtBn: 'খুলনা', districtEn: 'Khulna', color: 'crimson' },
  { id: 'rupsha-bridge', nameBn: 'রূপসা সেতু', nameEn: 'Rupsha Bridge', districtBn: 'খুলনা', districtEn: 'Khulna', color: 'navy' },
  { id: 'ruposhi-bangla', nameBn: 'রূপসী বাংলা বিচ', nameEn: 'Ruposhi Bangla Beach', districtBn: 'ভোলা', districtEn: 'Bhola', color: 'navy' },
  { id: 'banshbaria-beach', nameBn: 'বাঁশবাড়িয়া বিচ', nameEn: 'Banshbaria Sea Beach', districtBn: 'চট্টগ্রাম', districtEn: 'Chittagong', color: 'navy' },
  { id: 'sitakunda-ecopark', nameBn: 'সীতাকুণ্ড ইকোপার্ক', nameEn: 'Sitakunda Eco Park', districtBn: 'চট্টগ্রাম', districtEn: 'Chittagong', color: 'emerald' },
  { id: 'mohamaya-lake', nameBn: 'মিরসরাই মহামায়া লেক', nameEn: 'Mohamaya Lake', districtBn: 'চট্টগ্রাম', districtEn: 'Chittagong', color: 'navy' },
  { id: 'khoiyachora', nameBn: 'খৈয়াছড়া ঝরনা', nameEn: 'Khoiyachora Waterfall', districtBn: 'চট্টগ্রাম', districtEn: 'Chittagong', color: 'navy' },
  { id: 'jhorjhori-trail', nameBn: 'ঝরঝরি ট্রেইল', nameEn: 'Jhorjhori Trail', districtBn: 'চট্টগ্রাম', districtEn: 'Chittagong', color: 'emerald' },
  { id: 'alutila-cave', nameBn: 'আলুটিলা রহস্যময় গুহা', nameEn: 'Alutila Cave', districtBn: 'খাগড়াছড়ি', districtEn: 'Khagrachhari', color: 'purple' },
  { id: 'tareng-hill', nameBn: 'তারেং হিল', nameEn: 'Tareng Hill', districtBn: 'খাগড়াছড়ি', districtEn: 'Khagrachhari', color: 'emerald' },
  { id: 'richang-waterfall', nameBn: 'রিছাং ঝরনা', nameEn: 'Richang Waterfall', districtBn: 'খাগড়াছড়ি', districtEn: 'Khagrachhari', color: 'navy' },
  { id: 'hatimatha-hill', nameBn: 'হাতিমাথা পাহাড়', nameEn: 'Hatimatha Peak', districtBn: 'খাগড়াছড়ি', districtEn: 'Khagrachhari', color: 'crimson' },
  { id: 'shubholong', nameBn: 'শুভলং ঝরনা', nameEn: 'Shubholong Waterfall', districtBn: 'রাঙ্গামাটি', districtEn: 'Rangamati', color: 'navy' },
  { id: 'hanging-bridge', nameBn: 'ঝুলন্ত সেতু', nameEn: 'Hanging Bridge Rangamati', districtBn: 'রাঙ্গামাটি', districtEn: 'Rangamati', color: 'crimson' },
  { id: 'polwel-park', nameBn: 'পলওয়েল পার্ক', nameEn: 'Polwel Park Lake', districtBn: 'রাঙ্গামাটি', districtEn: 'Rangamati', color: 'navy' },
  { id: 'sajek-helipad', nameBn: 'সাজেক হেলিপ্যাড সানসেট', nameEn: 'Sajek Helipad Sunset', districtBn: 'রাঙ্গামাটি', districtEn: 'Rangamati', color: 'amber' },
  { id: 'ruma-bazar', nameBn: 'রুমা বাজার', nameEn: 'Ruma Bazar', districtBn: 'বান্দরবান', districtEn: 'Bandarban', color: 'navy' },
  { id: 'dhanmondi-lake', nameBn: 'ধানমন্ডি লেক ও রবীন্দ্র সরোবর', nameEn: 'Dhanmondi Lake', districtBn: 'ঢাকা', districtEn: 'Dhaka', color: 'emerald' },
  { id: 'botanical-garden', nameBn: 'মিরপুর বোটানিক্যাল গার্ডেন', nameEn: 'Botanical Garden', districtBn: 'ঢাকা', districtEn: 'Dhaka', color: 'emerald' },
  { id: 'bhawal-park', nameBn: 'ভাওয়াল জাতীয় উদ্যান', nameEn: 'Bhawal National Park', districtBn: 'গাজীপুর', districtEn: 'Gazipur', color: 'emerald' },
  { id: 'belai-beel', nameBn: 'বেলাই বিল', nameEn: 'Belai Beel', districtBn: 'গাজীপুর', districtEn: 'Gazipur', color: 'navy' },
  { id: 'safari-park', nameBn: 'বঙ্গবন্ধু সাফারি পার্ক', nameEn: 'Safari Park Gazipur', districtBn: 'গাজীপুর', districtEn: 'Gazipur', color: 'amber' },
  { id: 'mainot-ghat', nameBn: 'মৈনট ঘাট মিনি কক্সবাজার', nameEn: 'Mainot Ghat', districtBn: 'ঢাকা', districtEn: 'Dhaka', color: 'navy' },
  { id: 'nawabganj-palace', nameBn: 'নবাবগঞ্জ জজবাড়ি', nameEn: 'Nawabganj Palace', districtBn: 'ঢাকা', districtEn: 'Dhaka', color: 'purple' },
  { id: 'padma-char', nameBn: 'পদ্মার চর', nameEn: 'Padma River Char', districtBn: 'শরীয়তপুর', districtEn: 'Shariatpur', color: 'amber' },
  { id: 'rampal-dighi', nameBn: 'রামপাল দীঘি', nameEn: 'Rampal Dighi', districtBn: 'মুন্সীগঞ্জ', districtEn: 'Munshiganj', color: 'navy' },
  { id: 'modhumoti-river', nameBn: 'মধুমতি নদী', nameEn: 'Modhumoti River', districtBn: 'গোপালগঞ্জ', districtEn: 'Gopalganj', color: 'navy' },
  { id: 'tungipara-samadhi', nameBn: 'টুঙ্গিপাড়া সমাধি সৌধ', nameEn: 'Tungipara Mausoleum', districtBn: 'গোপালগঞ্জ', districtEn: 'Gopalganj', color: 'emerald' },
  { id: 'gabkhan-bridge', nameBn: 'গাবখান সেতু', nameEn: 'Gabkhan Bridge', districtBn: 'ঝালকাঠি', districtEn: 'Jhalokathi', color: 'navy' },
  { id: 'laldia-sea-beach', nameBn: 'লালদিয়া সমুদ্র সৈকত', nameEn: 'Laldia Sea Beach', districtBn: 'বরগুনা', districtEn: 'Barguna', color: 'amber' },
  { id: 'tengragiri-forest', nameBn: 'টেংরাগিরি বন্যপ্রাণী অভয়ারণ্য', nameEn: 'Tengragiri Wildlife Sanctuary', districtBn: 'বরগুনা', districtEn: 'Barguna', color: 'emerald' },
  { id: 'char-fesson', nameBn: 'জ্যাকব ওয়াচ টাওয়ার চরফ্যাশন', nameEn: 'Jacob Watch Tower', districtBn: 'ভোলা', districtEn: 'Bhola', color: 'purple' },
];

interface TravelPassportBookProps {
  lang: 'bn' | 'en';
  selectedDistricts?: Set<string>;
  onToggleDistrict?: (districtId: string) => void;
}

// ============================================================================
// Robust Canvas Fallback Renderer for Passport Book Spread Export
// Exactly matches the open booklet design in user's image
// ============================================================================
function renderPassportPageToCanvas(
  travelerName: string,
  pageIndex: number,
  totalPages: number,
  topStamps: DestinationItem[],
  bottomStamps: DestinationItem[],
  totalStampsCount: number,
  lang: 'bn' | 'en'
): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  const width = 1000;
  const height = 1380;
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return canvas;

  // 1. Parchment paper background
  ctx.fillStyle = '#f3eee4';
  ctx.fillRect(0, 0, width, height);

  // 2. Left & Right Forest Green Outer Spine Binding Bars
  ctx.fillStyle = '#083827';
  ctx.fillRect(0, 0, 16, height);
  ctx.fillRect(width - 16, 0, 16, height);

  ctx.strokeStyle = '#124c36';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(8, 0);
  ctx.lineTo(8, height);
  ctx.moveTo(width - 8, 0);
  ctx.lineTo(width - 8, height);
  ctx.stroke();

  // 3. Banknote Guilloche Wavy Sine Curves
  ctx.save();
  ctx.strokeStyle = 'rgba(31, 84, 62, 0.08)';
  ctx.lineWidth = 0.8;
  for (let y = 30; y < height - 30; y += 18) {
    ctx.beginPath();
    for (let x = 20; x <= width - 20; x += 10) {
      const wave = Math.sin((x / 60) + (y / 40)) * 6;
      if (x === 20) ctx.moveTo(x, y + wave);
      else ctx.lineTo(x, y + wave);
    }
    ctx.stroke();
  }
  ctx.restore();

  // Helper for Central Guilloche Rosette Watermark
  const drawRosetteWatermark = (cx: number, cy: number) => {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.strokeStyle = 'rgba(27, 67, 50, 0.08)';
    ctx.lineWidth = 0.8;
    for (let i = 0; i < 16; i++) {
      ctx.beginPath();
      ctx.ellipse(0, 0, 140, 75, (i * Math.PI) / 16, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.beginPath();
    ctx.setLineDash([4, 4]);
    ctx.arc(0, 0, 60, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
  };

  // Helper to draw circular stamp slot (empty or filled)
  const drawStampSlot = (item: DestinationItem | undefined, x: number, y: number, radius = 50) => {
    ctx.save();
    ctx.translate(x, y);

    if (!item) {
      // Empty dashed circle slot matching photo
      ctx.strokeStyle = '#97bba5';
      ctx.setLineDash([4, 4]);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, radius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
      return;
    }

    // Stamped slot
    const colorMap: Record<string, { stroke: string; bg: string }> = {
      crimson: { stroke: '#be123c', bg: '#fff1f2' },
      navy: { stroke: '#1d4ed8', bg: '#eff6ff' },
      purple: { stroke: '#7e22ce', bg: '#faf5ff' },
      amber: { stroke: '#b45309', bg: '#fffbeb' },
      emerald: { stroke: '#0d5c3a', bg: '#ecfdf5' },
    };
    const c = colorMap[item.color || 'emerald'] || colorMap.emerald;

    // Fill background
    ctx.fillStyle = c.bg;
    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, Math.PI * 2);
    ctx.fill();

    // Outer dashed ring
    ctx.strokeStyle = c.stroke;
    ctx.setLineDash([5, 4]);
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, Math.PI * 2);
    ctx.stroke();

    // Inner thin ring
    ctx.setLineDash([]);
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(0, 0, radius - 7, 0, Math.PI * 2);
    ctx.stroke();

    // Stamp text
    ctx.textAlign = 'center';
    ctx.fillStyle = c.stroke;
    ctx.font = 'bold 10px sans-serif';
    ctx.fillText('★ ENTRY ★', 0, -radius + 20);

    ctx.font = 'bold 15px sans-serif';
    const placeName = lang === 'bn' ? item.nameBn : item.nameEn;
    ctx.fillText(placeName, 0, 5);

    ctx.font = '600 11px sans-serif';
    const districtName = lang === 'bn' ? item.districtBn : item.districtEn;
    ctx.fillText(districtName, 0, radius - 15);

    ctx.restore();
  };

  // ==========================================================
  // TOP PAGE (ভ্রমণ পাসপোর্ট • TRAVEL PASSPORT)
  // ==========================================================
  ctx.fillStyle = '#23533e';
  ctx.font = 'bold 13px sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText('ভ্রমণ পাসপোর্ট • TRAVEL PASSPORT', 36, 36);
  ctx.textAlign = 'right';
  ctx.fillText('BANGLADESH', width - 36, 36);

  ctx.strokeStyle = '#bccdc1';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(36, 46);
  ctx.lineTo(width - 36, 46);
  ctx.stroke();

  // Photo Box (Left) with green Bangladesh map outline
  ctx.fillStyle = '#ffffff';
  ctx.strokeStyle = '#23533e';
  ctx.lineWidth = 1.5;
  ctx.fillRect(36, 58, 80, 105);
  ctx.strokeRect(36, 58, 80, 105);

  ctx.fillStyle = '#0d5c3a';
  ctx.font = 'bold 11px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('🇧🇩 BD MAP', 76, 115);

  // Identity Details (Center)
  ctx.textAlign = 'left';
  ctx.fillStyle = '#6c8275';
  ctx.font = 'bold 11px sans-serif';
  ctx.fillText('নাম / NAME', 132, 74);

  ctx.fillStyle = '#22332a';
  ctx.font = 'bold 24px sans-serif';
  const travelerNameStr = travelerName.trim() || (lang === 'bn' ? 'আপনার নাম' : 'YOUR NAME');
  ctx.fillText(travelerNameStr, 132, 104);

  // 3 Columns: Passport No, Issued, Stamps
  ctx.fillStyle = '#6c8275';
  ctx.font = 'bold 10px sans-serif';
  ctx.fillText('পাসপোর্ট নং / PASSPORT NO.', 132, 135);
  ctx.fillText('ইস্যু / ISSUED', 360, 135);
  ctx.fillText('সিল / STAMPS', 540, 135);

  ctx.fillStyle = '#1b2b23';
  ctx.font = 'bold 16px monospace';
  ctx.fillText('UB572824', 132, 155);

  ctx.font = 'bold 15px sans-serif';
  ctx.fillText(lang === 'bn' ? '১২ অক্টো ২০২৬' : '12 OCT 2026', 360, 155);

  ctx.font = 'bold 18px sans-serif';
  ctx.fillText(String(totalStampsCount), 540, 155);

  // Official Circular Stamp (Right)
  ctx.save();
  ctx.translate(width - 85, 110);
  ctx.strokeStyle = '#1b4e39';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, 42, 0, Math.PI * 2);
  ctx.stroke();
  ctx.lineWidth = 1;
  ctx.setLineDash([3, 2]);
  ctx.beginPath();
  ctx.arc(0, 0, 38, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.beginPath();
  ctx.arc(0, 0, 26, 0, Math.PI * 2);
  ctx.stroke();
  ctx.fillStyle = '#1b4e39';
  ctx.font = 'bold 7px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('TRAVEL PASSPORT', 0, -12);
  ctx.font = 'bold 6px sans-serif';
  ctx.fillText('★ BANGLADESH ★', 0, 16);
  ctx.fillText('ভ্রমণ পাসপোর্ট', 0, 2);
  ctx.restore();

  // Dotted separator line beneath Identity
  ctx.strokeStyle = '#b6cbbe';
  ctx.lineWidth = 1;
  ctx.setLineDash([4, 4]);
  ctx.beginPath();
  ctx.moveTo(36, 178);
  ctx.lineTo(width - 36, 178);
  ctx.stroke();
  ctx.setLineDash([]);

  // Top Watermark
  drawRosetteWatermark(width / 2, 385);

  // 15 Stamp Slots on Top Page (5 cols x 3 rows)
  const colsX = [125, 312, 500, 688, 875];
  const topRowsY = [245, 375, 505];

  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 5; c++) {
      const idx = r * 5 + c;
      drawStampSlot(topStamps[idx], colsX[c], topRowsY[r]);
    }
  }

  // ==========================================================
  // MIDDLE BOOK SPINE FOLD (Real 3D booklet shadow)
  // ==========================================================
  const foldGrad = ctx.createLinearGradient(0, 580, 0, 608);
  foldGrad.addColorStop(0, 'rgba(0, 0, 0, 0.08)');
  foldGrad.addColorStop(0.5, 'rgba(0, 0, 0, 0.22)');
  foldGrad.addColorStop(1, 'rgba(0, 0, 0, 0.05)');
  ctx.fillStyle = foldGrad;
  ctx.fillRect(16, 580, width - 32, 28);
  ctx.strokeStyle = '#d3ccbc';
  ctx.lineWidth = 1;
  ctx.strokeRect(16, 580, width - 32, 28);

  // ==========================================================
  // BOTTOM PAGE (ভিসা • VISAS)
  // ==========================================================
  ctx.fillStyle = '#23533e';
  ctx.font = 'bold 13px sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText('ভিসা • VISAS', 36, 638);
  ctx.textAlign = 'right';
  ctx.fillText('BANGLADESH', width - 36, 638);

  ctx.strokeStyle = '#bccdc1';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(36, 648);
  ctx.lineTo(width - 36, 648);
  ctx.stroke();

  // Bottom Watermark
  drawRosetteWatermark(width / 2, 855);

  // 15 Stamp Slots on Bottom Page (5 cols x 3 rows)
  const botRowsY = [715, 845, 975];

  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 5; c++) {
      const idx = r * 5 + c;
      drawStampSlot(bottomStamps[idx], colsX[c], botRowsY[r]);
    }
  }

  // ==========================================================
  // MACHINE READABLE ZONE (MRZ) AT BOTTOM
  // ==========================================================
  ctx.strokeStyle = '#c6d7cc';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(36, 1100);
  ctx.lineTo(width - 36, 1100);
  ctx.stroke();

  const cleanName = (travelerName.trim() || 'TRAVELLER')
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '<');
  const mrzLine1 = `P<BGD<TRAVEL<PASSPORT<<${cleanName}`.padEnd(44, '<').slice(0, 44);
  const stampsCountStr = String(totalStampsCount).padStart(3, '0');
  const mrzLine2 = `UB572824<<BD<<STAMPS<${stampsCountStr}<<TRAVEL<PASSPORT<<<`.padEnd(44, '<').slice(0, 44);

  ctx.fillStyle = '#2a3c32';
  ctx.font = 'bold 16px monospace';
  ctx.textAlign = 'left';
  ctx.fillText(mrzLine1, 36, 1130);
  ctx.fillText(mrzLine2, 36, 1158);

  return canvas;
}

export const TravelPassportBook: React.FC<TravelPassportBookProps> = ({
  lang,
}) => {
  // Traveler name
  const [travelerName, setTravelerName] = useState<string>('');

  // Search keyword for destinations list
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Notification when page fills up and auto-flips
  const [pageFlipNotice, setPageFlipNotice] = useState<string | null>(null);

  // Download states and success toast
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Selected place IDs set
  const [selectedPlaceIds, setSelectedPlaceIds] = useState<Set<string>>(() => {
    return new Set(['coxs-bazar', 'saint-martin', 'sajek-valley', 'ratargul', 'jaflong']);
  });

  // Multi-page spread index: Each open booklet spread holds 30 stamps (15 on top page, 15 on bottom page)
  const [currentPage, setCurrentPage] = useState<number>(0);
  const passportBookRef = useRef<HTMLDivElement>(null);

  const STAMPS_PER_SPREAD = 30;

  // Filtered destinations list
  const filteredDestinations = useMemo(() => {
    if (!searchQuery.trim()) return BANGLADESH_130_DESTINATIONS;
    const q = searchQuery.toLowerCase().trim();
    return BANGLADESH_130_DESTINATIONS.filter(
      (d) =>
        d.nameBn.toLowerCase().includes(q) ||
        d.nameEn.toLowerCase().includes(q) ||
        d.districtBn.toLowerCase().includes(q) ||
        d.districtEn.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  // Selected places array ordered by selection
  const selectedPlacesList = useMemo(() => {
    return BANGLADESH_130_DESTINATIONS.filter((d) => selectedPlaceIds.has(d.id));
  }, [selectedPlaceIds]);

  // Total spreads needed (minimum 1)
  const totalPages = Math.max(1, Math.ceil(selectedPlacesList.length / STAMPS_PER_SPREAD));

  // Current spread's stamps: 15 on top page, 15 on bottom page
  const topPageStamps = useMemo(() => {
    const startIdx = currentPage * STAMPS_PER_SPREAD;
    return selectedPlacesList.slice(startIdx, startIdx + 15);
  }, [selectedPlacesList, currentPage]);

  const bottomPageStamps = useMemo(() => {
    const startIdx = currentPage * STAMPS_PER_SPREAD + 15;
    return selectedPlacesList.slice(startIdx, startIdx + 15);
  }, [selectedPlacesList, currentPage]);

  // Is current spread full (30 stamps)?
  const isCurrentPageFull = (topPageStamps.length + bottomPageStamps.length) >= STAMPS_PER_SPREAD;

  // Issued date matching photo
  const issuedDate = lang === 'bn' ? '১২ অক্টো ২০২৬' : '12 OCT 2026';

  // MRZ code lines computed dynamically
  const mrzCleanName = useMemo(() => {
    return (travelerName.trim() || 'TRAVELLER')
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, '<');
  }, [travelerName]);

  const mrzLine1 = useMemo(() => {
    return `P<BGD<TRAVEL<PASSPORT<<${mrzCleanName}`.padEnd(44, '<').slice(0, 44);
  }, [mrzCleanName]);

  const mrzLine2 = useMemo(() => {
    const stampsCountStr = String(selectedPlacesList.length).padStart(3, '0');
    return `UB572824<<BD<<STAMPS<${stampsCountStr}<<TRAVEL<PASSPORT<<<`.padEnd(44, '<').slice(0, 44);
  }, [selectedPlacesList.length]);

  // Toggle single place
  const handleTogglePlace = (placeId: string) => {
    setSelectedPlaceIds((prev) => {
      const next = new Set(prev);
      if (next.has(placeId)) {
        next.delete(placeId);
      } else {
        next.add(placeId);
        // Check if current spread is already full or new count overflows
        const newCount = next.size;
        const targetPage = Math.floor((newCount - 1) / STAMPS_PER_SPREAD);
        if (targetPage > currentPage) {
          setCurrentPage(targetPage);
          setPageFlipNotice(
            lang === 'bn'
              ? `📄 স্প্রেড ${currentPage + 1} পূর্ণ হয়েছে! স্প্রেড ${targetPage + 1}-এ নতুন সিল যোগ করা হয়েছে।`
              : `📄 Spread ${currentPage + 1} full! New seal added to Spread ${targetPage + 1}.`
          );
          setTimeout(() => setPageFlipNotice(null), 4000);
        }
      }
      return next;
    });
  };

  // Select all 130 places
  const handleSelectAll = () => {
    const all = new Set(BANGLADESH_130_DESTINATIONS.map((d) => d.id));
    setSelectedPlaceIds(all);
    setCurrentPage(0);
    confetti({ particleCount: 70, spread: 80, origin: { y: 0.6 } });
  };

  // Clear all
  const handleClearAll = () => {
    setSelectedPlaceIds(new Set());
    setCurrentPage(0);
    setPageFlipNotice(null);
  };

  // Helper to trigger file download from Data URL
  const triggerDownload = (dataUrl: string, filename: string) => {
    const link = document.createElement('a');
    link.download = filename;
    link.href = dataUrl;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Download passport action (current page spread)
  const handleDownload = async () => {
    if (isDownloading) return;
    setIsDownloading(true);
    setDownloadSuccess(false);

    try {
      let dataUrl: string | null = null;

      // 1. Attempt high-fidelity DOM snapshot with html-to-image
      if (passportBookRef.current) {
        try {
          dataUrl = await toPng(passportBookRef.current, {
            cacheBust: true,
            pixelRatio: 2,
            quality: 0.98,
            skipFonts: true,
            backgroundColor: '#f3eee4',
            filter: (node) => {
              const el = node as HTMLElement;
              // Don't include pagination control buttons in exported passport image
              if (el?.classList?.contains('passport-nav-controls')) {
                return false;
              }
              return true;
            },
          });
        } catch (domErr) {
          console.warn('html-to-image capture fallback to canvas generator:', domErr);
        }
      }

      // 2. Direct Canvas fallback if html-to-image was unavailable or failed
      if (!dataUrl) {
        const canvas = renderPassportPageToCanvas(
          travelerName,
          currentPage,
          totalPages,
          topPageStamps,
          bottomPageStamps,
          selectedPlacesList.length,
          lang
        );
        dataUrl = canvas.toDataURL('image/png', 0.98);
      }

      const safeName = travelerName.trim()
        ? travelerName.trim().replace(/[^a-zA-Z0-9_\-\u0980-\u09FF]/g, '_')
        : (lang === 'bn' ? 'ভ্রমণকারী' : 'traveler');
      const filename = `bangladesh-travel-passport-${safeName}-spread-${currentPage + 1}.png`;

      triggerDownload(dataUrl, filename);

      confetti({ particleCount: 90, spread: 80, origin: { y: 0.6 } });
      setDownloadSuccess(true);
      setSuccessToast(
        lang === 'bn'
          ? `🎉 আপনার পাসপোর্ট বুকলেট (স্প্রেড ${currentPage + 1}) ডাউনলোড সম্পন্ন হয়েছে!`
          : `🎉 Passport Booklet (Spread ${currentPage + 1}) downloaded successfully!`
      );

      setTimeout(() => {
        setDownloadSuccess(false);
        setSuccessToast(null);
      }, 4500);
    } catch (err) {
      console.error('Passport download error:', err);
    } finally {
      setIsDownloading(false);
    }
  };

  // Download all pages if multiple pages exist
  const handleDownloadAllPages = async () => {
    if (isDownloading) return;
    setIsDownloading(true);
    setDownloadSuccess(false);

    try {
      for (let pIdx = 0; pIdx < totalPages; pIdx++) {
        const topStamps = selectedPlacesList.slice(
          pIdx * STAMPS_PER_SPREAD,
          pIdx * STAMPS_PER_SPREAD + 15
        );
        const botStamps = selectedPlacesList.slice(
          pIdx * STAMPS_PER_SPREAD + 15,
          pIdx * STAMPS_PER_SPREAD + 30
        );
        const canvas = renderPassportPageToCanvas(
          travelerName,
          pIdx,
          totalPages,
          topStamps,
          botStamps,
          selectedPlacesList.length,
          lang
        );
        const dataUrl = canvas.toDataURL('image/png', 0.98);
        const safeName = travelerName.trim()
          ? travelerName.trim().replace(/[^a-zA-Z0-9_\-\u0980-\u09FF]/g, '_')
          : (lang === 'bn' ? 'ভ্রমণকারী' : 'traveler');
        const filename = `bangladesh-travel-passport-${safeName}-spread-${pIdx + 1}.png`;

        triggerDownload(dataUrl, filename);
        // Small delay to ensure sequential browser downloads
        await new Promise((resolve) => setTimeout(resolve, 350));
      }

      confetti({ particleCount: 120, spread: 90, origin: { y: 0.6 } });
      setDownloadSuccess(true);
      setSuccessToast(
        lang === 'bn'
          ? `🎉 সবগুলো স্প্রেড (${totalPages}টি বুকলেট পাতা) সফলভাবে ডাউনলোড হয়েছে!`
          : `🎉 All ${totalPages} spreads downloaded successfully!`
      );

      setTimeout(() => {
        setDownloadSuccess(false);
        setSuccessToast(null);
      }, 5000);
    } catch (err) {
      console.error('All pages download error:', err);
    } finally {
      setIsDownloading(false);
    }
  };

  // Color styles mapping for stamps
  const getStampColor = (color?: DestinationItem['color']) => {
    switch (color) {
      case 'crimson':
        return { text: '#be123c', border: '#be123c', bg: '#fff1f2' };
      case 'navy':
        return { text: '#1d4ed8', border: '#1d4ed8', bg: '#eff6ff' };
      case 'purple':
        return { text: '#7e22ce', border: '#7e22ce', bg: '#faf5ff' };
      case 'amber':
        return { text: '#b45309', border: '#b45309', bg: '#fffbeb' };
      case 'emerald':
      default:
        return { text: '#005a3c', border: '#005a3c', bg: '#ecfdf5' };
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn max-w-6xl mx-auto">
      {/* ============================================================== */}
      {/* 1. HERO HEADER (Exact same typography & pills as in photo) */}
      {/* ============================================================== */}
      <div className="text-center pt-2 pb-2">
        {/* Top Tag Pill */}
        <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#e8f5e9] text-[#006042] border border-[#c8e6c9] text-xs font-bold mb-3 shadow-2xs">
          <span>{lang === 'bn' ? '১৩০ গন্তব্য • সিল সংগ্রহ করুন' : '130 Destinations • Collect Stamps'}</span>
        </div>

        {/* Main Title: "আপনার ভ্রমণ " (Black) + "পাসপোর্ট" (Red/Coral) */}
        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-tight">
          <span className="text-[#17201c]">{lang === 'bn' ? 'আপনার ভ্রমণ ' : 'Your Travel '}</span>
          <span className="text-[#e11d48]">{lang === 'bn' ? 'পাসপোর্ট' : 'Passport'}</span>
        </h1>

        {/* Subtitle */}
        <p className="text-slate-600 text-xs sm:text-sm max-w-xl mx-auto mt-3 leading-relaxed">
          {lang === 'bn'
            ? 'যেসব জায়গায় গিয়েছেন সেগুলো বেছে নিন। প্রতিটি জায়গার নিজস্ব সিল বসবে আপনার পাসপোর্টে। নাম লিখুন আর ডাউনলোড করুন।'
            : 'Select the places you have explored. Each place receives its own unique rubber seal on your passport. Add your name and download.'}
        </p>

        {/* Download Count Badge */}
        <div className="mt-3 flex justify-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-slate-200 shadow-2xs text-xs font-bold text-slate-700">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>{lang === 'bn' ? '৭,৯১৪ টি পাসপোর্ট ডাউনলোড হয়েছে' : '7,914 Passports Downloaded'}</span>
          </div>
        </div>
      </div>

      {/* Download Success Notification Toast */}
      {successToast && (
        <div className="bg-emerald-700 text-white px-4 py-3 rounded-xl shadow-lg text-xs sm:text-sm font-bold flex items-center justify-between animate-fadeIn border border-emerald-500">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-200 shrink-0" />
            <span>{successToast}</span>
          </div>
          <button
            onClick={() => setSuccessToast(null)}
            className="text-white/80 hover:text-white cursor-pointer text-sm font-black px-2 py-0.5 rounded hover:bg-emerald-800"
          >
            ✕
          </button>
        </div>
      )}

      {/* Auto-flip full page notification */}
      {pageFlipNotice && (
        <div className="bg-[#005a3c] text-white px-4 py-2.5 rounded-xl shadow-md text-xs font-bold flex items-center justify-between animate-bounce">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>{pageFlipNotice}</span>
          </div>
          <button
            onClick={() => setPageFlipNotice(null)}
            className="text-white/80 hover:text-white cursor-pointer text-sm font-black px-1.5"
          >
            ✕
          </button>
        </div>
      )}

      {/* ============================================================== */}
      {/* 2. MAIN 2-COLUMN SECTION: LEFT PASSPORT PREVIEW | RIGHT PLACES */}
      {/* ============================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* ============================================================== */}
        {/* LEFT COLUMN: PASSPORT PREVIEW & CONTROLS (6 COLS) */}
        {/* ============================================================== */}
        <div className="lg:col-span-6 space-y-4">
          {/* Traveler Name Input */}
          <div className="bg-white border border-[#ded8cb] p-3 rounded-2xl shadow-2xs">
            <label className="block text-xs font-bold text-slate-800 mb-1">
              {lang === 'bn' ? 'আপনার নাম (পাসপোর্টের জন্য):' : 'Your Name (For Passport):'}
            </label>
            <input
              type="text"
              value={travelerName}
              onChange={(e) => setTravelerName(e.target.value)}
              placeholder={lang === 'bn' ? 'নাম লিখুন (যেমন: মহিউদ্দিন আহমেদ নাফিস)' : 'Enter name (e.g. Muhiuddin Ahmed Nafis)'}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#005a3c] focus:bg-white"
            />
          </div>

          {/* ============================================================== */}
          {/* THE AUTHENTIC OPEN PASSPORT BOOKLET PREVIEW */}
          {/* Exact Replica of User's Image (Top Page, Fold, Bottom Page, MRZ) */}
          {/* ============================================================== */}
          <div
            ref={passportBookRef}
            className="rounded-2xl border border-[#c4d6cb] overflow-hidden shadow-2xl bg-[#f3eee4] select-none transition-all flex relative"
          >
            {/* Left Dark Forest Green Binding Bar with inner pinstripe */}
            <div className="w-2.5 sm:w-3.5 bg-[#083827] border-r border-[#0d5038] shrink-0 relative flex flex-col justify-between py-6">
              <div className="w-0.5 h-full bg-[#165a3f]/40 mx-auto" />
            </div>

            {/* Main Passport Booklet Paper Body */}
            <div className="flex-1 flex flex-col relative overflow-hidden bg-[#f3eee4] p-3 sm:p-5">
              {/* Background Banknote Guilloche Wavy Sine Curves */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-20" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  <pattern id="guillocheWaves" width="240" height="40" patternUnits="userSpaceOnUse">
                    <path d="M 0 10 Q 60 0 120 10 T 240 10" fill="none" stroke="#1f543e" strokeWidth="0.6" />
                    <path d="M 0 20 Q 60 10 120 20 T 240 20" fill="none" stroke="#1f543e" strokeWidth="0.6" />
                    <path d="M 0 30 Q 60 20 120 30 T 240 30" fill="none" stroke="#1f543e" strokeWidth="0.6" />
                    <path d="M 0 40 Q 60 30 120 40 T 240 40" fill="none" stroke="#1f543e" strokeWidth="0.6" />
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#guillocheWaves)" />
              </svg>

              {/* ========================================================== */}
              {/* 1. TOP PAGE (ভ্রমণ পাসপোর্ট • TRAVEL PASSPORT) */}
              {/* ========================================================== */}
              <div className="flex-1 flex flex-col relative">
                {/* Top Header Bar */}
                <div className="flex items-center justify-between text-[10px] sm:text-[11px] font-black text-[#23533e] tracking-widest uppercase pb-1.5 border-b border-[#bccdc1]">
                  <span>ভ্রমণ পাসপোর্ট • TRAVEL PASSPORT</span>
                  <span>BANGLADESH</span>
                </div>

                {/* Identity Data Row */}
                <div className="mt-3 flex items-center justify-between gap-2 sm:gap-4">
                  {/* Left: Photo Box with Silhouette of Bangladesh Map */}
                  <div className="w-16 h-20 sm:w-20 sm:h-24 rounded-xl border-[1.5px] border-[#23533e]/60 bg-white/80 p-1.5 flex flex-col items-center justify-center shrink-0 shadow-2xs">
                    <svg viewBox={`0 0 ${mapData.w} ${mapData.h}`} className="w-full h-full drop-shadow-2xs">
                      {(mapData.f as any[]).map((feature) => (
                        <path
                          key={feature.n}
                          d={feature.d}
                          fill="#0d5c3a"
                          stroke="#ffffff"
                          strokeWidth="1.2"
                          strokeLinejoin="round"
                        />
                      ))}
                    </svg>
                  </div>

                  {/* Center: Traveler Details */}
                  <div className="flex-1 space-y-1">
                    <div>
                      <span className="text-[9px] sm:text-[10px] font-bold text-[#6c8275] uppercase block leading-none">
                        নাম / NAME
                      </span>
                      <div className="text-base sm:text-2xl font-black text-[#22332a] truncate mt-0.5">
                        {travelerName.trim() || (lang === 'bn' ? 'আপনার নাম' : 'YOUR NAME')}
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 pt-1 text-slate-800">
                      <div>
                        <span className="text-[8px] sm:text-[9px] font-bold text-[#6c8275] uppercase block leading-tight">
                          পাসপোর্ট নং / PASSPORT NO.
                        </span>
                        <span className="font-mono font-bold text-xs sm:text-sm text-[#1b2b23]">UB572824</span>
                      </div>
                      <div>
                        <span className="text-[8px] sm:text-[9px] font-bold text-[#6c8275] uppercase block leading-tight">
                          ইস্যু / ISSUED
                        </span>
                        <span className="font-bold text-xs sm:text-sm text-[#1b2b23]">{issuedDate}</span>
                      </div>
                      <div>
                        <span className="text-[8px] sm:text-[9px] font-bold text-[#6c8275] uppercase block leading-tight">
                          সিল / STAMPS
                        </span>
                        <span className="font-black text-xs sm:text-sm text-[#1b2b23]">{selectedPlacesList.length}</span>
                      </div>
                    </div>
                  </div>

                  {/* Right: Circular Official Rubber Seal Stamp */}
                  <div className="shrink-0 flex items-center justify-center">
                    <svg viewBox="0 0 100 100" className="w-16 h-16 sm:w-20 sm:h-20 text-[#1b4e39]">
                      <circle cx="50" cy="50" r="46" fill="none" stroke="currentColor" strokeWidth="2" />
                      <circle cx="50" cy="50" r="42" fill="none" stroke="currentColor" strokeWidth="1" strokeDasharray="3,2" />
                      <circle cx="50" cy="50" r="28" fill="none" stroke="currentColor" strokeWidth="1" />
                      <path id="sealTopArc" d="M 16 50 A 34 34 0 0 1 84 50" fill="none" />
                      <path id="sealBottomArc" d="M 84 50 A 34 34 0 0 1 16 50" fill="none" />
                      <text fontSize="7.2" fontWeight="bold" fill="currentColor" letterSpacing="1.2">
                        <textPath href="#sealTopArc" startOffset="50%" textAnchor="middle">
                          TRAVEL PASSPORT
                        </textPath>
                      </text>
                      <text fontSize="6" fontWeight="bold" fill="currentColor" letterSpacing="1">
                        <textPath href="#sealBottomArc" startOffset="50%" textAnchor="middle">
                          ★ BANGLADESH ★
                        </textPath>
                      </text>
                      <g transform="translate(39, 36) scale(0.04)">
                        {(mapData.f as any[]).map((feature) => (
                          <path key={feature.n} d={feature.d} fill="currentColor" />
                        ))}
                      </g>
                      <text x="50" y="63" fontSize="4.5" fontWeight="bold" fill="currentColor" textAnchor="middle">
                        ভ্রমণ পাসপোর্ট
                      </text>
                    </svg>
                  </div>
                </div>

                {/* Dotted horizontal separator line */}
                <div className="my-2.5 border-b border-dashed border-[#b6cbbe]" />

                {/* Top Page 15 Stamp Slots (5 columns x 3 rows) */}
                <div className="relative py-2 flex-1 flex flex-col justify-around min-h-[220px]">
                  {/* Central Rosette and Map Watermark */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.09]">
                    <svg viewBox="0 0 200 200" className="w-44 h-44 sm:w-56 sm:h-56 text-[#1b4332]">
                      {Array.from({ length: 16 }).map((_, rIdx) => (
                        <ellipse
                          key={rIdx}
                          cx="100"
                          cy="100"
                          rx="85"
                          ry="45"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="0.8"
                          transform={`rotate(${rIdx * 11.25} 100 100)`}
                        />
                      ))}
                      <circle cx="100" cy="100" r="35" fill="none" stroke="currentColor" strokeWidth="1" strokeDasharray="3,3" />
                    </svg>
                    <div className="absolute w-32 h-32">
                      <svg viewBox={`0 0 ${mapData.w} ${mapData.h}`} className="w-full h-full">
                        {(mapData.f as any[]).map((f) => (
                          <path key={f.n} d={f.d} fill="#1b4332" />
                        ))}
                      </svg>
                    </div>
                  </div>

                  {/* 3 rows of 5 circular slots */}
                  <div className="grid grid-cols-5 gap-2 sm:gap-2.5 justify-items-center relative z-1">
                    {Array.from({ length: 15 }).map((_, idx) => {
                      const stamp = topPageStamps[idx];
                      if (stamp) {
                        const style = getStampColor(stamp.color);
                        return (
                          <div
                            key={stamp.id}
                            style={{
                              borderColor: style.border,
                              color: style.text,
                              backgroundColor: style.bg,
                            }}
                            className="w-11 h-11 sm:w-15 sm:h-15 rounded-full border-2 border-dashed flex flex-col items-center justify-center p-0.5 sm:p-1 text-center shadow-xs transition-transform hover:scale-105 cursor-pointer"
                            title={`${stamp.nameBn} (${stamp.districtBn})`}
                          >
                            <span className="text-[5.5px] sm:text-[6.5px] font-bold uppercase leading-none opacity-80">★ ENTRY ★</span>
                            <span className="text-[7.5px] sm:text-[9px] font-black uppercase leading-tight line-clamp-1 px-0.5">
                              {stamp.nameBn}
                            </span>
                            <span className="text-[5.5px] sm:text-[6.5px] font-bold uppercase leading-none opacity-80">
                              {stamp.districtBn}
                            </span>
                          </div>
                        );
                      }
                      return (
                        <div
                          key={`empty-top-${idx}`}
                          className="w-11 h-11 sm:w-15 sm:h-15 rounded-full border-2 border-dashed border-[#97bba5]/80 bg-transparent flex items-center justify-center"
                        />
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* ========================================================== */}
              {/* 2. MIDDLE BOOK SPINE FOLD (Real 3D booklet shadow) */}
              {/* ========================================================== */}
              <div className="my-2.5 h-4 sm:h-5 bg-gradient-to-b from-black/[0.08] via-black/[0.2] to-black/[0.05] border-y border-[#d3ccbc] -mx-3 sm:-mx-5 shadow-inner" />

              {/* ========================================================== */}
              {/* 3. BOTTOM PAGE (ভিসা • VISAS) */}
              {/* ========================================================== */}
              <div className="flex-1 flex flex-col relative">
                {/* Bottom Header Bar */}
                <div className="flex items-center justify-between text-[10px] sm:text-[11px] font-black text-[#23533e] tracking-widest uppercase pb-1.5 border-b border-[#bccdc1]">
                  <span>ভিসা • VISAS</span>
                  <span>BANGLADESH</span>
                </div>

                {/* Bottom Page 15 Stamp Slots (5 columns x 3 rows) */}
                <div className="relative py-2 flex-1 flex flex-col justify-around min-h-[220px]">
                  {/* Central Rosette and Map Watermark */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.09]">
                    <svg viewBox="0 0 200 200" className="w-44 h-44 sm:w-56 sm:h-56 text-[#1b4332]">
                      {Array.from({ length: 16 }).map((_, rIdx) => (
                        <ellipse
                          key={rIdx}
                          cx="100"
                          cy="100"
                          rx="85"
                          ry="45"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="0.8"
                          transform={`rotate(${rIdx * 11.25} 100 100)`}
                        />
                      ))}
                      <circle cx="100" cy="100" r="35" fill="none" stroke="currentColor" strokeWidth="1" strokeDasharray="3,3" />
                    </svg>
                    <div className="absolute w-32 h-32">
                      <svg viewBox={`0 0 ${mapData.w} ${mapData.h}`} className="w-full h-full">
                        {(mapData.f as any[]).map((f) => (
                          <path key={f.n} d={f.d} fill="#1b4332" />
                        ))}
                      </svg>
                    </div>
                  </div>

                  {/* 3 rows of 5 circular slots */}
                  <div className="grid grid-cols-5 gap-2 sm:gap-2.5 justify-items-center relative z-1">
                    {Array.from({ length: 15 }).map((_, idx) => {
                      const stamp = bottomPageStamps[idx];
                      if (stamp) {
                        const style = getStampColor(stamp.color);
                        return (
                          <div
                            key={stamp.id}
                            style={{
                              borderColor: style.border,
                              color: style.text,
                              backgroundColor: style.bg,
                            }}
                            className="w-11 h-11 sm:w-15 sm:h-15 rounded-full border-2 border-dashed flex flex-col items-center justify-center p-0.5 sm:p-1 text-center shadow-xs transition-transform hover:scale-105 cursor-pointer"
                            title={`${stamp.nameBn} (${stamp.districtBn})`}
                          >
                            <span className="text-[5.5px] sm:text-[6.5px] font-bold uppercase leading-none opacity-80">★ ENTRY ★</span>
                            <span className="text-[7.5px] sm:text-[9px] font-black uppercase leading-tight line-clamp-1 px-0.5">
                              {stamp.nameBn}
                            </span>
                            <span className="text-[5.5px] sm:text-[6.5px] font-bold uppercase leading-none opacity-80">
                              {stamp.districtBn}
                            </span>
                          </div>
                        );
                      }
                      return (
                        <div
                          key={`empty-bottom-${idx}`}
                          className="w-11 h-11 sm:w-15 sm:h-15 rounded-full border-2 border-dashed border-[#97bba5]/80 bg-transparent flex items-center justify-center"
                        />
                      );
                    })}
                  </div>
                </div>

                {/* Machine Readable Zone (MRZ) at Bottom of Passport */}
                <div className="mt-3 pt-2.5 border-t border-[#c6d7cc] font-mono text-[9px] sm:text-[11px] font-bold text-[#2a3c32] tracking-wider sm:tracking-widest leading-relaxed select-all">
                  <div className="truncate">{mrzLine1}</div>
                  <div className="truncate">{mrzLine2}</div>
                </div>
              </div>
            </div>

            {/* Right Dark Forest Green Binding Bar with inner pinstripe */}
            <div className="w-2.5 sm:w-3.5 bg-[#083827] border-l border-[#0d5038] shrink-0 relative flex flex-col justify-between py-6">
              <div className="w-0.5 h-full bg-[#165a3f]/40 mx-auto" />
            </div>
          </div>

          {/* Multi-Page Navigation Bar Below Passport */}
          <div className="passport-nav-controls bg-white border border-[#ebe6dc] p-2.5 rounded-xl shadow-2xs flex items-center justify-between text-xs flex-wrap gap-2">
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-bold text-slate-700">
                {lang === 'bn'
                  ? `বুকলেট স্প্রেড ${currentPage + 1} / ${totalPages} (${topPageStamps.length + bottomPageStamps.length}/৩০টি সিল)`
                  : `Booklet Spread ${currentPage + 1} of ${totalPages} (${topPageStamps.length + bottomPageStamps.length}/30 stamps)`}
              </span>
              {/* Spread Jump Dots/Pills */}
              <div className="flex items-center gap-1 ml-1">
                {Array.from({ length: totalPages }).map((_, pIdx) => (
                  <button
                    key={pIdx}
                    onClick={() => setCurrentPage(pIdx)}
                    className={`w-5 h-5 rounded-full text-[10px] font-bold flex items-center justify-center cursor-pointer transition-all ${
                      currentPage === pIdx
                        ? 'bg-[#005a3c] text-white shadow-2xs'
                        : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                    title={`Go to spread ${pIdx + 1}`}
                  >
                    {pIdx + 1}
                  </button>
                ))}
              </div>
            </div>

            {/* Page Flip Buttons */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setCurrentPage((p) => Math.max(0, p - 1))}
                disabled={currentPage === 0}
                className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 disabled:opacity-40 text-xs font-bold transition-all hover:bg-slate-50 cursor-pointer flex items-center gap-1"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                <span>{lang === 'bn' ? 'পূর্ববর্তী স্প্রেড' : 'Prev Spread'}</span>
              </button>
              <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages - 1, p + 1))}
                disabled={currentPage >= totalPages - 1}
                className="px-2.5 py-1 rounded-lg bg-[#005a3c] text-white disabled:opacity-40 text-xs font-bold transition-all hover:bg-[#004730] cursor-pointer flex items-center gap-1 shadow-2xs"
              >
                <span>{lang === 'bn' ? 'পরবর্তী স্প্রেড' : 'Next Spread'}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Action Buttons for Passport Download */}
          <div className="space-y-2">
            {/* Primary Download Button (Current Page) */}
            <button
              onClick={handleDownload}
              disabled={isDownloading}
              className="w-full bg-[#005a3c] hover:bg-[#004730] disabled:bg-[#005a3c]/70 text-white font-black text-sm py-3.5 px-6 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99]"
            >
              {isDownloading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{lang === 'bn' ? 'পাসপোর্ট প্রস্তুত হচ্ছে...' : 'Generating Passport...'}</span>
                </>
              ) : downloadSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                  <span>{lang === 'bn' ? 'ডাউনলোড সফল হয়েছে!' : 'Download Complete!'}</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>
                    {lang === 'bn'
                      ? totalPages > 1
                        ? `পাসপোর্ট পেজ ${currentPage + 1} ডাউনলোড করুন (PNG)`
                        : 'পাসপোর্ট ডাউনলোড করুন (PNG)'
                      : totalPages > 1
                      ? `Download Passport Page ${currentPage + 1} (PNG)`
                      : 'Download Passport (PNG)'}
                  </span>
                </>
              )}
            </button>

            {/* Optional All Pages Download Button if more than 1 page exists */}
            {totalPages > 1 && (
              <button
                onClick={handleDownloadAllPages}
                disabled={isDownloading}
                className="w-full bg-white hover:bg-slate-50 border border-[#005a3c] text-[#005a3c] font-bold text-xs py-2.5 px-4 rounded-xl shadow-2xs transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Book className="w-3.5 h-3.5" />
                <span>
                  {lang === 'bn'
                    ? `সবগুলো পেজ একবারে ডাউনলোড করুন (${totalPages}টি পেজ)`
                    : `Download All ${totalPages} Pages in One Click`}
                </span>
              </button>
            )}
          </div>
        </div>

        {/* ============================================================== */}
        {/* RIGHT COLUMN: PLACES LIST (যেসব জায়গায় গিয়েছি) (6 COLS) */}
        {/* ============================================================== */}
        <div className="lg:col-span-6 bg-white border border-[#ebe6dc] rounded-2xl p-5 shadow-xs">
          {/* Header Row: [যেসব জায়গায় গিয়েছি] ... [সব বাছাই করুন] [সব মুছুন] [০/১৩০] */}
          <div className="flex items-center justify-between gap-3 mb-2">
            <div className="flex items-center gap-2">
              <h3 className="text-base font-extrabold text-slate-900">
                {lang === 'bn' ? 'যেসব জায়গায় গিয়েছি' : 'Places I Have Visited'}
              </h3>
            </div>

            {/* Counter Badge */}
            <div className="bg-[#e8f5e9] text-[#005a3c] font-black text-xs px-2.5 py-1 rounded-full border border-[#c8e6c9]">
              {selectedPlaceIds.size}/{BANGLADESH_130_DESTINATIONS.length}
            </div>
          </div>

          {/* Action Links: Select All / Clear All */}
          <div className="flex justify-end gap-3 text-xs mb-3 text-slate-500 font-semibold">
            <button
              onClick={handleSelectAll}
              className="hover:text-[#005a3c] hover:underline cursor-pointer"
            >
              {lang === 'bn' ? 'সব বাছাই করুন' : 'Select All'}
            </button>
            <span>•</span>
            <button
              onClick={handleClearAll}
              className="hover:text-rose-600 hover:underline cursor-pointer"
            >
              {lang === 'bn' ? 'সব মুছুন' : 'Clear All'}
            </button>
          </div>

          {/* Search Input Box */}
          <div className="relative mb-2">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={lang === 'bn' ? 'জায়গা খুঁজুন: গুলিয়াখালী, Lalakhal...' : 'Search place: Guliakhali, Lalakhal...'}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9.5 pr-4 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#005a3c] focus:bg-white"
            />
          </div>

          {/* Subtitle helper */}
          <p className="text-[11px] text-slate-500 mb-3">
            {lang === 'bn'
              ? '১৩০টি জায়গা, জনপ্রিয়গুলো আগে। নিচে স্ক্রল করুন বা নাম লিখে খুঁজুন।'
              : '130 destinations, top popular spots first. Scroll down or search by name.'}
          </p>

          {/* Scrollable 2-Column Grid of 130 Places (Identical to Screenshot 2) */}
          <div className="grid grid-cols-2 gap-2 max-h-[500px] overflow-y-auto pr-1">
            {filteredDestinations.map((dest) => {
              const isChecked = selectedPlaceIds.has(dest.id);
              return (
                <div
                  key={dest.id}
                  onClick={() => handleTogglePlace(dest.id)}
                  className={`p-2.5 rounded-xl border flex items-center gap-2.5 transition-all cursor-pointer ${
                    isChecked
                      ? 'bg-emerald-50/50 border-[#005a3c]'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  {/* Circular Checkbox/Radio Indicator */}
                  <div
                    className={`w-4 h-4 rounded-full border-2 flex items-center justify-center shrink-0 transition-all ${
                      isChecked
                        ? 'bg-[#005a3c] border-[#005a3c] text-white'
                        : 'border-slate-300 bg-white'
                    }`}
                  >
                    {isChecked && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                  </div>

                  {/* Destination Info */}
                  <div className="truncate">
                    <div className="text-xs font-bold text-slate-900 truncate">
                      {dest.nameBn}
                    </div>
                    <div className="text-[10px] text-slate-400 font-medium truncate">
                      {dest.districtBn}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
