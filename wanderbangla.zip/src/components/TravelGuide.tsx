import React, { useState } from 'react';
import { DISTRICTS, DIVISIONS, District } from '../data/bangladeshData';
import { Search, MapPin, Utensils, Calendar, Check, ExternalLink } from 'lucide-react';

interface TravelGuideProps {
  selectedDistricts: Set<string>;
  onToggleDistrict: (districtId: string) => void;
  lang: 'bn' | 'en';
}

export const TravelGuide: React.FC<TravelGuideProps> = ({
  selectedDistricts,
  onToggleDistrict,
  lang,
}) => {
  const [selectedDivision, setSelectedDivision] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const divisionsList = Object.keys(DIVISIONS);

  const filteredDistricts = DISTRICTS.filter((d) => {
    const matchesDiv = selectedDivision === 'all' || d.divisionBn === selectedDivision;
    const query = searchQuery.trim().toLowerCase();
    const matchesQuery =
      !query ||
      d.nameBn.toLowerCase().includes(query) ||
      d.nameEn.toLowerCase().includes(query) ||
      d.famousForBn.toLowerCase().includes(query) ||
      d.spots.some((s) => s.toLowerCase().includes(query));

    return matchesDiv && matchesQuery;
  });

  return (
    <div className="bg-white border border-[#ebe6dc] rounded-3xl p-6 sm:p-8 shadow-xs">
      <div className="max-w-3xl mb-8">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          {lang === 'bn' ? '৬৪ জেলার সম্পূর্ণ ভ্রমণ গাইড ও দর্শনীয় স্থান' : '64 District Complete Travel Guide'}
        </h2>
        <p className="text-sm sm:text-base text-slate-600 mt-2">
          {lang === 'bn'
            ? 'প্রতিটি জেলার শীর্ষ দর্শনীয় স্থান, বিখ্যাত খাবার ও ভ্রমণের শ্রেষ্ঠ সময় জানুন।'
            : 'Explore top sightseeing attractions, regional signature foods, and best travel seasons across Bangladesh.'}
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 pb-6 border-b border-[#ebe6dc]">
        {/* Division Selector Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
          <button
            onClick={() => setSelectedDivision('all')}
            className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
              selectedDivision === 'all'
                ? 'bg-[#0f6b4f] text-white shadow-xs'
                : 'bg-[#f3efe7] text-slate-600 hover:text-slate-900'
            }`}
          >
            {lang === 'bn' ? 'সব বিভাগ' : 'All Divisions'}
          </button>
          {divisionsList.map((div) => (
            <button
              key={div}
              onClick={() => setSelectedDivision(div)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
                selectedDivision === div
                  ? 'bg-[#0f6b4f] text-white shadow-xs'
                  : 'bg-[#f3efe7] text-slate-600 hover:text-slate-900'
              }`}
            >
              {div} {lang === 'bn' ? 'বিভাগ' : ''}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={lang === 'bn' ? 'জেলা বা দর্শনীয় স্থান খুঁজুন...' : 'Search spot or district...'}
            className="w-full bg-[#faf8f4] border border-[#ebe6dc] rounded-xl pl-9 pr-4 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-[#0f6b4f]"
          />
        </div>
      </div>

      {/* District Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredDistricts.map((district) => {
          const isVisited = selectedDistricts.has(district.id);

          return (
            <div
              key={district.id}
              className={`rounded-2xl border p-5 transition-all duration-200 flex flex-col justify-between ${
                isVisited
                  ? 'border-[#0f6b4f]/40 bg-[#f7fbf9] shadow-xs'
                  : 'border-[#ebe6dc] bg-[#faf8f4] hover:border-slate-300'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <h3 className="text-lg font-bold text-slate-900 flex items-center gap-1.5">
                      <span>{lang === 'bn' ? district.nameBn : district.nameEn}</span>
                      <span className="text-xs font-medium text-slate-500">
                        ({district.divisionBn})
                      </span>
                    </h3>
                  </div>

                  <button
                    onClick={() => onToggleDistrict(district.id)}
                    className={`px-2.5 py-1 rounded-full text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer ${
                      isVisited
                        ? 'bg-[#0f6b4f] text-white'
                        : 'bg-white border border-[#ebe6dc] text-slate-600 hover:border-[#0f6b4f] hover:text-[#0f6b4f]'
                    }`}
                  >
                    {isVisited ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>{lang === 'bn' ? 'ঘুরেছি' : 'Visited'}</span>
                      </>
                    ) : (
                      <span>+ {lang === 'bn' ? 'চিহ্নিত করুন' : 'Mark'}</span>
                    )}
                  </button>
                </div>

                <p className="text-xs text-slate-600 mb-4 line-clamp-2 leading-relaxed">
                  {lang === 'bn' ? district.famousForBn : district.famousForEn}
                </p>

                {/* Sightseeing spots */}
                <div className="mb-3">
                  <div className="flex items-center gap-1 text-[11px] font-bold text-slate-700 mb-1.5">
                    <MapPin className="w-3 h-3 text-[#0f6b4f]" />
                    <span>{lang === 'bn' ? 'দর্শনীয় স্থানসমূহ:' : 'Key Sightseeing Spots:'}</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {district.spots.map((spot, idx) => (
                      <span
                        key={idx}
                        className="text-[11px] bg-white border border-[#ebe6dc] px-2 py-0.5 rounded-md text-slate-700"
                      >
                        {spot}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Famous Foods */}
                <div className="mb-2.5 flex items-start gap-1.5 text-xs text-slate-600">
                  <Utensils className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                  <span>
                    <strong className="text-slate-800">{lang === 'bn' ? 'বিখ্যাত খাবার: ' : 'Famous Food: '}</strong>
                    {district.foodBn}
                  </span>
                </div>

                {/* Best Season */}
                <div className="flex items-center gap-1.5 text-xs text-slate-600">
                  <Calendar className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                  <span>
                    <strong className="text-slate-800">{lang === 'bn' ? 'ভ্রমণের সময়: ' : 'Best Time: '}</strong>
                    {district.bestTimeBn}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
