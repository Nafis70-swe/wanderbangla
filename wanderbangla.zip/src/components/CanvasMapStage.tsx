import React, { useRef, useEffect, useState } from 'react';
import { DISTRICTS, DIVISIONS } from '../data/bangladeshData';
import mapData from '../data/bangladeshMapPaths.json';
import { BangladeshMap } from './BangladeshMap';
import { Download, Share2, Map as MapIcon, Image as ImageIcon, Sparkles, Check } from 'lucide-react';
import confetti from 'canvas-confetti';

interface CanvasMapStageProps {
  selectedDistricts: Set<string>;
  onToggleDistrict: (districtId: string) => void;
  lang: 'bn' | 'en';
}

const THEMES = [
  { id: 'emerald', nameBn: 'ক্লাসিক এমারেল্ড', nameEn: 'Emerald Green', color: '#0f6b4f' },
  { id: 'midnight', nameBn: 'মিডনাইট ব্ল্যাক', nameEn: 'Midnight Black', color: '#17201c' },
  { id: 'crimson', nameBn: 'লাল সূর্য', nameEn: 'Crimson Red', color: '#d9381e' },
  { id: 'ocean', nameBn: 'বঙ্গোপসাগর নীল', nameEn: 'Ocean Azure', color: '#1e40af' },
  { id: 'forest', nameBn: 'সবুজ অরণ্য', nameEn: 'Forest Green', color: '#15803d' },
];

export const CanvasMapStage: React.FC<CanvasMapStageProps> = ({
  selectedDistricts,
  onToggleDistrict,
  lang,
}) => {
  const [currentTheme, setCurrentTheme] = useState<string>('#0f6b4f');
  const [travelerName, setTravelerName] = useState<string>('আমার ভ্রমণ ম্যাপ');
  const [travelMotto, setTravelMotto] = useState<string>('বাংলার পথে পথে অদেখা সুন্দর');
  const [viewMode, setViewMode] = useState<'map' | 'canvas'>('map');
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const visitedCount = selectedDistricts.size;
  const percentage = Math.round((visitedCount / 64) * 100);

  // Re-draw Canvas whenever state changes
  useEffect(() => {
    drawCanvasExport();
  }, [selectedDistricts, currentTheme, travelerName, travelMotto, lang]);

  const getDistrictIdForFeature = (name: string): string => {
    const norm = name.toLowerCase().replace(/[^a-z]/g, '');
    if (norm === 'jhalokati') return 'jhalokathi';
    if (norm === 'chapainawabganj') return 'chapai-nawabganj';
    if (norm === 'kishorganj') return 'kishoreganj';
    const found = DISTRICTS.find((d) => d.nameEn.toLowerCase().replace(/[^a-z]/g, '') === norm);
    return found ? found.id : norm;
  };

  const drawCanvasExport = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = 960;
    const height = 1280;
    canvas.width = width;
    canvas.height = height;

    // 1. Background fill
    ctx.fillStyle = '#faf8f4';
    ctx.fillRect(0, 0, width, height);

    // 2. Outer decorative border card
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#ebe6dc';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.roundRect(24, 24, width - 48, height - 48, 24);
    ctx.fill();
    ctx.stroke();

    // 3. Top Banner with Brand Title: WanderBangla
    ctx.textAlign = 'left';
    ctx.fillStyle = '#17201c';
    ctx.font = 'bold 36px "Plus Jakarta Sans", sans-serif';
    ctx.fillText('Wander', 60, 95);

    ctx.fillStyle = currentTheme;
    ctx.fillText('Bangla', 60 + ctx.measureText('Wander').width, 95);

    ctx.fillStyle = '#6b716d';
    ctx.font = '500 15px "Anek Bangla", sans-serif';
    ctx.fillText('বাংলাদেশ ৬৪ জেলা ভ্রমণ মানচিত্র ও অফিশিয়াল ট্রাভেলার কার্ড', 60, 125);

    // Date Stamped on right
    const today = new Date().toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
    ctx.textAlign = 'right';
    ctx.fillStyle = '#78716c';
    ctx.font = '600 15px "Anek Bangla", sans-serif';
    ctx.fillText(today, width - 60, 105);

    // Divider
    ctx.strokeStyle = '#ebe6dc';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(60, 145);
    ctx.lineTo(width - 60, 145);
    ctx.stroke();

    // 4. Traveler Name & Stats Header
    ctx.textAlign = 'center';
    ctx.fillStyle = '#17201c';
    ctx.font = lang === 'bn' ? 'bold 36px "Anek Bangla", sans-serif' : 'bold 36px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(travelerName || (lang === 'bn' ? 'আমার ভ্রমণ ম্যাপ' : 'My Travel Map'), width / 2, 200);

    ctx.fillStyle = '#6b716d';
    ctx.font = lang === 'bn' ? 'italic 16px "Anek Bangla", sans-serif' : 'italic 16px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(`“${travelMotto || (lang === 'bn' ? 'বাংলার অপরূপ রূপ দেখতে বেরিয়ে পড়ি' : 'Exploring the beauty of Bangladesh')}”`, width / 2, 230);

    // 5. Stat Pill Box
    const statBoxY = 255;
    const statBoxHeight = 70;
    ctx.fillStyle = '#f7f4ed';
    ctx.strokeStyle = '#ebe6dc';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(140, statBoxY, width - 280, statBoxHeight, 16);
    ctx.fill();
    ctx.stroke();

    // Stats Columns
    ctx.textAlign = 'center';
    ctx.fillStyle = currentTheme;
    ctx.font = 'bold 26px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(`${visitedCount} / 64`, width / 2 - 180, statBoxY + 36);
    ctx.fillStyle = '#78716c';
    ctx.font = lang === 'bn' ? '13px "Anek Bangla", sans-serif' : '13px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(lang === 'bn' ? 'ঘুরে আসা জেলা' : 'Districts Visited', width / 2 - 180, statBoxY + 56);

    ctx.fillStyle = currentTheme;
    ctx.font = 'bold 26px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(`${percentage}%`, width / 2, statBoxY + 36);
    ctx.fillStyle = '#78716c';
    ctx.font = lang === 'bn' ? '13px "Anek Bangla", sans-serif' : '13px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(lang === 'bn' ? 'বাংলাদেশ অন্বেষণ' : 'Bangladesh Explored', width / 2, statBoxY + 56);

    let rankText = lang === 'bn' ? 'নবীন পর্যটক' : 'Novice Explorer';
    if (visitedCount >= 50) rankText = lang === 'bn' ? '৬৪ জেলা বিজয়ী' : 'Conqueror of BD';
    else if (visitedCount >= 30) rankText = lang === 'bn' ? 'অভিজ্ঞ পরিব্রাজক' : 'Seasoned Wanderer';
    else if (visitedCount >= 15) rankText = lang === 'bn' ? 'অন্বেষী ভবঘুরে' : 'Curious Traveler';

    ctx.fillStyle = currentTheme;
    ctx.font = lang === 'bn' ? 'bold 22px "Anek Bangla", sans-serif' : 'bold 20px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(rankText, width / 2 + 180, statBoxY + 36);
    ctx.fillStyle = '#78716c';
    ctx.font = lang === 'bn' ? '13px "Anek Bangla", sans-serif' : '13px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(lang === 'bn' ? 'অর্জিত ট্রাভেল ব্যাজ' : 'Traveler Badge', width / 2 + 180, statBoxY + 56);

    // 6. Draw the Authentic Vector Polygon Map of Bangladesh on Canvas
    ctx.save();
    const mapScale = 0.95;
    const mapX = (width - mapData.w * mapScale) / 2;
    const mapY = 345;

    ctx.translate(mapX, mapY);
    ctx.scale(mapScale, mapScale);

    // Draw all 64 district polygons
    mapData.f.forEach((feature) => {
      const districtId = getDistrictIdForFeature(feature.n);
      const isVisited = selectedDistricts.has(districtId);

      const path = new Path2D(feature.d);
      ctx.fillStyle = isVisited ? currentTheme : '#ded7cb';
      ctx.fill(path);

      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1;
      ctx.stroke(path);
    });

    ctx.restore();

    // 7. Footer
    const footerY = height - 40;
    ctx.textAlign = 'center';
    ctx.fillStyle = '#78716c';
    ctx.font = lang === 'bn' ? '14px "Anek Bangla", sans-serif' : '13px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(
      lang === 'bn'
        ? 'wanderbangla.com — নিজের ভ্রমণ মানচিত্র তৈরি করুন ও বন্ধুদের সাথে শেয়ার করুন'
        : 'wanderbangla.com — Create and share your personalized travel map of Bangladesh',
      width / 2,
      footerY
    );
  };

  const handleDownload = (format: 'png' | 'jpeg') => {
    drawCanvasExport();
    const canvas = canvasRef.current;
    if (!canvas) return;

    const mime = format === 'jpeg' ? 'image/jpeg' : 'image/png';
    const link = document.createElement('a');
    link.download = `wanderbangla-map-${Date.now()}.${format === 'jpeg' ? 'jpg' : 'png'}`;
    link.href = canvas.toDataURL(mime, 0.95);
    link.click();

    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  const handleShare = async () => {
    drawCanvasExport();
    const canvas = canvasRef.current;
    if (!canvas) return;

    if (navigator.share) {
      try {
        canvas.toBlob(async (blob) => {
          if (!blob) return;
          const file = new File([blob], 'wanderbangla-map.png', { type: 'image/png' });
          await navigator.share({
            title: 'আমার WanderBangla ভ্রমণ ম্যাপ',
            text: `আমি বাংলাদেশের ৬৪টির মধ্যে ${visitedCount}টি জেলা ভ্রমণ করেছি! দেখুন আমার ম্যাপ:`,
            files: [file],
          });
        });
      } catch (err) {
        navigator.clipboard.writeText(window.location.href);
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert(lang === 'bn' ? 'ম্যাপের লিংক কপি হয়েছে!' : 'Link copied to clipboard!');
    }
  };

  return (
    <div className="bg-white border border-[#ebe6dc] rounded-2xl p-5 shadow-xs flex flex-col">
      {/* Top Customizer Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#ebe6dc]">
        {/* Theme Swatches */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-700">
            {lang === 'bn' ? 'থিম:' : 'Theme:'}
          </span>
          <div className="flex items-center gap-1.5">
            {THEMES.map((theme) => (
              <button
                key={theme.id}
                onClick={() => setCurrentTheme(theme.color)}
                title={lang === 'bn' ? theme.nameBn : theme.nameEn}
                className={`w-7 h-7 rounded-full border-2 transition-transform duration-150 cursor-pointer ${
                  currentTheme === theme.color
                    ? 'scale-115 border-slate-900 shadow-sm ring-2 ring-slate-300'
                    : 'border-white hover:scale-105'
                }`}
                style={{ backgroundColor: theme.color }}
              />
            ))}
          </div>
        </div>

        {/* Inputs for Name & Motto */}
        <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
          <input
            type="text"
            value={travelerName}
            onChange={(e) => setTravelerName(e.target.value)}
            placeholder={lang === 'bn' ? 'আপনার নাম' : 'Traveler Name'}
            className="bg-[#faf8f4] border border-[#ebe6dc] rounded-xl px-3 py-1.5 text-xs text-slate-800 font-semibold focus:outline-none focus:border-[#0f6b4f] w-36 sm:w-44"
          />

          <input
            type="text"
            value={travelMotto}
            onChange={(e) => setTravelMotto(e.target.value)}
            placeholder={lang === 'bn' ? 'ভ্রমণ স্লোগান' : 'Travel Motto'}
            className="bg-[#faf8f4] border border-[#ebe6dc] rounded-xl px-3 py-1.5 text-xs text-slate-700 focus:outline-none focus:border-[#0f6b4f] w-36 sm:w-52 hidden lg:block"
          />

          {/* View Mode Toggle */}
          <div className="flex items-center bg-[#f3efe7] p-0.5 rounded-xl border border-[#ebe6dc]">
            <button
              onClick={() => setViewMode('map')}
              className={`p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer ${
                viewMode === 'map' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <MapIcon className="w-3.5 h-3.5" />
              <span>{lang === 'bn' ? 'মানচিত্র' : 'Map'}</span>
            </button>
            <button
              onClick={() => setViewMode('canvas')}
              className={`p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer ${
                viewMode === 'canvas' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>{lang === 'bn' ? 'কার্ড প্রিভিউ' : 'Card'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Visual Display Area */}
      <div className="py-4 flex-1 flex flex-col items-center justify-center">
        {viewMode === 'map' ? (
          <BangladeshMap
            selectedDistricts={selectedDistricts}
            onToggleDistrict={onToggleDistrict}
            themeColor={currentTheme}
            lang={lang}
          />
        ) : (
          <div className="w-full flex flex-col items-center justify-center bg-[#f7f4ed] p-3 rounded-2xl border border-[#ebe6dc] overflow-auto max-h-[640px]">
            <canvas
              ref={canvasRef}
              className="max-w-full h-auto rounded-xl shadow-lg border border-[#ebe6dc]"
              style={{ maxHeight: '580px' }}
            />
          </div>
        )}
      </div>

      {/* Hidden canvas used for high-res exports when in 'map' mode */}
      {viewMode === 'map' && <canvas ref={canvasRef} className="hidden" />}

      {/* Action Buttons Bar */}
      <div className="flex items-center justify-between flex-wrap gap-3 pt-3 border-t border-[#ebe6dc]">
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 font-medium">
            {lang === 'bn' ? '৬৪টির মধ্যে' : 'Visited'}{' '}
            <strong className="text-slate-900 font-bold">{visitedCount}</strong>{' '}
            {lang === 'bn' ? 'টি জেলা ভ্রমণ শেষ' : 'of 64 districts'}
          </span>
          <span className="text-xs bg-[#e3f0ea] text-[#0f6b4f] font-bold px-2 py-0.5 rounded-full">
            {percentage}%
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleShare}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-700 bg-[#f3efe7] hover:bg-[#eae5dc] rounded-xl transition-colors cursor-pointer border border-[#ebe6dc]"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? 'শেয়ার' : 'Share'}</span>
          </button>

          <button
            onClick={() => handleDownload('jpeg')}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 rounded-xl transition-colors cursor-pointer border border-[#ebe6dc]"
          >
            <Download className="w-3.5 h-3.5" />
            <span>JPG</span>
          </button>

          <button
            onClick={() => handleDownload('png')}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-extrabold text-white rounded-xl shadow-xs transition-transform hover:scale-[1.02] cursor-pointer"
            style={{ backgroundColor: currentTheme }}
          >
            {downloadSuccess ? (
              <>
                <Check className="w-4 h-4 text-emerald-200" />
                <span>{lang === 'bn' ? 'ডাউনলোড সম্পন্ন!' : 'Downloaded!'}</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>{lang === 'bn' ? 'ম্যাপ ডাউনলোড করুন (PNG)' : 'Download Map (PNG)'}</span>
                <Sparkles className="w-3 h-3 text-amber-300" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
