import React, { useState, useEffect } from 'react';
import { WanderBanglaLogo } from './components/WanderBanglaLogo';
import { HeroSection } from './components/HeroSection';
import { DistrictPicker } from './components/DistrictPicker';
import { CanvasMapStage } from './components/CanvasMapStage';
import { TourPlanner } from './components/TourPlanner';
import { TravelQuiz } from './components/TravelQuiz';
import { TouristHandbook } from './components/TouristHandbook';
import { TravelPassportBook } from './components/TravelPassportBook';
import { DISTRICTS, DIVISION_DISTRICTS } from './data/bangladeshData';
import { Globe, Heart, Sparkles, MapPin, BookOpen, ShieldAlert, Stamp } from 'lucide-react';
import confetti from 'canvas-confetti';

export default function App() {
  const [activeTab, setActiveTab] = useState<'map' | 'tour' | 'passport' | 'guide' | 'quiz'>('map');
  const [lang, setLang] = useState<'bn' | 'en'>('bn');

  // Stored visited districts in state with localStorage persistence
  const [selectedDistricts, setSelectedDistricts] = useState<Set<string>>(() => {
    try {
      const saved = localStorage.getItem('wanderbangla_visited_districts');
      if (saved) {
        return new Set(JSON.parse(saved));
      }
    } catch (e) {
      // ignore
    }
    return new Set(['dhaka', 'coxs-bazar', 'sylhet', 'chattogram']);
  });

  // Save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(
        'wanderbangla_visited_districts',
        JSON.stringify(Array.from(selectedDistricts))
      );
    } catch (e) {
      // ignore
    }
  }, [selectedDistricts]);

  // Toggle single district
  const handleToggleDistrict = (id: string) => {
    setSelectedDistricts((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
        if ((next.size % 10 === 0 || next.size === 64) && next.size > 0) {
          confetti({
            particleCount: 50,
            spread: 60,
            origin: { y: 0.7 },
          });
        }
      }
      return next;
    });
  };

  // Select all or deselect all
  const handleSelectAll = (select: boolean) => {
    if (select) {
      const allIds = DISTRICTS.map((d) => d.id);
      setSelectedDistricts(new Set(allIds));
      confetti({
        particleCount: 90,
        spread: 80,
        origin: { y: 0.6 },
      });
    } else {
      setSelectedDistricts(new Set());
    }
  };

  // Select or clear whole division
  const handleSelectDivision = (divisionNameBn: string, select: boolean) => {
    const districtIds = DIVISION_DISTRICTS[divisionNameBn] || [];
    setSelectedDistricts((prev) => {
      const next = new Set(prev);
      districtIds.forEach((id) => {
        if (select) next.add(id);
        else next.delete(id);
      });
      return next;
    });
  };

  const scrollToApp = () => {
    setActiveTab('map');
    const el = document.getElementById('app-sec');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#faf8f4] text-[#17201c] flex flex-col font-sans">
      {/* Top Navigation Bar with Clean Transparent WanderBangla Brand */}
      <header className="sticky top-0 z-50 bg-[#faf8f4]/95 backdrop-blur-md border-b border-[#ebe6dc]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex items-center justify-between gap-4 flex-wrap">
          {/* Brand Logo - Transparent Background, No Green Container */}
          <div className="flex items-center">
            <WanderBanglaLogo
              size="md"
              onClick={() => {
                setActiveTab('map');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
          </div>

            {/* Navigation Tabs (World Map replaced with Hidden Gems of Bangladesh) */}
          <nav className="flex items-center gap-1 bg-[#f3efe7] p-1 rounded-full border border-[#ebe6dc] overflow-x-auto">
            <button
              onClick={() => {
                setActiveTab('map');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`px-3.5 py-1.5 text-xs sm:text-sm font-bold rounded-full transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'map'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang === 'bn' ? 'বাংলাদেশ ম্যাপ' : 'Bangladesh Map'}
            </button>

            <button
              onClick={() => {
                setActiveTab('tour');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`px-3.5 py-1.5 text-xs sm:text-sm font-bold rounded-full transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'tour'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang === 'bn' ? 'ট্যুর প্ল্যান' : 'Tour Plan'}
            </button>

            {/* Travel Passport Book & Stamp Collection */}
            <button
              onClick={() => {
                setActiveTab('passport');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`px-3.5 py-1.5 text-xs sm:text-sm font-bold rounded-full transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'passport'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang === 'bn' ? 'ভ্রমণ পাসপোর্ট' : 'Travel Passport'}
            </button>

            {/* Seba (Services) Tab */}
            <button
              onClick={() => {
                setActiveTab('guide');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`px-3.5 py-1.5 text-xs sm:text-sm font-bold rounded-full transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'guide'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang === 'bn' ? 'সেবা' : 'Seba'}
            </button>

            <button
              onClick={() => {
                setActiveTab('quiz');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`px-3.5 py-1.5 text-xs sm:text-sm font-bold rounded-full transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'quiz'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang === 'bn' ? 'পাজল ও গেম' : 'Puzzle & Game'}
            </button>
          </nav>

          {/* Language Switcher */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setLang(lang === 'bn' ? 'en' : 'bn')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-[#ebe6dc] bg-white hover:border-slate-400 text-xs font-extrabold text-slate-800 transition-colors cursor-pointer shadow-2xs"
            >
              <Globe className="w-3.5 h-3.5 text-[#0f6b4f]" />
              <span>{lang === 'bn' ? 'English' : 'বাংলা'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-5 pb-16 flex-1 w-full">
        {/* Hero Section ONLY on Home Page (activeTab === 'map') */}
        {activeTab === 'map' && (
          <HeroSection
            onStartClick={scrollToApp}
            onOpenTouristGuide={() => {
              setActiveTab('guide');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            lang={lang}
          />
        )}

        {/* Tab 1: Bangladesh Map Application with 2nd Vector Polygon Map */}
        {activeTab === 'map' && (
          <main id="app-sec" className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Column: District Picker */}
            <section className="lg:col-span-5 xl:col-span-4 w-full">
              <DistrictPicker
                selectedDistricts={selectedDistricts}
                onToggleDistrict={handleToggleDistrict}
                onSelectAll={handleSelectAll}
                onSelectDivision={handleSelectDivision}
                lang={lang}
              />
            </section>

            {/* Right Column: 2nd Authentic SVG Vector Map & Customizer */}
            <section className="lg:col-span-7 xl:col-span-8 w-full">
              <CanvasMapStage
                selectedDistricts={selectedDistricts}
                onToggleDistrict={handleToggleDistrict}
                lang={lang}
              />
            </section>
          </main>
        )}

        {/* Tab 2: Tour Plan Itineraries & Budget Planner */}
        {activeTab === 'tour' && <TourPlanner lang={lang} />}

        {/* Tab 3: Official Bangladesh Travel Passport & Rubber Stamp Book */}
        {activeTab === 'passport' && (
          <TravelPassportBook
            lang={lang}
            selectedDistricts={selectedDistricts}
            onToggleDistrict={handleToggleDistrict}
          />
        )}

        {/* Tab 4: Seba - Rides, Bus, Green Line Boat, Live Currency & Emergency Hotlines */}
        {activeTab === 'guide' && <TouristHandbook lang={lang} />}

        {/* Tab 5: Travel Trivia & Game */}
        {activeTab === 'quiz' && <TravelQuiz lang={lang} />}
      </div>

      {/* Footer */}
      <footer className="border-t border-[#ebe6dc] bg-white py-10 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-6 border-b border-slate-100">
            {/* Logo and Tagline */}
            <div className="flex flex-col items-center md:items-start text-center md:text-left">
              <WanderBanglaLogo size="md" />
              <p className="text-xs text-slate-500 mt-2 max-w-sm">
                {lang === 'bn'
                  ? 'বাংলাদেশের ৬৪ জেলার ভ্রমণ মানচিত্র, ট্যুর প্ল্যানার ও ভ্রমণ সহায়িকা।'
                  : 'Interactive travel map, tour itineraries and traveler handbook of Bangladesh.'}
              </p>
            </div>

            {/* Quick Links & Social Media */}
            <div className="flex flex-col items-center md:items-end gap-3">
              <div className="flex flex-wrap justify-center md:justify-end gap-x-5 gap-y-2 text-xs font-semibold text-slate-600">
                <button
                  onClick={() => {
                    setActiveTab('map');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-[#0f6b4f] transition-colors cursor-pointer"
                >
                  {lang === 'bn' ? 'বাংলাদেশ ম্যাপ' : 'Bangladesh Map'}
                </button>
                <button
                  onClick={() => {
                    setActiveTab('tour');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-[#0f6b4f] transition-colors cursor-pointer"
                >
                  {lang === 'bn' ? 'ট্যুর প্ল্যান' : 'Tour Plan'}
                </button>
                <button
                  onClick={() => {
                    setActiveTab('passport');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-[#0f6b4f] transition-colors cursor-pointer"
                >
                  {lang === 'bn' ? 'ভ্রমণ পাসপোর্ট' : 'Travel Passport'}
                </button>
                <button
                  onClick={() => {
                    setActiveTab('guide');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-[#0f6b4f] transition-colors cursor-pointer flex items-center gap-1"
                >
                  <span>{lang === 'bn' ? 'সেবা' : 'Seba'}</span>
                </button>
                <button
                  onClick={() => {
                    setActiveTab('quiz');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-[#0f6b4f] transition-colors cursor-pointer"
                >
                  {lang === 'bn' ? 'ভ্রমণ কুইজ' : 'Travel Quiz'}
                </button>
              </div>

              {/* Social Connect Links (Facebook & Instagram) */}
              <div className="flex items-center gap-2 pt-1">
                <span className="text-[11px] font-bold text-slate-400">
                  {lang === 'bn' ? 'কানেক্ট থাকুন:' : 'Connect:'}
                </span>

                {/* Facebook Link */}
                <a
                  href="https://www.facebook.com/profile.php?id=61555816542974"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#1877F2]/10 hover:bg-[#1877F2] text-[#1877F2] hover:text-white border border-[#1877F2]/20 text-xs font-bold transition-all shadow-2xs group"
                  title="Facebook Profile"
                >
                  <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                  </svg>
                  <span>Facebook</span>
                </a>

                {/* Instagram Link */}
                <a
                  href="https://www.instagram.com/muhiudden_nafis/?hl=en"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-purple-500/10 hover:from-amber-500 hover:via-rose-500 hover:to-purple-600 text-rose-600 hover:text-white border border-rose-200 text-xs font-bold transition-all shadow-2xs group"
                  title="Instagram Profile (@muhiudden_nafis)"
                >
                  <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                  </svg>
                  <span>Instagram</span>
                </a>
              </div>
            </div>
          </div>

          <div className="pt-5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
            <div className="flex flex-wrap items-center gap-2">
              <span>© {new Date().getFullYear()} <strong>WanderBangla</strong>. All rights reserved.</span>
              <span>•</span>
              <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                <span>Made By:</span>
                <strong className="text-[#0f6b4f]">Muhiuddin Ahmed Nafis</strong>
                <a
                  href="https://www.facebook.com/profile.php?id=61555816542974"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#1877F2] hover:underline font-bold text-[11px]"
                >
                  [FB]
                </a>
                <a
                  href="https://www.instagram.com/muhiudden_nafis/?hl=en"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-rose-600 hover:underline font-bold text-[11px]"
                >
                  [IG]
                </a>
              </span>
            </div>
            <div className="flex items-center gap-1 text-slate-500">
              <span>{lang === 'bn' ? 'নির্মিত হয়েছে' : 'Built for'}</span>
              <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
              <span>{lang === 'bn' ? 'সকল বাংলাদেশ ভ্রমণপ্রেমীদের জন্য' : 'all Bangladesh wanderers'}</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
